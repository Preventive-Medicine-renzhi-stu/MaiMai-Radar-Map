import asyncio, sys, io
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding="utf-8")
from datetime import date
from src.config import Settings
from src.mcp_client import HttpMCPClient
from src.parsers import parse_activities

async def main():
    s = Settings.load()
    client = HttpMCPClient(s)
    async with client:
        raw = await client.call("campaign-calendar", {})
    print("raw type:", type(raw).__name__)
    text = raw if isinstance(raw, str) else repr(raw)
    print("raw len:", len(text))
    print("raw head:\n", text[:800])
    print("---- parse ----")
    acts = parse_activities(raw, today=date(2026, 10, 10))
    print("parsed activities:", len(acts))
    for a in acts[:6]:
        print("  ", a.date, "|", a.status, "|", a.title[:30])

asyncio.run(main())
