import asyncio, sys, json
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding="utf-8")
from src.config import Settings
from src.mcp_client import HttpMCPClient

async def main():
    s = Settings.load()
    client = HttpMCPClient(s)
    async with client:
        raw = await client.call("campaign-calendar", {})
    d = raw.get("data", {})
    print("data keys:", list(d.keys()))
    daily = d.get("dailyList") or []
    print("dailyList 天数:", len(daily))
    for day in daily:
        evs = day.get("events") or []
        print(" ", day.get("date"), "|", day.get("dateText"), "| events:", len(evs))
    # 取一个 event 的完整字段
    ev = daily[3]["events"][0] if len(daily) > 3 and daily[3].get("events") else daily[0]["events"][0]
    print("\n单个 event 的键:", list(ev.keys()))
    print("articleDto 键:", list((ev.get("articleDto") or {}).keys()))
    ad = ev.get("articleDto") or {}
    print("\narticleDto 样例:")
    print(json.dumps({k: (v[:60] + "..." if isinstance(v, str) and len(v) > 60 else v) for k, v in ad.items()}, ensure_ascii=False, indent=2)[:1200])
    # 顶层还有别的字段吗
    print("\nraw 顶层键:", list(raw.keys()))

asyncio.run(main())
