/* ==========================================================================
   麦麦雷达地图 —— 地图层（腾讯地图 GL JS + 纯本地 SVG 降级）
   * MCD.map      雷达首页的地图 / 雷达图
   * MCD.routeMap 下单结果页「前往餐厅」的独立小地图
   两个实例互不干扰；腾讯地图不可用时都退化为本地视图，不会白屏。
   ========================================================================== */
(function (MCD) {
  'use strict';

  var util = MCD.util;
  var data = MCD.data;

  var DEFAULT_CENTER = { lat: 22.5235, lng: 113.9383 }; // 深圳南山（GCJ-02 近似）

  /** 取某城市的中心坐标。
   *
   *  为什么需要它：麦当劳 MCP 不返回门店经纬度，而腾讯地图 WebServiceAPI
   *  需要额外申请配额（未开通时返回 status 110 / 121）。过去拿不到搜索结果就
   *  统一退回硬编码的默认点，结果「切到上海、地图还停在深圳」。
   *  现在城市坐标随数据包 / 本地服务下发，地图定位不再依赖任何外部接口。
   */
  function cityCoord(city) {
    if (!city) return null;
    var table = (MCD.api && MCD.api.cities && MCD.api.cities()) || [];
    if (!table.length) table = (MCD.DATA && MCD.DATA.cities) || [];
    for (var i = 0; i < table.length; i++) {
      var c = table[i];
      if (c && c.city === city && c.lat && c.lng) {
        return { lat: Number(c.lat), lng: Number(c.lng) };
      }
    }
    return null;
  }

  function tmapUsable() {
    return typeof TMap !== 'undefined' && !!TMap.Map;
  }

  function markerSvg(color, ring) {
    return 'data:image/svg+xml,' + encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" width="34" height="44" viewBox="0 0 34 44">' +
      '<path d="M17 43C17 43 32 26 32 16A15 15 0 1 0 2 16C2 26 17 43 17 43Z" fill="' + color +
      '" stroke="' + (ring || '#ffffff') + '" stroke-width="2.5"/>' +
      '<circle cx="17" cy="16" r="5.4" fill="#ffffff"/></svg>'
    );
  }

  function dotSvg() {
    return 'data:image/svg+xml,' + encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22">' +
      '<circle cx="11" cy="11" r="10" fill="rgba(28,95,168,.22)"/>' +
      '<circle cx="11" cy="11" r="5.5" fill="#1c5fa8" stroke="#fff" stroke-width="2"/></svg>'
    );
  }

  function decodePolyline(polyline) {
    var out = [];
    if (!polyline || !polyline.length) return out;
    if (polyline[0] instanceof TMap.LatLng) return polyline;
    if (typeof polyline[0] === 'number') {
      var lat = 0, lng = 0;
      for (var i = 0; i + 1 < polyline.length; i += 2) {
        lat += polyline[i];
        lng += polyline[i + 1];
        out.push(new TMap.LatLng(lat / 1e6, lng / 1e6));
      }
      return out;
    }
    return out;
  }

  // 腾讯 GL JS「服务类库」的 Search 类**没有 search() 方法**，
  // 只有 searchRegion / searchNearby / searchRectangle / explore / here / searchPoiId。
  // 早先这里写成 svc.search(...)，会抛 "svc.search is not a function" 并被 catch 吞掉，
  // 于是门店坐标永远补不上（异常静默 → exact 恒为 0）。只要 WebServiceAPI 一恢复可用，
  // 这个藏在后面的 bug 立刻现形：接口通了、坐标还是取不到。
  // 正确用法：searchRegion({ keyword, boundary: 'region(<城市>,0)' })，末位 0 = 范围不足时自动扩页。
  function poiSearch(keyword, region) {
    return new Promise(function (resolve) {
      if (!tmapUsable() || !TMap.service || !TMap.service.Search) return resolve(null);
      var city = region || (data.stores().length ? MCD.DATA.city : '');
      if (!city) return resolve(null);
      try {
        var svc = new TMap.service.Search({ pageSize: 5 });
        svc.searchRegion({ keyword: keyword, boundary: 'region(' + city + ',0)' })
          .then(function (res) {
            var list = (res && res.result && res.result.data) || (res && res.data) || [];
            for (var i = 0; i < list.length; i++) {
              var loc = list[i] && list[i].location;
              if (loc && (loc.lat || loc.lng)) return resolve({ lat: Number(loc.lat), lng: Number(loc.lng) });
            }
            resolve(null);
          })
          .catch(function () { resolve(null); });
      } catch (e) { resolve(null); }
    });
  }

  function relativePositions(list, center) {
    var maxD = 1;
    list.forEach(function (s) { maxD = Math.max(maxD, s.distance || 1); });
    var out = {};
    list.forEach(function (s, i) {
      var angle = (-90 + (360 * i) / Math.max(1, list.length)) * Math.PI / 180;
      var radius = 0.0016 + 0.0034 * ((s.distance || 0) / maxD);
      out[s.store_code] = {
        lat: center.lat + radius * Math.cos(angle),
        lng: center.lng + radius * Math.sin(angle) / Math.cos(center.lat * Math.PI / 180),
        exact: false
      };
    });
    return out;
  }

  /* ======================================================================
     雷达首页地图
     ====================================================================== */
  var mapState = {
    map: null, markers: null, lines: null, labels: null,
    coords: {}, user: null, ready: false, routeTimer: null, onSelect: null
  };

  var map = {};

  map.ready = function () { return mapState.ready; };

  map.setSelectHandler = function (fn) { mapState.onSelect = fn; };

  map.init = function () {
    if (mapState.map) return mapState.ready;   // 幂等：重复进入首页不重复创建
    if (!tmapUsable()) return false;
    try {
      mapState.map = new TMap.Map('tmap', {
        zoom: 14,
        center: new TMap.LatLng(
          (cityCoord(MCD.DATA.city) || DEFAULT_CENTER).lat,
          (cityCoord(MCD.DATA.city) || DEFAULT_CENTER).lng
        ),
        pitch: 0
      });
      mapState.markers = new TMap.MultiMarker({
        map: mapState.map,
        styles: {
          store: new TMap.MarkerStyle({ width: 26, height: 34, anchor: { x: 13, y: 34 }, src: markerSvg('#da291c') }),
          best: new TMap.MarkerStyle({ width: 32, height: 42, anchor: { x: 16, y: 42 }, src: markerSvg('#ffc72c', '#c99a00') }),
          me: new TMap.MarkerStyle({ width: 22, height: 22, anchor: { x: 11, y: 11 }, src: dotSvg() })
        },
        geometries: []
      });
      mapState.lines = new TMap.MultiPolyline({
        map: mapState.map,
        styles: {
          route: new TMap.PolylineStyle({ color: '#da291c', width: 6, borderWidth: 2, borderColor: '#ffffff', lineCap: 'round' }),
          link: new TMap.PolylineStyle({ color: '#da291c', width: 4, dashArray: [8, 8], borderWidth: 0, lineCap: 'round' })
        },
        geometries: []
      });
      mapState.labels = new TMap.MultiLabel({
        map: mapState.map,
        styles: {
          label: new TMap.LabelStyle({
            color: '#1f2328', size: 12, offset: { x: 0, y: -42 }, alignment: 'center',
            background: 'rgba(255,255,255,.94)', borderRadius: 6, padding: '3px 8px'
          })
        },
        geometries: []
      });
      mapState.markers.on('click', function (evt) {
        if (evt && evt.geometry && evt.geometry.id !== '__me__' && mapState.onSelect) {
          mapState.onSelect(evt.geometry.id);
        }
      });
      mapState.ready = true;
      return true;
    } catch (err) {
      if (window.console && console.warn) console.warn('[map] init failed', err);
      mapState.ready = false;
      return false;
    }
  };

  map.locate = async function (onBanner) {
    if (!mapState.ready) return;
    var stores = data.stores();
    if (!stores.length) return;

    // 先按数据包里的城市取基准点（不依赖腾讯接口），再尝试用关键词搜索细化。
    var base = cityCoord(MCD.DATA.city);
    var searched = await poiSearch(MCD.DATA.keyword, MCD.DATA.city);
    var center = searched || base;
    mapState.user = center || { lat: DEFAULT_CENTER.lat, lng: DEFAULT_CENTER.lng };
    if (center) mapState.map.setCenter(new TMap.LatLng(center.lat, center.lng));
    if (onBanner) {
      if (center) onBanner('');
      else onBanner('未能定位到「' + MCD.DATA.keyword + '」，门店位置为示意排布。', 'warn');
    }

    mapState.coords = relativePositions(stores, mapState.user);
    var exact = 0;
    for (var i = 0; i < stores.length; i++) {
      var hit = await poiSearch(stores[i].name, MCD.DATA.city);
      if (hit) {
        mapState.coords[stores[i].store_code] = { lat: hit.lat, lng: hit.lng, exact: true };
        exact++;
      }
    }
    if (onBanner && exact === 0) {
      onBanner('门店实际坐标未能获取（麦当劳 MCP 不返回经纬度），当前为按距离等比的示意排布；导航请以门店地址为准。', 'warn');
    }
    return { exact: exact, located: !!center };
  };

  map.drawMarkers = function (bestCode) {
    if (!mapState.ready || !mapState.user) return;
    var coords = mapState.coords;
    var geos = [{ id: '__me__', styleId: 'me', position: new TMap.LatLng(mapState.user.lat, mapState.user.lng) }];
    var labels = [{ id: '__me__', styleId: 'label', position: new TMap.LatLng(mapState.user.lat, mapState.user.lng), content: '我的位置' }];
    data.stores().forEach(function (s) {
      var pos = coords[s.store_code];
      if (!pos) return;
      var ll = new TMap.LatLng(pos.lat, pos.lng);
      geos.push({ id: s.store_code, styleId: s.store_code === bestCode ? 'best' : 'store', position: ll });
      labels.push({ id: s.store_code, styleId: 'label', position: ll, content: s.name.replace(/^麦当劳/, '').replace(/餐厅$/, '') });
    });
    mapState.markers.setGeometries(geos);
    mapState.labels.setGeometries(labels);
  };

  map.clearRoute = function () {
    if (mapState.ready && mapState.lines) mapState.lines.setGeometries([]);
  };

  /** 清空门店标记（城市下拉切到没有快照数据的城市时用，避免张冠李戴）。 */
  map.clearMarkers = function () {
    if (!mapState.ready) return;
    mapState.markers.setGeometries([]);
    mapState.labels.setGeometries([]);
  };

  /** 把地图视角移到某个城市（不做门店落点）。 */
  map.moveTo = function (city, keyword, onBanner) {
    if (!mapState.ready) return Promise.resolve(false);
    var base = cityCoord(city);
    return poiSearch(keyword || city, city).then(function (center) {
      var target = center || base;   // 搜不到就退回城市坐标，绝不乱停
      if (target) {
        mapState.map.setCenter(new TMap.LatLng(target.lat, target.lng));
        mapState.map.setZoom(12);
      } else if (onBanner) {
        onBanner('未能在地图上定位到「' + city + (keyword ? ' · ' + keyword : '') + '」。', 'warn');
      }
      return !!target;
    });
  };

  /** 把地图视角移到某个具体坐标（定位输入框选中候选后立刻落点用）。
   *
   *  与 ``moveTo`` 的区别：这里坐标是**已知的**（腾讯候选直接带 lat/lng），
   *  不再多发一次地点检索 —— 点一下就到位，不用等网络。
   */
  map.focus = function (lat, lng, zoom) {
    if (!mapState.ready || !mapState.map) return false;
    var la = Number(lat);
    var ln = Number(lng);
    if (!isFinite(la) || !isFinite(ln)) return false;
    try {
      mapState.map.setCenter(new TMap.LatLng(la, ln));
      mapState.map.setZoom(zoom || 14);
      mapState.focus = { lat: la, lng: ln };
      return true;
    } catch (e) {
      return false;
    }
  };

  /** 定位输入框选中的那个点（供测试断言）。 */
  map.focusedPoint = function () { return mapState.focus || null; };

  map.drawRoute = function (storeCode, onBanner) {
    if (!mapState.ready || !mapState.lines) return;
    var pos = mapState.coords[storeCode];
    if (!pos || !mapState.user) return;

    var from = new TMap.LatLng(mapState.user.lat, mapState.user.lng);
    var to = new TMap.LatLng(pos.lat, pos.lng);
    mapState.lines.setGeometries([{ id: 'link', styleId: 'link', paths: [from, to] }]);

    if (!TMap.service || !TMap.service.Driving) return;
    try {
      var drv = new TMap.service.Driving({ policy: 'LEAST_TIME' });
      drv.search({ from: from, to: to }).then(function (res) {
        var routes = (res && res.result && res.result.routes) || [];
        var route = routes[0];
        if (!route) return;
        var paths = decodePolyline(route.polyline);
        if (paths.length > 1) {
          mapState.lines.setGeometries([{ id: 'route', styleId: 'route', paths: paths }]);
          if (onBanner) {
            onBanner('已规划驾车路线：' + (route.distance ? (route.distance / 1000).toFixed(1) + 'km' : '') +
              '，约 ' + Math.round((route.duration || 0) / 60) + ' 分钟（腾讯地图实时路况）。', 'info');
          }
        }
      }).catch(function () { /* 保留虚线示意 */ });
    } catch (e) { /* 保留虚线示意 */ }
  };

  map.fit = function () {
    if (!mapState.ready || !mapState.map) return;
    var lats = [], lngs = [];
    Object.keys(mapState.coords).forEach(function (k) {
      lats.push(mapState.coords[k].lat); lngs.push(mapState.coords[k].lng);
    });
    if (mapState.user) { lats.push(mapState.user.lat); lngs.push(mapState.user.lng); }
    if (!lats.length) return;
    try {
      mapState.map.fitBounds(new TMap.LatLngBounds(
        new TMap.LatLng(Math.min.apply(null, lats), Math.min.apply(null, lngs)),
        new TMap.LatLng(Math.max.apply(null, lats), Math.max.apply(null, lngs)),
        true
      ), { padding: 70 });
    } catch (e) { /* 忽略 */ }
  };

  /* ---- 纯本地 SVG 距离雷达图（无底图，按真实距离等比排布） ---- */
  map.radar = function (svg, rows, bestCode) {
    if (!svg) return;
    var W = 620, H = 460, cx = W / 2, cy = H / 2 + 10, R = 165;
    var list = rows && rows.length ? rows : data.stores();
    var maxD = 1;
    list.forEach(function (s) { maxD = Math.max(maxD, s.distance || 1); });

    var parts = [];
    [0.25, 0.5, 0.75, 1].forEach(function (r) {
      parts.push('<circle cx="' + cx + '" cy="' + cy + '" r="' + (R * r) + '" fill="none" stroke="#e6e0d6" stroke-dasharray="4 5"/>');
      parts.push('<text x="' + (cx + 5) + '" y="' + (cy - R * r + 13) + '" font-size="10" fill="#9a9186">' +
        util.distLabel(Math.round(maxD * r)) + '</text>');
    });
    parts.push('<circle cx="' + cx + '" cy="' + cy + '" r="8" fill="#1c5fa8" stroke="#fff" stroke-width="3"/>');
    parts.push('<text x="' + cx + '" y="' + (cy + 24) + '" text-anchor="middle" font-size="11" fill="#1c5fa8" font-weight="700">我的位置</text>');

    list.forEach(function (s, i) {
      var angle = (-90 + (360 * i) / list.length) * Math.PI / 180;
      var r = 34 + (R - 34) * ((s.distance || 0) / maxD);
      var x = cx + r * Math.cos(angle), y = cy + r * Math.sin(angle);
      var isBest = s.store_code === bestCode;
      var color = isBest ? '#f0a400' : '#da291c';
      parts.push('<line x1="' + cx + '" y1="' + cy + '" x2="' + x + '" y2="' + y + '" stroke="' + color +
        '" stroke-width="' + (isBest ? 2.4 : 1.4) + '" stroke-dasharray="6 5" opacity="' + (isBest ? .95 : .5) + '"/>');
      parts.push('<circle cx="' + x + '" cy="' + y + '" r="' + (isBest ? 12 : 9) + '" fill="' + color +
        '" stroke="#fff" stroke-width="2.5" style="cursor:pointer" data-store="' + util.esc(s.store_code) + '"/>');
      if (isBest) parts.push('<text x="' + (x + 16) + '" y="' + (y + 4) + '" font-size="10.5" fill="#a97a00" font-weight="700">推荐</text>');
      var short = String(s.name || '').replace(/^麦当劳/, '').replace(/深圳|上海|北京|广州|杭州|成都/g, '').replace(/餐厅$/, '');
      parts.push('<text x="' + x + '" y="' + (y + 24) + '" text-anchor="middle" font-size="10.5" fill="#5f594f">' + util.esc(short) + '</text>');
      parts.push('<text x="' + x + '" y="' + (y + 36) + '" text-anchor="middle" font-size="10" fill="#da291c" font-weight="700">' + util.distLabel(s.distance) + '</text>');
    });

    svg.innerHTML = parts.join('');
    util.$$('circle[data-store]', svg).forEach(function (node) {
      node.addEventListener('click', function () {
        if (mapState.onSelect) mapState.onSelect(node.getAttribute('data-store'));
      });
    });
  };

  /** 地图当前把视线放在了哪里（供测试与排查用）。
   *
   *  为什么值得暴露：曾经有一个 bug 是「切到上海、地图还停在深圳」——
   *  因为拿不到搜索结果就退回硬编码默认点。这种事在页面上不容易一眼看出来
   *  （地图是能渲染的，只是位置不对），所以留一个可断言的出口。 */
  map.currentCenter = function () {
    if (mapState.user) return { lat: mapState.user.lat, lng: mapState.user.lng };
    if (mapState.map && mapState.map.getCenter) {
      try {
        var c = mapState.map.getCenter();
        if (c && c.lat != null && c.lng != null) return { lat: c.lat, lng: c.lng };
      } catch (e) { /* 忽略：只是调试出口 */ }
    }
    return null;
  };

  /** 地图内部状态快照（排查 / 测试用）。
   *
   *  为什么需要：地图「底图正常、却没有门店大头针」这类问题，光看页面很难判断
   *  是「没画」还是「画到屏幕外了」。这里把图层几何数、缩放级别一并吐出来，
   *  一眼就能分清是 setGeometries 没执行，还是坐标落在了视野外。 */
  map.debug = function () {
    function count(layer) {
      try {
        var g = layer && layer.getGeometries && layer.getGeometries();
        return g ? g.length : -1;
      } catch (e) { return -2; }
    }
    var zoom = null;
    try { if (mapState.map && mapState.map.getZoom) zoom = mapState.map.getZoom(); } catch (e) { /* 忽略 */ }
    return {
      ready: mapState.ready,
      center: map.currentCenter(),
      zoom: zoom,
      markerCount: count(mapState.markers),
      labelCount: count(mapState.labels),
      coordCount: Object.keys(mapState.coords).length,
      positioned: !!mapState.user,
      focusPoint: mapState.focus || null,
      fallbackHidden: (function () {
        var fb = document.getElementById('radar-fallback');
        return fb ? fb.hidden : null;
      })()
    };
  };

  MCD.map = map;

  /* ======================================================================
     下单结果页：独立小地图 + 走廊
     ====================================================================== */
  var routeState = {
    map: null, markers: null, lines: null, ready: false, anchor: null, from: null, to: null,
    // 路线是「真实驾车折线」还是「两点直线示意」——给测试一个可断言的出口。
    // 曾经 WebServiceAPI 未授权时这里永远是直线；授权恢复后若 poiSearch 仍取不到坐标，
    // 也依然会退成直线，所以必须能被断言出来，不能只靠肉眼看。
    routePoints: 0, routeMode: 'none'
  };

  var routeMap = {};

  routeMap.available = tmapUsable;

  routeMap.show = async function (containerId, storeCode) {
    var store = data.storeByCode(storeCode);
    if (!store) return false;
    if (!tmapUsable()) return false;

    try {
      // 基准点必须跟着「当前数据包所在城市」，不能用写死的默认坐标。
      // 曾经这里固定 深圳南山：切到呼伦贝尔下单后，结果页小地图照旧停在深圳，
      // 与雷达页早先修掉的「切上海还停在深圳」是同一个 bug，只是漏改了这半边。
      var anchor = cityCoord(MCD.DATA.city) || DEFAULT_CENTER;
      routeState.anchor = anchor;

      if (routeState.ready) {
        // 结果页会整段重绘，旧实例必须先销毁，否则地图会残留并泄漏
        try { routeState.map.destroy(); } catch (e) { /* 忽略 */ }
        routeState.ready = false;
      }
      routeState.map = new TMap.Map(containerId, {
        zoom: 15, center: new TMap.LatLng(anchor.lat, anchor.lng), pitch: 0
      });
      routeState.markers = new TMap.MultiMarker({
        map: routeState.map,
        styles: {
          store: new TMap.MarkerStyle({ width: 30, height: 38, anchor: { x: 15, y: 38 }, src: markerSvg('#da291c') }),
          me: new TMap.MarkerStyle({ width: 22, height: 22, anchor: { x: 11, y: 11 }, src: dotSvg() })
        },
        geometries: []
      });
      routeState.lines = new TMap.MultiPolyline({
        map: routeState.map,
        styles: {
          route: new TMap.PolylineStyle({ color: '#da291c', width: 6, borderWidth: 2, borderColor: '#fff', lineCap: 'round' })
        },
        geometries: []
      });
      routeState.ready = true;

      // 搜不到就把起点落在城市中心（而不是深圳），终点再按固定偏移示意。
      var from = await poiSearch(MCD.DATA.keyword, MCD.DATA.city);
      if (!from) from = { lat: anchor.lat, lng: anchor.lng };
      var to = await poiSearch(store.name, MCD.DATA.city) ||
        { lat: from.lat + 0.0035, lng: from.lng + 0.0025 };
      routeState.from = from;
      routeState.to = to;

      var a = new TMap.LatLng(from.lat, from.lng);
      var b = new TMap.LatLng(to.lat, to.lng);
      routeState.markers.setGeometries([
        { id: '__me__', styleId: 'me', position: a },
        { id: storeCode, styleId: 'store', position: b }
      ]);
      routeState.lines.setGeometries([{ id: 'link', styleId: 'route', paths: [a, b] }]);
      routeState.routePoints = 2;
      routeState.routeMode = 'straight';
      routeState.map.fitBounds(new TMap.LatLngBounds(a, b, true), { padding: 60 });

      if (TMap.service && TMap.service.Driving) {
        try {
          var drv = new TMap.service.Driving({ policy: 'LEAST_TIME' });
          var res = await drv.search({ from: a, to: b });
          var route = ((res && res.result && res.result.routes) || [])[0];
          var paths = route ? decodePolyline(route.polyline) : [];
          if (paths.length > 1) {
            routeState.lines.setGeometries([{ id: 'route', styleId: 'route', paths: paths }]);
            routeState.routePoints = paths.length;
            routeState.routeMode = 'driving';
          }
        } catch (e) { /* 保留直线 */ }
      }
      return true;
    } catch (err) {
      return false;
    }
  };

  /** 结果页小地图的落点（排查 / 测试用）。
   *
   *  留这个出口的原因：它曾经写死深圳南山，切到别的城市下单后小地图照旧停在深圳。
   *  「地图能渲染、只是位置不对」在页面上不容易一眼看出来，所以给个可断言的出口。 */
  routeMap.currentCenter = function () {
    if (routeState.anchor) return { lat: routeState.anchor.lat, lng: routeState.anchor.lng };
    try {
      var c = routeState.map && routeState.map.getCenter && routeState.map.getCenter();
      if (c && c.lat != null && c.lng != null) return { lat: c.lat, lng: c.lng };
    } catch (e) { /* 忽略：只是调试出口 */ }
    return null;
  };

  /** 结果页小地图的完整调试出口：路线是真实折线还是两点直线、起终点是否拿到了真实坐标。 */
  routeMap.debug = function () {
    return {
      ready: routeState.ready,
      center: routeMap.currentCenter(),
      anchor: routeState.anchor,
      from: routeState.from,
      to: routeState.to,
      routePoints: routeState.routePoints,
      mode: routeState.routeMode
    };
  };

  MCD.routeMap = routeMap;
})(window.MCD);
