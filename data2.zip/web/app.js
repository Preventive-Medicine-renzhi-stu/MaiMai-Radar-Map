/* ==========================================================================
   麦麦雷达地图 —— 启动 / 路由注册 / 全局顶栏（含用户信息下拉）
   依赖顺序：data.js → core.js → map.js → view-radar.js → view-order.js → app.js
   ========================================================================== */
(function () {
  'use strict';

  var MCD = window.MCD;
  var util = MCD.util;
  var $ = util.$, $$ = util.$$, esc = util.esc, yuan = util.yuan;

  if (!MCD.DATA) {
    document.body.innerHTML =
      '<div style="padding:40px;font-family:sans-serif">缺少数据包 <code>data.js</code>。' +
      '请先运行 <code>python -m src.main web --demo</code> 生成。</div>';
    return;
  }

  var DATA = MCD.DATA;

  /* ------------------------------------------------------------ 路由表 */
  MCD.router.register('radar', /^\/$/, MCD.views.radar.render);
  MCD.router.register('order', /^\/order\/?$/, MCD.views.order.render);
  MCD.router.register('checkout', /^\/checkout\/?$/, MCD.views.checkout.render);
  MCD.router.register('result', /^\/result\/?$/, MCD.views.result.render);
  MCD.router.register('activity', /^\/activity\/(\d+)\/?$/, MCD.views.activity.render);

  /* ==========================================================================
     顶栏 · 用户信息
     —— 只展示麦当劳 MCP 真实返回的字段；MCP 没有的（昵称 / 手机号）明确说明缺口，
        不虚构任何个人资料。
     ========================================================================== */
  function maskId(id) {
    var text = String(id || '');
    if (text.length <= 8) return text || '—';
    return text.slice(0, 5) + '…' + text.slice(-4);
  }

  function couponsForUser() {
    return MCD.calc.couponsFor();
  }

  /** 下拉里的「账号」区块 —— 明确区分「本地演示登录」与「MCP 真实账户数据」。 */
  function accountBlockHTML() {
    var auth = MCD.auth || {};
    var signed = auth.signedIn && auth.signedIn();
    var session = signed ? auth.current() : null;

    var row = session
      ? '<div class="ud-account is-on">' +
        '<span class="uda-avatar">' + esc(auth.avatarChar()) + '</span>' +
        '<div class="uda-body"><b>' + esc(auth.displayName()) + '</b>' +
        '<span>' + esc(auth.label()) + ' · 登录于 ' +
        esc(String(session.at || '').slice(0, 10)) + '</span></div>' +
        '<button class="btn btn-ghost btn-sm" data-logout>退出登录</button>' +
        '</div>'
      : '<div class="ud-account">' +
        '<span class="uda-avatar is-off">?</span>' +
        '<div class="uda-body"><b>未登录</b>' +
        '<span>登录后这里显示你的身份（本地演示）</span></div>' +
        '<button class="btn btn-primary btn-sm" data-login-open>立即登录</button>' +
        '</div>';

    return '<div class="ud-section"><div class="ud-title">账号<em>本地演示登录</em></div>' +
      row +
      '<p class="ud-gap is-tight">登录状态只存在这个浏览器里，不上传任何信息，' +
      '也未接入麦当劳真实账号体系；下面的券 / 积分 / 订单来自 MCP 真实返回的账户数据。</p>' +
      '</div>';
  }

  function userPanelHTML() {
    var acc = MCD.data.account() || {};
    var coupons = couponsForUser();
    var orders = MCD.data.orderHistory();
    var rawFavorites = [];
    MCD.data.orderHistory().forEach(function (o) {
      (o.preferred_names || []).forEach(function (n) {
        if (n && rawFavorites.indexOf(n) < 0 && rawFavorites.length < 6) rawFavorites.push(n);
      });
    });

    var pointsHTML =
      '<div class="ud-grid">' +
      cell(acc.available_points, '可用积分', true) +
      cell(acc.accumulated_points, '累计获得') +
      cell(acc.expired_points, '已过期') +
      '</div>' +
      '<p class="ud-note">本月将过期 ' + num(acc.expiring_this_month) +
      ' · 下月将过期 ' + num(acc.expiring_next_month) +
      ' · 已使用 ' + num(acc.used_points) +
      ' · 冻结 ' + num(acc.frozen_points) + '</p>';

    var couponHTML = coupons.length
      ? '<ul class="ud-list">' + coupons.slice(0, 5).map(function (c) {
        return '<li><b>' + esc(c.title) + '</b><span>' + esc(c.source || '') +
          (c.face_price != null ? ' · 券面 ¥' + c.face_price : ' · 标题未写明金额') +
          (c.valid_to ? ' · 至 ' + esc(String(c.valid_to).slice(0, 10)) : '') + '</span></li>';
      }).join('') + '</ul>'
      : '<div class="ud-empty">当前门店 / 卡包暂无可用券</div>';

    var orderHTML = orders.length
      ? '<ul class="ud-list">' + orders.slice(0, 5).map(function (o) {
        var names = (o.products || []).map(function (p) { return p.name; }).join('、') || o.summary;
        return '<li><b>' + esc(names) + '</b><span>' + esc(o.store_name) + ' · ' +
          esc(String(o.create_time || '').slice(0, 10)) + ' · 实付 ' + yuan(o.amount) + '</span></li>';
      }).join('') + '</ul>'
      : '<div class="ud-empty">还没有历史订单</div>';

    var favHTML = rawFavorites.length
      ? '<div class="ud-section"><div class="ud-title">口味偏好<em>从历史订单推导</em></div>' +
      '<div class="chips">' + rawFavorites.map(function (n) {
        return '<span class="chip is-on">' + esc(n) + '</span>';
      }).join('') + '</div></div>'
      : '';

    return accountBlockHTML() +

      '<div class="ud-head">' +
      '<span class="ud-avatar">麦</span>' +
      '<div class="ud-who"><b>麦享会会员</b>' +
      '<span>账户 ' + esc(maskId(acc.account_id)) + '</span></div>' +
      '</div>' +

      '<div class="ud-section"><div class="ud-title">积分账户<em>query-my-account</em></div>' +
      pointsHTML + '</div>' +

      '<div class="ud-section"><div class="ud-title">我的优惠券<em>available-coupons</em>' +
      '<span class="ud-count">' + coupons.length + ' 张</span></div>' + couponHTML + '</div>' +

      '<div class="ud-section"><div class="ud-title">历史订单<em>order-list</em>' +
      '<span class="ud-count">' + orders.length + ' 单</span></div>' + orderHTML + '</div>' +

      favHTML +

      '<div class="ud-foot">' +
      '<span>定位：' + esc(DATA.city || '—') + (DATA.keyword ? ' · ' + esc(DATA.keyword) : '') + '</span>' +
      '<span>数据时间 ' + esc(String(DATA.generated_at || '').slice(11, 16)) + '</span>' +
      '</div>' +
      '<p class="ud-gap">⚠️ 麦当劳 MCP 的 35 个 Tool 中<strong>没有昵称、手机号、头像</strong>这类个人资料接口，' +
      '因此本卡片只呈现 MCP 真实返回的账户 ID、积分、券与订单，不做虚构填充。</p>';
  }

  function cell(value, label, highlight) {
    return '<div class="ud-cell' + (highlight ? ' is-hl' : '') + '">' +
      '<b>' + num(value) + '</b><span>' + label + '</span></div>';
  }

  function num(value) {
    var n = Number(value || 0);
    return Math.abs(n % 1) < 1e-9 ? String(n) : n.toFixed(1);
  }

  var userOpen = false;

  /** 下拉里的按钮每次重绘后都要重新绑（innerHTML 换掉了节点）。 */
  function bindUserDrop() {
    var drop = $('#user-drop');
    if (!drop) return;

    function collapse() {
      userOpen = false;
      var menu = $('#user-menu');
      if (menu) menu.classList.remove('is-open');
    }

    var login = drop.querySelector('[data-login-open]');
    if (login) {
      login.addEventListener('click', function () {
        collapse();
        MCD.auth.open('manual');
      });
    }

    var logout = drop.querySelector('[data-logout]');
    if (logout) {
      logout.addEventListener('click', function () {
        collapse();
        MCD.auth.logout();     // 内部会重开登录框，方便立刻换个号
        renderAccount();
      });
    }
  }

  function refreshUserDrop() {
    var drop = $('#user-drop');
    if (!drop) return;
    drop.innerHTML = userPanelHTML();
    bindUserDrop();
  }

  function renderAccount() {
    var box = $('#account-box');
    if (!box) return;

    var acc = MCD.data.account() || {};
    var auth = MCD.auth || {};
    var signed = !!(auth.signedIn && auth.signedIn());

    box.innerHTML =
      '<span class="pill-demo">' + (DATA.demo ? '离线真实快照' : 'MCP 实时') + '</span>' +
      (DATA.scenario ? '<span class="pill-demo">' + esc(DATA.scenario) + '</span>' : '') +
      '<div class="user-menu' + (userOpen ? ' is-open' : '') + '" id="user-menu">' +
      '<button class="user-trigger" id="user-trigger" aria-haspopup="true" aria-expanded="' + (userOpen ? 'true' : 'false') + '">' +
      '<span class="user-avatar' + (signed ? ' is-in' : ' is-off') + '" id="user-avatar">' +
      esc(signed ? auth.avatarChar() : '?') + '</span>' +
      '<span class="user-brief"><b id="user-name">' + esc(signed ? auth.displayName() : '未登录') + '</b>' +
      '<span id="user-sub">' + (signed ? esc(auth.label())
        : num(acc.available_points) + ' ' + esc(acc.unit || '积分') + '可用') + '</span></span>' +
      '<span class="user-caret" aria-hidden="true">▾</span>' +
      '</button>' +
      '<div class="user-drop" id="user-drop" role="menu">' + userPanelHTML() + '</div>' +
      '</div>';

    var trigger = $('#user-trigger');
    if (trigger) {
      trigger.addEventListener('click', function (evt) {
        evt.stopPropagation();
        userOpen = !userOpen;
        var menu = $('#user-menu');
        if (menu) menu.classList.toggle('is-open', userOpen);
        trigger.setAttribute('aria-expanded', userOpen ? 'true' : 'false');
        // 展开时用最新数据重绘内容（购物车 / 登录态都可能刚变过）
        if (userOpen) refreshUserDrop();
      });
    }
    bindUserDrop();
  }

  // 登录 / 退出后立刻反映到顶栏
  if (MCD.auth && MCD.auth.onChange) MCD.auth.onChange(function () { renderAccount(); });

  /** 供雷达首页在渲染顶栏时同步刷新（数据可能已变化）。 */
  MCD.chrome = {
    refresh: function () { renderAccount(); renderFab(); },
    refreshFab: renderFab
  };

  /* ==========================================================================
     页面壳交互
     ========================================================================== */
  /** 悬浮球 / 页头「一键点餐」：落到 1.1 里选中（或推荐）的那家店。 */
  function quickOrder() {
    var code = MCD.orderStoreCode();
    if (code) MCD.state.storeCode = code;
    MCD.router.go('/order');
  }

  function shortStoreName(name) {
    return String(name || '').replace(/^麦当劳/, '').replace(/餐厅$/, '');
  }

  /** 把「将要下单的门店」写在悬浮球上，避免用户点了才发现店不对。 */
  function renderFab() {
    var el = $('#fab-store');
    if (!el) return;
    var row = MCD.orderStoreRow && MCD.orderStoreRow();
    el.textContent = row ? shortStoreName(row.name) : '未选门店';
    var fab = $('#fab-order');
    if (fab) {
      fab.title = row
        ? '一键点餐 · ' + row.name + '（可在雷达页左侧点门店卡片切换）'
        : '一键点餐';
    }
  }

  function bindChrome() {
    $$('[data-nav]').forEach(function (node) {
      node.addEventListener('click', function () {
        MCD.router.go(node.getAttribute('data-nav'));
      });
    });

    $$('[data-order-quick]').forEach(function (node) {
      node.addEventListener('click', quickOrder);
    });

    var fab = $('#fab-order');
    if (fab) fab.addEventListener('click', quickOrder);

    // 点击空白处收起用户下拉
    document.addEventListener('click', function (evt) {
      if (!userOpen) return;
      if (evt.target.closest && evt.target.closest('#user-menu')) return;
      userOpen = false;
      var menu = $('#user-menu');
      if (menu) menu.classList.remove('is-open');
      var t = $('#user-trigger');
      if (t) t.setAttribute('aria-expanded', 'false');
    });
  }

  /* ==========================================================================
     启动
     ========================================================================== */
  function boot() {
    // 城市下拉由 view-radar.js 的 renderCityPicker 负责渲染（自定义控件，
    // 默认停在数据包的快照城市）。这里只回填位置关键词输入框。
    var kwInput = $('#keyword-input');
    if (kwInput) kwInput.value = DATA.keyword || '';

    // 购物车一律从空开始：点餐页不再预置任何餐食，
    // 需要推荐时由「极速模式」的选品面板显式加入。
    MCD.state.cart = {};

    renderAccount();
    renderFab();
    bindChrome();
    MCD.router.start();

    // 探测本地服务：决定城市下拉是「点一下就切」还是「给出导出命令」。
    // 失败是正常的（file:// 打开、纯静态托管），所以它只更新状态、不抛错。
    if (MCD.api) MCD.api.probe();

    // 首屏登录框：已登录或本次会话已跳过则静默
    if (MCD.auth) MCD.auth.gate();
  }

  /* 腾讯地图 SDK 由 index.html 动态加载（key / proxy 二选一）。
     仅在页面声明了 __TMAP_PENDING__ 时才等待加载完成；无该标记时（如单测环境）
     直接启动，行为与改造前一致。 */
  function waitForTMap(timeoutMs) {
    return new Promise(function (resolve) {
      if (!window.__TMAP_PENDING__) return resolve(!!window.__TMAP_READY__);
      var t0 = Date.now();
      var timer = setInterval(function () {
        if (!window.__TMAP_PENDING__) {
          clearInterval(timer);
          resolve(!!window.__TMAP_READY__);
        } else if (Date.now() - t0 > timeoutMs) {
          clearInterval(timer);
          resolve(false);
        }
      }, 40);
    });
  }

  function start() {
    if (window.__TMAP_PENDING__) {
      waitForTMap(6000).then(boot);
      return;
    }
    boot();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
