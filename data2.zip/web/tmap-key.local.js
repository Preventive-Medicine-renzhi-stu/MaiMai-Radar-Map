// 由 `python -m src.main web` 依据 .env 的 TMAP_KEY 自动生成，请勿提交。
window.__TMAP_KEY__ = "63PBZ-KHHKI-XO5GZ-UOHV6-MGBCQ-B2FVB";
