/* ==========================================================================
   麦麦雷达地图 —— 本地服务适配层
   --------------------------------------------------------------------------
   纯静态页面拿不到麦当劳 MCP 的 Token（也不该拿），所以「换城市」必须有人
   替它去服务端拉数据。这个模块负责和本地服务（src/serve.py）对话：

     · GET  /api/status  —— 探测服务是否在线、能不能实时切城市、当前快照城市
     · POST /api/city    —— 真的去麦当劳 MCP 拉一次该城市的数据并重新导出

   三种情形都必须能优雅收场：
     ① 本地服务在线 + 有 Token  → 点城市名直接切换（真数据）
     ② 本地服务在线 + 无 Token  → 明确说明缺 Token，并给出填法
     ③ 没有本地服务（file:// 打开 / 纯静态托管）→ 回落到「复制导出命令」

   注意：绝不在浏览器里存放任何 Token —— Token 只在服务端的 .env 里。
   ========================================================================== */
(function (MCD) {
  'use strict';

  var STATUS_TIMEOUT = 4000;    // 探测要快，避免页面等着
  var SWITCH_TIMEOUT = 0;       // 真实导出可能几十秒，不设上限（用户能看到进度）

  var api = {
    state: {
      probed: false,
      online: false,
      live: false,
      mode: '',
      reason: '',
      city: '',
      keyword: '',
      generatedAt: '',
      storeCount: 0,
      cities: [],
      tmap: false,
      lastError: ''
    }
  };

  var onChange = null;

  api.onChange = function (fn) { onChange = fn; };
  function emit() { if (onChange) { try { onChange(api.state); } catch (e) { /* 渲染失败不影响探测 */ } } }

  /** 页面是否具备访问本地服务的前提（file:// 下 fetch 必然失败）。 */
  function reachable() {
    if (typeof fetch !== 'function') return false;
    try {
      if (window.location && window.location.protocol === 'file:') return false;
    } catch (e) { return false; }
    return true;
  }

  function request(method, url, body, timeout) {
    return new Promise(function (resolve, reject) {
      if (!reachable()) { reject(new Error('unreachable')); return; }

      var opts = { method: method, headers: {} };
      if (body) {
        opts.headers['Content-Type'] = 'application/json';
        opts.body = JSON.stringify(body);
      }

      var timer = timeout ? setTimeout(function () {
        reject(new Error('timeout'));
      }, timeout) : null;

      fetch(url, opts).then(function (res) {
        if (timer) clearTimeout(timer);
        return res.text().then(function (text) {
          var data = null;
          try { data = JSON.parse(text); } catch (e) { data = null; }
          resolve({ status: res.status, data: data || {} });
        });
      }).catch(function (err) {
        if (timer) clearTimeout(timer);
        reject(err);
      });
    });
  }

  /** 探测本地服务。失败不抛错 —— 离线是正常姿势，不是异常。 */
  api.probe = function () {
    return request('GET', '/api/status', null, STATUS_TIMEOUT).then(function (r) {
      var d = r.data || {};
      api.state.probed = true;
      api.state.online = !!d.ok;
      api.state.live = !!d.live;
      api.state.mode = d.mode || '';
      api.state.reason = d.live_reason || '';
      api.state.city = d.city || '';
      api.state.keyword = d.keyword || '';
      api.state.generatedAt = d.generated_at || '';
      api.state.storeCount = d.store_count || 0;
      api.state.cities = d.cities || [];
      api.state.tmap = !!d.tmap;
      api.state.lastError = d.last_error || '';
      emit();
      return api.state;
    }, function () {
      api.state.probed = true;
      api.state.online = false;
      api.state.live = false;
      api.state.reason = '';
      emit();
      return api.state;
    });
  };

  api.online = function () { return api.state.online; };
  api.live = function () { return api.state.online && api.state.live; };

  /**
   * 切换城市（真实拉取 + 重新导出）。
   * 返回服务端的原始 payload；``ok=false`` 时带 message / hint，由调用方展示。
   */
  api.switchCity = function (city, keyword) {
    return request('POST', '/api/city', { city: city, keyword: keyword || '' }, SWITCH_TIMEOUT)
      .then(function (r) {
        return r.data || { ok: false, message: '本地服务没有返回有效内容。' };
      }, function (err) {
        return {
          ok: false,
          code: String(err && err.message || err),
          message: '没能连上本地服务，请确认启动脚本的窗口还开着。'
        };
      });
  };

  /**
   * 把麦当劳 MCP Token 交给本地服务，由它写进项目根的 .env。
   * 这样「配置 Token」也不用离开浏览器 —— 页面本身依然不保存任何 Token。
   */
  api.saveToken = function (token) {
    return request('POST', '/api/token', { token: token }, 15000)
      .then(function (r) {
        return r.data || { ok: false, message: '本地服务没有返回有效内容。' };
      }, function (err) {
        return {
          ok: false,
          code: String(err && err.message || err),
          message: '没能连上本地服务，请确认启动脚本的窗口还开着。'
        };
      });
  };

  /** 城市清单：优先服务端 / 数据包，最后才回退内置副本。 */
  api.cities = function () {
    if (api.state.cities && api.state.cities.length) return api.state.cities;
    var fromData = MCD.DATA && MCD.DATA.cities;
    if (fromData && fromData.length) return fromData;
    return [];
  };

  /**
   * 地点候选（定位输入框的下拉）。
   *
   * 走本地服务的 ``/api/suggest`` —— 由服务端去问腾讯「关键词输入提示」，
   * 而不是浏览器直接调：Key 不必出现在请求里，白名单也由服务端转发 Referer 命中。
   * 服务端不可用时返回空候选，输入框静默降级（绝不假装搜到了）。
   */
  api.suggest = function (keyword, region, limit) {
    var kw = (keyword || '').trim();
    if (!kw) return Promise.resolve({ ok: true, items: [] });

    var url = '/api/suggest?keyword=' + encodeURIComponent(kw) +
      '&region=' + encodeURIComponent(region || '') +
      '&limit=' + encodeURIComponent(limit || 5);

    return request('GET', url, null, 8000).then(function (r) {
      var d = (r && r.data) || {};
      return {
        ok: d.ok !== false,
        items: d.items || [],
        message: d.message || '',
        code: d.code || ''
      };
    }, function (err) {
      return { ok: false, items: [], code: String(err && err.message || err),
        message: '没能连上本地定位服务。' };
    });
  };

  MCD.api = api;
})(window.MCD);
