/* ==========================================================================
   麦麦雷达地图 —— 核心层
   工具函数 / 全局状态 / 数据访问 / 结算引擎 / 前端路由
   被 core.js 之后的所有脚本共享（挂在 window.MCD 上，无构建、纯脚本加载）。
   ========================================================================== */
window.MCD = window.MCD || {};

(function (MCD) {
  'use strict';

  var DATA = window.MCD_DATA || null;
  MCD.DATA = DATA;

  /* ------------------------------------------------------------ 工具 */
  var util = {};

  util.$ = function (sel, root) { return (root || document).querySelector(sel); };
  util.$$ = function (sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  };

  util.esc = function (value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };

  util.round2 = function (n) { return Math.round((Number(n) || 0) * 100) / 100; };

  util.yuan = function (n, withSymbol) {
    if (n == null || isNaN(n)) return '—';
    var num = Number(n);
    var text = Math.abs(num % 1) < 1e-9 ? String(num) : num.toFixed(2);
    return withSymbol === false ? text : '¥' + text;
  };

  util.distLabel = function (m) {
    if (m == null || isNaN(m)) return '—';
    return m < 1000 ? m + 'm' : (m / 1000).toFixed(1) + 'km';
  };

  util.kcal = function (n) {
    if (n == null || isNaN(n)) return '';
    return Math.round(Number(n)) + ' 千卡';
  };

  util.img = function (url, cls, alt) {
    if (!url) return '<div class="' + (cls || 'ph') + ' is-empty"></div>';
    return '<img class="' + (cls || '') + '" src="' + util.esc(url) + '" alt="' +
      util.esc(alt || '') + '" loading="lazy" onerror="this.style.visibility=\'hidden\'">';
  };

  /** 删除字符串里的所有空白，便于模糊匹配。 */
  util.squash = function (s) { return String(s || '').replace(/\s+/g, ''); };

  MCD.util = util;

  /* ------------------------------------------------------------ 状态 */
  MCD.state = {
    // 雷达首页
    mode: 'nearby',
    nearbySort: 'distance',
    selectedStore: null,
    selectedDay: null,
    // 城市下拉的选择。null = 跟随数据包的快照城市。
    // 注意：这**不是**数据筛选条件 —— 快照是导出时固化的，换城市必须重新导出。
    city: null,
    keyword: null,
    cart: {},              // code -> qty（极速模式选品）
    pickerQuery: '',
    pickerCategory: '推荐',
    // 点餐页
    storeCode: null,
    dining: 'dinein',      // dinein | takeaway
    category: '全部',
    query: '',
    detailCode: null,      // 商品详情弹窗
    // 结算页
    useCoupons: true,
    pointsSpuId: null,     // 选中的积分换购项
    order: null,           // 下单结果
    orderCancelled: false, // 演示订单是否已取消
    demoReady: false       // 演示用：强制把订单推进到「已出餐」
  };

  /* ------------------------------------------------------------ 数据访问 */
  var data = {};

  data.stores = function () { return (DATA && DATA.stores) || []; };
  data.menus = function () { return (DATA && DATA.menus) || {}; };

  data.storeByCode = function (code) {
    var list = data.stores();
    for (var i = 0; i < list.length; i++) if (list[i].store_code === code) return list[i];
    return null;
  };

  data.menuOf = function (code) { return data.menus()[code] || []; };

  data.mealByCode = function (code) {
    var menus = data.menus();
    var keys = Object.keys(menus);
    for (var i = 0; i < keys.length; i++) {
      var list = menus[keys[i]];
      for (var j = 0; j < list.length; j++) if (list[j].code === code) return list[j];
    }
    return null;
  };

  data.nearbyRows = function (sort) {
    var key = (sort || MCD.state.nearbySort) === 'frequent' ? 'nearby_frequent' : 'nearby_distance';
    var mode = DATA && DATA.modes && DATA.modes[key];
    return (mode && mode.stores) || [];
  };

  data.speedRows = function () {
    var mode = DATA && DATA.modes && DATA.modes.speed;
    return (mode && mode.stores) || [];
  };

  data.rowByCode = function (code) {
    var rows = data.speedRows();
    for (var i = 0; i < rows.length; i++) if (rows[i].store_code === code) return rows[i];
    return null;
  };

  data.nearbyRowByCode = function (code) {
    var rows = data.nearbyRows('distance');
    for (var i = 0; i < rows.length; i++) if (rows[i].store_code === code) return rows[i];
    return null;
  };

  /** 点餐页默认门店：优先已选，其次最速/最近，最后第一家。 */
  data.defaultStoreCode = function () {
    if (MCD.state.storeCode) return MCD.state.storeCode;
    var speed = DATA && DATA.modes && DATA.modes.speed;
    if (speed && speed.best_store_code) return speed.best_store_code;
    var rows = data.nearbyRows('distance');
    if (rows.length) return rows[0].store_code;
    var list = data.stores();
    return list.length ? list[0].store_code : '';
  };

  /** 点餐页分类：以门店菜单的 tag 为准，附加「全部 / 折扣」两个虚拟分类。 */
  data.categoriesOf = function (storeCode) {
    var menu = data.menuOf(storeCode);
    var seen = {};
    menu.forEach(function (meal) {
      (meal.tags || []).forEach(function (tag) {
        if (tag) seen[tag] = (seen[tag] || 0) + 1;
      });
    });
    var list = Object.keys(seen).sort(function (a, b) { return seen[b] - seen[a]; });
    return list;
  };

  data.compositionOf = function (code) {
    return (DATA && DATA.compositions && DATA.compositions[code]) || null;
  };

  data.account = function () { return (DATA && DATA.account) || {}; };

  data.pointsMall = function () { return (DATA && DATA.points_mall) || []; };

  /** 历史订单原始列表（order-list）。 */
  data.orderHistory = function () { return (DATA && DATA.orders) || []; };

  /** 历史消费门店聚合。 */
  data.historyStores = function () { return (DATA && DATA.history_stores) || []; };

  /**
   * 「常点商品」集合（已去空白，便于匹配）。
   * 取套餐子项 + 顶层商品名 + 门店聚合里的商品名，
   * 用于给积分换购 / 推荐打上「你常点」标记。
   */
  var _favCache = null;
  data.favoriteNames = function () {
    if (_favCache) return _favCache;
    var set = {};
    function add(name) {
      var key = util.squash(name);
      if (key) set[key] = true;
    }
    data.orderHistory().forEach(function (o) {
      (o.preferred_names || []).forEach(add);
      (o.products || []).forEach(function (p) { add(p.name); });
    });
    data.historyStores().forEach(function (h) {
      (h.products || []).forEach(add);
    });
    _favCache = set;
    return set;
  };

  data.isFavorite = function (name) {
    return !!data.favoriteNames()[util.squash(name)];
  };

  /**
   * 统一的活动列表：以 7 天日历为骨架，用「追新」模式的卡片补齐
   * 关联商品 / 周边标记。索引即详情页地址 `#/activity/<index>`。
   */
  var _activityCache = null;
  data.activities = function () {
    if (_activityCache) return _activityCache;
    var map = {};
    var out = [];

    function keyOf(item) { return (item.date || '') + '|' + (item.title || ''); }

    var newest = (DATA && DATA.modes && DATA.modes.newest) || {};
    var byKey = {};
    (newest.activities || []).forEach(function (a) { byKey[keyOf(a)] = a; });

    var days = (DATA && DATA.calendar) || [];
    days.forEach(function (day) {
      (day.activities || []).forEach(function (a) {
        var key = keyOf(a);
        if (map[key]) return;
        var extra = byKey[key] || {};
        map[key] = true;
        out.push({
          index: out.length,
          date: a.date || day.date,
          date_label: day.month_day,
          weekday: day.weekday,
          day_label: day.label,
          is_today: !!day.is_today,
          title: a.title || '',
          body: a.body || '',
          image: a.image || '',
          is_gift: !!extra.is_gift,
          launch_tags: extra.launch_tags || [],
          products: extra.products || [],
          days_until: extra.days_until
        });
      });
    });

    // 追新模式里有、但日历没覆盖到的活动（例如超出 7 天）也并进来
    (newest.activities || []).forEach(function (a) {
      var key = keyOf(a);
      if (map[key]) return;
      map[key] = true;
      out.push({
        index: out.length,
        date: a.date,
        date_label: a.date_label,
        weekday: '',
        day_label: '',
        is_today: a.days_until === 0,
        title: a.title,
        body: a.body,
        image: a.image,
        is_gift: !!a.is_gift,
        launch_tags: a.launch_tags || [],
        products: a.products || [],
        days_until: a.days_until
      });
    });

    _activityCache = out;
    return out;
  };

  data.activityAt = function (index) {
    var list = data.activities();
    var i = parseInt(index, 10);
    return isNaN(i) ? null : list[i] || null;
  };

  MCD.data = data;

  /* ------------------------------------------------------------ 一键点餐口径

     「一键点餐」必须落到雷达首页 1.1 里那家店，而不是随便挑一个默认值：
       ① 1.1 里手动点选过的门店（state.selectedStore）优先；
       ② 否则用 1.1 当前排序下的第一家（「距离最近」/「最常去」）；
       ③ 都没有时退回极速模式的最快门店，最后退回第一家门店。

     注意：这个函数**只看 1.1 的选择**，不随当前处于哪个模式漂移，
     否则用户切到 1.2 看完活动再点悬浮球，下单的店就悄悄变了。 */
  MCD.orderStoreCode = function () {
    var st = MCD.state;
    if (st.selectedStore && data.storeByCode(st.selectedStore)) return st.selectedStore;

    var rows = data.nearbyRows();
    if (rows.length) return rows[0].store_code;

    var speed = DATA && DATA.modes && DATA.modes.speed;
    if (speed && speed.best_store_code) return speed.best_store_code;

    var list = data.stores();
    return list.length ? list[0].store_code : '';
  };

  /** 「一键点餐」对应的门店行（含距离 / 到达时长 / 繁忙度）。 */
  MCD.orderStoreRow = function () {
    var code = MCD.orderStoreCode();
    if (!code) return null;
    var row = data.nearbyRowByCode(code) || data.rowByCode(code);
    var store = data.storeByCode(code);
    if (!row && store) {
      row = { store_code: code, name: store.name, address: store.address, distance: null };
    }
    return row;
  };

  /* ------------------------------------------------------------ 结算引擎
     只使用数据包里**已写明**的规则，不猜测金额：
     * 券：kind=fixed 用券面价算差额；free 免单；bogo 免一份（需 ≥2 份）；
            kind=unknown（标题未写价，如「麦旋风任选」）只提示可用，不计金额。
     * 积分：麦当劳积分用于「积分 + 指定金额」换购，不是直接折现。
            这里做的是**换购方案推荐**，省下的钱按购物车里被覆盖的商品原价算。
     ================================================================= */
  var calc = {};

  calc.cartItems = function (storeCode) {
    var menu = data.menuOf(storeCode);
    var out = [];
    Object.keys(MCD.state.cart).forEach(function (code) {
      var qty = MCD.state.cart[code];
      if (!qty) return;
      var meal = null;
      for (var i = 0; i < menu.length; i++) if (menu[i].code === code) { meal = menu[i]; break; }
      // 换店后可能出现「购物车里有、这家店不卖」的商品：
      // 保留在购物车里（用户切回去还能用），但标记出来并从金额里剔除。
      var available = !!meal;
      if (!meal) meal = data.mealByCode(code);
      if (!meal) return;
      out.push({
        code: code,
        name: meal.name,
        price: meal.price,
        original_price: meal.original_price,
        image: meal.image,
        qty: qty,
        kcal: meal.kcal,
        available: available
      });
    });
    return out;
  };

  calc.subtotal = function (items) {
    var sum = 0;
    items.forEach(function (i) { sum += i.price * i.qty; });
    return util.round2(sum);
  };

  calc.originalTotal = function (items) {
    var sum = 0;
    items.forEach(function (i) { sum += (i.original_price || i.price) * i.qty; });
    return util.round2(sum);
  };

  /** 当前门店相关的全部券（门店券 + 卡包券），按券码去重。 */
  calc.couponsFor = function () {
    var all = [];
    var seen = {};
    (DATA && DATA.store_coupons || []).forEach(function (c) {
      var key = c.coupon_code || c.title;
      if (seen[key]) return;
      seen[key] = true;
      all.push(Object.assign({}, c, { source: '门店券' }));
    });
    (DATA && DATA.coupons || []).forEach(function (c) {
      var key = c.title;
      if (seen[key]) return;
      seen[key] = true;
      all.push(Object.assign({}, c, { source: c.status === '可领取' ? '待领取' : '卡包券' }));
    });
    return all;
  };

  function matches(coupon, item) {
    var terms = coupon.terms || [];
    var name = util.squash(item.name);
    for (var i = 0; i < terms.length; i++) {
      var t = util.squash(terms[i]);
      if (!t) continue;
      if (name.indexOf(t) >= 0 || t.indexOf(name) >= 0) return true;
    }
    return false;
  }

  /** 单份该商品的券面抵扣；null 表示券未写明金额。 */
  calc.couponDiscount = function (coupon, item) {
    if (coupon.kind === 'fixed' && coupon.face_price != null) {
      return util.round2(Math.max(0, item.price - coupon.face_price));
    }
    if (coupon.kind === 'free') return item.price;
    if (coupon.kind === 'bogo') return item.qty >= 2 ? item.price : null;
    return null;
  };

  /**
   * 用券方案：贪心配对（面额大的先用），每张券限用一次、每次消耗 1 份商品。
   * 返回 {lines, unknown, couponTotal}
   */
  calc.planCoupons = function (items) {
    var coupons = calc.couponsFor();
    var apps = [];
    coupons.forEach(function (coupon) {
      items.forEach(function (item, idx) {
        if (!matches(coupon, item)) return;
        apps.push({ coupon: coupon, index: idx, discount: calc.couponDiscount(coupon, item) });
      });
    });

    // 同一张券可能匹配多件商品，只保留抵扣最高的那份
    var byCoupon = {};
    apps.forEach(function (a) {
      var key = a.coupon.coupon_code || a.coupon.title;
      var prev = byCoupon[key];
      var score = a.discount == null ? -1 : a.discount;
      if (!prev || score > (prev.discount == null ? -1 : prev.discount)) byCoupon[key] = a;
    });

    var pool = Object.keys(byCoupon).map(function (k) { return byCoupon[k]; });
    pool.sort(function (a, b) {
      return (b.discount == null ? -1 : b.discount) - (a.discount == null ? -1 : a.discount);
    });

    var remaining = items.map(function (i) { return i.qty; });
    var lines = [];
    var unknown = [];
    var total = 0;

    pool.forEach(function (a) {
      if (a.discount == null) { unknown.push(a); return; }
      if (a.discount <= 0) return;
      if (remaining[a.index] <= 0) return;
      remaining[a.index] -= 1;
      total += a.discount;
      lines.push({
        title: a.coupon.title,
        code: a.coupon.coupon_code || '',
        source: a.coupon.source,
        amount: util.round2(a.discount),
        on_item: items[a.index].name
      });
    });

    return { lines: lines, unknown: unknown, couponTotal: util.round2(total) };
  };

  /**
   * 积分换购推荐。
   *
   * 两个关键修正（相比早期版本）：
   * 1. **按单份计价**：一次换购只替代 1 份商品，省的是「该商品单价 − 换购现金」，
   *    不能拿整件总价去减，否则多份时会把优惠算大。
   * 2. **结合历史订单**：用「常点商品」给换购项打标（`from_history`），
   *    让推荐顺序更贴近用户真实口味；积分不够的也返回，附「再攒 X 积分」提示。
   */
  calc.pointOffers = function (items) {
    var balance = Number(data.account().available_points || 0);
    var out = [];
    data.pointsMall().forEach(function (m) {
      if (!m.cash) return;
      var mallName = util.squash(String(m.name).replace(/(?<![\d.])\d+(\.\d+)?\s*元/, ''));
      var covered = [];
      var bestSave = 0;
      items.forEach(function (item, idx) {
        var name = util.squash(item.name);
        if (name.length < 2 || mallName.indexOf(name) < 0) return;
        covered.push(idx);
        var gain = util.round2(item.price - m.cash);
        if (gain > bestSave) bestSave = gain;
      });
      if (!covered.length || bestSave <= 0) return;

      var affordable = m.point <= balance;
      var fromHistory = covered.some(function (i) { return data.isFavorite(items[i].name); });
      out.push({
        spu_id: m.spu_id,
        name: m.name,
        point: m.point,
        cash: m.cash,
        saving: bestSave,
        covered: covered,
        covered_names: covered.map(function (i) { return items[i].name; }),
        image: m.image,
        affordable: affordable,
        shortfall: affordable ? 0 : util.round2(m.point - balance),
        from_history: fromHistory
      });
    });

    // 能换的在前（省得多优先、常点的略作加权），换不起的按缺口从小到大排
    out.sort(function (a, b) {
      if (a.affordable !== b.affordable) return a.affordable ? -1 : 1;
      if (!a.affordable) return a.shortfall - b.shortfall;
      if (a.from_history !== b.from_history) return a.from_history ? -1 : 1;
      return b.saving - a.saving;
    });
    return out;
  };

  /**
   * 汇总结算。
   * 返回：小计 / 券明细 / 积分换购 / 应付 / 共省 / 本店无售清单
   */
  calc.settle = function (storeCode) {
    var all = calc.cartItems(storeCode);
    var items = all.filter(function (i) { return i.available; });
    var unavailable = all.filter(function (i) { return !i.available; });

    var subtotal = calc.subtotal(items);
    var original = calc.originalTotal(items);

    var plan = MCD.state.useCoupons ? calc.planCoupons(items) : { lines: [], unknown: [], couponTotal: 0 };
    var offers = calc.pointOffers(items);

    var chosen = null;
    if (MCD.state.pointsSpuId != null) {
      offers.forEach(function (o) {
        if (o.spu_id === MCD.state.pointsSpuId && o.affordable) chosen = o;
      });
    }

    var pointsTotal = chosen ? chosen.saving : 0;
    var payable = util.round2(Math.max(0, subtotal - plan.couponTotal - pointsTotal));

    return {
      items: items,
      unavailable: unavailable,
      count: items.reduce(function (a, i) { return a + i.qty; }, 0),
      unavailableCount: unavailable.reduce(function (a, i) { return a + i.qty; }, 0),
      subtotal: subtotal,
      original: original,
      couponLines: plan.lines,
      couponUnknown: plan.unknown,
      couponTotal: plan.couponTotal,
      offers: offers,
      chosenOffer: chosen,
      pointsTotal: util.round2(pointsTotal),
      payable: payable,
      saved: util.round2(original - payable),
      crossStoreSaved: util.round2(subtotal - payable),
      kcal: items.reduce(function (a, i) { return a + (i.kcal || 0) * i.qty; }, 0)
    };
  };

  MCD.calc = calc;

  /* ------------------------------------------------------------ 路由 */
  var routes = [];
  var currentName = '';

  var router = {};

  router.register = function (name, pattern, view) {
    routes.push({ name: name, pattern: pattern, view: view });
  };

  router.path = function () {
    var raw = (window.location.hash || '').replace(/^#/, '');
    return raw || '/';
  };

  router.go = function (path) {
    var next = '#' + path;
    if (window.location.hash === next) { router.render(); return; }
    window.location.hash = next;
  };

  router.resolve = function (path) {
    for (var i = 0; i < routes.length; i++) {
      var m = routes[i].pattern.exec(path);
      if (m) return { name: routes[i].name, view: routes[i].view, params: m.slice(1) };
    }
    return null;
  };

  router.render = function () {
    var path = router.path();
    var hit = router.resolve(path);
    if (!hit) { router.go('/'); return; }

    currentName = hit.name;
    document.body.setAttribute('data-page', hit.name);

    util.$$('[data-page-view]').forEach(function (node) {
      node.hidden = node.getAttribute('data-page-view') !== hit.name;
    });

    util.$$('[data-route]').forEach(function (node) {
      var active = node.getAttribute('data-route') === path ||
        (path !== '/' && node.getAttribute('data-route') === path.split('/').slice(0, 2).join('/'));
      node.classList.toggle('is-active', active);
    });

    window.scrollTo(0, 0);
    try {
      hit.view.apply(null, hit.params);
    } catch (err) {
      if (window.console && console.error) console.error('[route]', hit.name, err);
    }
  };

  router.current = function () { return currentName; };

  router.start = function () {
    window.addEventListener('hashchange', router.render);
    router.render();
  };

  MCD.router = router;
})(window.MCD);
