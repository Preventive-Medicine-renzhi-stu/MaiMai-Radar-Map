/* ==========================================================================
   麦麦雷达地图 —— 点餐页 / 结算页 / 下单成功页 / 活动详情页
   入口：#/order   #/checkout   #/result   #/activity/<i>
   ========================================================================== */
(function (MCD) {
  'use strict';

  var util = MCD.util, data = MCD.data, state = MCD.state, calc = MCD.calc;
  var $ = util.$, $$ = util.$$, esc = util.esc, yuan = util.yuan, img = util.img;

  var DINING_LABEL = { dinein: '堂食', takeaway: '打包' };
  var CANCEL_WINDOW_MS = 60 * 1000; // 下单后 1 分钟内视为「商家未接单」

  /* ------------------------------------------------------------ 小工具 */
  function toast(text) {
    var el = $('#toast');
    if (!el) return;
    el.textContent = text;
    el.classList.add('is-on');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { el.classList.remove('is-on'); }, 3200);
  }
  MCD.toast = toast;   // 全局小提示（雷达页 / 登录弹窗也会用）

  function pad(n) { return (n < 10 ? '0' : '') + n; }

  function clock(date) {
    return pad(date.getHours()) + ':' + pad(date.getMinutes());
  }

  function clockOf(ts) {
    var d = new Date(ts);
    return pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  function storeRow(code) {
    return data.rowByCode(code) || data.nearbyRowByCode(code) || null;
  }

  function setQty(code, delta) {
    var next = Math.max(0, (state.cart[code] || 0) + delta);
    if (next) state.cart[code] = next; else delete state.cart[code];
  }

  function cartCodes() {
    return Object.keys(state.cart).filter(function (k) { return state.cart[k] > 0; });
  }

  /** 某店能买到购物车里几件。 */
  function cartAvailIn(storeCode) {
    var have = {};
    data.menuOf(storeCode).forEach(function (m) { have[m.code] = true; });
    var codes = cartCodes();
    var ok = codes.filter(function (c) { return have[c]; }).length;
    return { ok: ok, total: codes.length };
  }

  /** 门店候选列表（带距离 / 到达 / 等待 / 繁忙度）。 */
  function storeCandidates() {
    var rows = data.nearbyRows('distance').slice();
    var seen = {};
    rows.forEach(function (r) { seen[r.store_code] = true; });
    data.stores().forEach(function (s) {
      if (seen[s.store_code]) return;
      var row = storeRow(s.store_code);
      if (row) { rows.push(row); seen[s.store_code] = true; }
    });
    return rows;
  }

  /* ------------------------------------------------------------ 通用对话框 */
  function openDialog(html, onMount) {
    var host = $('#modal-host');
    if (!host) return;
    host.innerHTML = html;
    host.hidden = false;
    var close = $('#modal-close');
    if (close) close.addEventListener('click', closeDialog);
    $$('.modal-mask', host).forEach(function (mask) {
      mask.addEventListener('click', function (evt) {
        if (evt.target === mask) closeDialog();
      });
    });
    if (onMount) onMount(host);
  }

  function closeDialog() {
    var host = $('#modal-host');
    if (host) { host.innerHTML = ''; host.hidden = true; }
  }

  /* ==========================================================================
     门店切换（点餐页 / 结算页共用）
     —— 购物车按餐品码存储，与门店无关，所以换店天然保留订单内容；
        新店不卖的商品保留在购物车并标记「本店无售」，从金额里剔除。
     ========================================================================== */
  function openStoreSwitch(onDone) {
    var current = state.storeCode || data.defaultStoreCode();
    var rows = storeCandidates();
    var picked = current;

    var listHTML = rows.map(function (row) {
      var av = cartAvailIn(row.store_code);
      var full = av.total === 0 || av.ok === av.total;
      return '<button class="store-pick' + (row.store_code === current ? ' is-on' : '') +
        '" data-pick="' + esc(row.store_code) + '">' +
        '<div class="sp-main"><b>' + esc(row.name) + '</b>' +
        '<span>' + esc(row.address) + '</span></div>' +
        '<div class="sp-meta">' +
        '<span>' + util.distLabel(row.distance) + '</span>' +
        '<span>' + esc(row.travel_label) + '约 ' + row.travel_minutes + ' 分</span>' +
        '<span>等待约 ' + row.queue_minutes + ' 分</span>' +
        '<span class="sp-busy' + (row.busy_score >= 52 ? ' is-hot' : '') + '">' + esc(row.busy_label) + '</span>' +
        (av.total
          ? '<span class="sp-avail' + (full ? '' : ' is-warn') + '">可买 ' + av.ok + '/' + av.total + '</span>'
          : '<span class="sp-avail">—</span>') +
        '</div></button>';
    }).join('');

    var html = '<div class="modal-mask" id="store-modal">' +
      '<div class="modal-card dialog-card" role="dialog" aria-modal="true">' +
      '<button class="modal-close" id="modal-close" aria-label="关闭">✕</button>' +
      '<div class="modal-body">' +
      '<h3 class="modal-name">临时换一家门店</h3>' +
      '<p class="modal-desc">购物车会原样保留。换店后如果有商品在新店不售卖，' +
      '会被标为「本店无售」并从结算金额中剔除，切回原店即可恢复。</p>' +
      '<div class="store-pick-list">' + listHTML + '</div>' +
      '</div>' +
      '<div class="modal-foot">' +
      '<span class="modal-hint" id="switch-hint">当前：' + esc(storeNameOf(current)) + '</span>' +
      '<button class="btn btn-primary" id="switch-confirm">确认切换</button>' +
      '</div></div></div>';

    openDialog(html, function (host) {
      $$('[data-pick]', host).forEach(function (btn) {
        btn.addEventListener('click', function () {
          picked = btn.getAttribute('data-pick');
          $$('[data-pick]', host).forEach(function (b) { b.classList.toggle('is-on', b === btn); });
          var hint = $('#switch-hint');
          if (hint) hint.textContent = '将切换到：' + storeNameOf(picked);
        });
      });

      var confirm = $('#switch-confirm');
      if (confirm) confirm.addEventListener('click', function () {
        if (picked === current) { closeDialog(); return; }
        state.storeCode = picked;
        // 换店后清掉「已选积分换购」——它绑定的是上一家店的购物车组合
        state.pointsSpuId = null;
        closeDialog();
        var av = cartAvailIn(picked);
        if (av.total && av.ok < av.total) {
          toast('已切到「' + storeNameOf(picked) + '」，其中 ' + (av.total - av.ok) + ' 件本店无售');
        } else {
          toast('已切换到「' + storeNameOf(picked) + '」，购物车已保留');
        }
        if (onDone) onDone();
      });
    });
  }

  function storeNameOf(code) {
    var s = data.storeByCode(code);
    return s ? s.name : code;
  }

  /* ==========================================================================
     点餐页
     ========================================================================== */
  function orderStore() {
    var code = data.defaultStoreCode();
    state.storeCode = code;
    return data.storeByCode(code);
  }

  function mealVisible(meal, cat, q) {
    if (q) {
      return meal.name.indexOf(q) >= 0 || meal.code.indexOf(q) >= 0;
    }
    if (cat === '全部') return true;
    if (cat === '折扣') return (meal.original_price || meal.price) > meal.price + 0.001;
    return (meal.tags || []).indexOf(cat) >= 0;
  }

  function mealCard(meal) {
    var qty = state.cart[meal.code] || 0;
    var kcal = meal.kcal != null ? Math.round(meal.kcal) + ' 千卡' : '热量未收录';
    var kcalCls = meal.kcal == null ? ' is-muted' : '';
    var fav = data.isFavorite(meal.name) ? '<span class="badge is-fav">你常点</span>' : '';
    return '<article class="meal-card' + (qty ? ' is-on' : '') + '" data-meal-card="' + esc(meal.code) + '">' +
      '<div class="meal-media">' + img(meal.image, 'meal-img', meal.name) +
      '<span class="meal-kcal' + kcalCls + '">' + esc(kcal) + '</span>' +
      (fav ? '<span class="meal-fav">' + fav + '</span>' : '') + '</div>' +
      '<div class="meal-body">' +
      '<h4 class="meal-name">' + esc(meal.name) + '</h4>' +
      '<p class="meal-desc">' + esc(meal.desc || '') + '</p>' +
      '<div class="meal-foot">' +
      '<span class="meal-price"><b>' + yuan(meal.price) + '</b>' +
      (meal.original_price > meal.price ? '<s>' + yuan(meal.original_price) + '</s>' : '') + '</span>' +
      (qty
        ? '<span class="qty"><button data-act="minus" data-code="' + esc(meal.code) + '">−</button>' +
        '<span>' + qty + '</span><button data-act="plus" data-code="' + esc(meal.code) + '">+</button></span>'
        : '<button class="btn btn-round" data-act="plus" data-code="' + esc(meal.code) + '" aria-label="加入">＋</button>') +
      '</div></div></article>';
  }

  function catCount(cat, storeCode) {
    return data.menuOf(storeCode).filter(function (m) { return mealVisible(m, cat, ''); }).length;
  }

  /** 餐品区（可单独重绘，见 refreshMealArea）。 */
  function mealAreaHtml(store) {
    var list = data.menuOf(store.store_code).filter(function (m) {
      return mealVisible(m, state.category, state.query.trim());
    });
    var q = state.query.trim();
    return '<div class="meal-area-head"><h3>' + esc(state.category) + '</h3>' +
      '<span>共 ' + list.length + ' 款' + (q ? '（搜索「' + esc(q) + '」）' : '') + '</span>' +
      (q ? '<button class="btn btn-ghost btn-sm" data-clear-query>清除搜索</button>' : '') +
      '</div>' +
      (list.length
        ? '<div class="meal-grid">' + list.map(mealCard).join('') + '</div>'
        : '<div class="empty">没有匹配「' + esc(q) + '」的餐品</div>');
  }

  function refreshMealArea() {
    var box = $('#meal-area');
    if (!box) { renderOrder(); return; }
    var store = orderStore();
    if (!store) return;
    box.innerHTML = mealAreaHtml(store);
  }

  function renderOrder() {
    var store = orderStore();
    if (!store) {
      $('#order-root').innerHTML = '<div class="empty">没有可用门店数据</div>';
      return;
    }

    var row = storeRow(store.store_code) || {};
    var cats = ['全部', '折扣'].concat(data.categoriesOf(store.store_code));
    if (cats.indexOf(state.category) < 0) state.category = '全部';

    var menu = data.menuOf(store.store_code);
    var settle = calc.settle(store.store_code);

    var html =
      '<div class="order-topbar">' +
      '<button class="btn btn-ghost btn-back" data-back>← 返回地图</button>' +
      '<div class="oh-store">' +
      '<strong>' + esc(store.name) + '</strong>' +
      '<span>' + esc(store.address) + '</span>' +
      '<span class="oh-meta">' + util.distLabel(store.distance) +
      (row.travel_minutes != null ? ' · ' + esc(row.travel_label || '') + '约 ' + row.travel_minutes + ' 分钟' : '') +
      (store.open_time ? ' · 营业 ' + esc(store.open_time + '-' + store.close_time) : '') +
      ' · ' + esc(store.be_type_label) + '</span>' +
      '</div>' +
      '<button class="btn btn-outline btn-switch" id="switch-store">⇄ 临时换店</button>' +
      '<span class="pill-demo">' + (MCD.DATA.demo ? '离线真实快照' : 'MCP 实时') + '</span>' +
      '</div>' +

      '<div class="order-toolbar">' +
      '<div class="dining-toggle" role="group" aria-label="就餐方式">' +
      '<button data-dining="dinein" class="' + (state.dining === 'dinein' ? 'is-active' : '') + '">堂食</button>' +
      '<button data-dining="takeaway" class="' + (state.dining === 'takeaway' ? 'is-active' : '') + '">打包</button>' +
      '</div>' +
      '<input class="order-search" id="order-search" type="search" placeholder="搜索餐品 / 餐品码" value="' + esc(state.query) + '">' +
      '<span class="order-count">本店 ' + menu.length + ' 款</span>' +
      '</div>' +

      '<div class="order-body">' +
      '<nav class="cat-rail">' +
      cats.map(function (c) {
        return '<button class="cat-item' + (state.category === c ? ' is-active' : '') + '" data-cat="' + esc(c) + '">' +
          '<span>' + esc(c) + '</span><em>' + catCount(c, store.store_code) + '</em></button>';
      }).join('') +
      '</nav>' +
      '<div class="meal-area" id="meal-area">' + mealAreaHtml(store) + '</div>' +
      '</div>' +

      settleBarHTML(settle) +
      cartDrawerHTML(settle);

    $('#order-root').innerHTML = html;

    $$('[data-back]', $('#order-root')).forEach(function (b) {
      b.addEventListener('click', function () { MCD.router.go('/'); });
    });
    $$('[data-dining]', $('#order-root')).forEach(function (b) {
      b.addEventListener('click', function () {
        state.dining = b.getAttribute('data-dining');
        renderOrder();
      });
    });
    /* 搜索框绑定。
       ⚠️ 绝不能在 input 里调 renderOrder() —— 那会把 `#order-root` 整体 innerHTML
       换掉，输入框节点每次按键都被销毁重建，中文输入法的组字被打断
       （现象：拼音能显示、汉字上不去）。这里只重绘 `#meal-area`，
       并且组字期间（compositionstart → compositionend）干脆不刷新。 */
    var search = $('#order-search');
    if (search) {
      var composing = false;
      search.addEventListener('compositionstart', function () { composing = true; });
      search.addEventListener('compositionend', function (e) {
        composing = false;
        state.query = e.target.value;
        refreshMealArea();
      });
      search.addEventListener('input', function (e) {
        state.query = e.target.value;
        if (composing || e.isComposing) return;   // 组字中：等 compositionend
        refreshMealArea();
      });
    }
    $$('.cat-item', $('#order-root')).forEach(function (b) {
      b.addEventListener('click', function () {
        state.category = b.getAttribute('data-cat');
        state.query = '';
        renderOrder();
      });
    });
    $('#switch-store').addEventListener('click', function () {
      openStoreSwitch(function () { renderOrder(); });
    });
    ensureOrderDelegation();
  }

  function settleBarHTML(settle) {
    return '<div class="cart-bar" id="cart-bar">' +
      '<button class="cart-toggle" id="cart-toggle">' +
      '<span class="cart-icon">🛒<i class="cart-badge' + (settle.count ? '' : ' is-hide') + '">' +
      (settle.unavailableCount ? settle.count + '+' + settle.unavailableCount : settle.count) + '</i></span>' +
      '<span class="cart-amount"><b>' + yuan(settle.payable) + '</b>' +
      (settle.saved > 0 ? '<em>已省 ' + yuan(settle.saved) + '</em>'
        : (settle.count ? '<em>门店价</em>' : '<em>购物车是空的</em>')) + '</span>' +
      '</button>' +
      '<button class="btn btn-primary btn-pay" id="go-checkout"' + (settle.count ? '' : ' disabled') + '>' +
      (settle.count ? '去结算 · ' + settle.count + ' 件' : '请选择餐品') + '</button>' +
      '</div>';
  }

  function cartLine(i) {
    return '<div class="cd-row' + (i.available ? '' : ' is-off') + '">' + img(i.image, 'cd-thumb') +
      '<div class="cd-info"><div class="cd-name">' + esc(i.name) +
      (i.available ? '' : '<span class="badge is-warn">本店无售</span>') + '</div>' +
      '<div class="cd-sub">' + yuan(i.price) + (i.kcal ? ' · ' + Math.round(i.kcal) + ' 千卡' : '') + '</div></div>' +
      '<span class="qty"><button data-act="minus" data-code="' + esc(i.code) + '">−</button>' +
      '<span>' + i.qty + '</span><button data-act="plus" data-code="' + esc(i.code) + '">+</button></span>' +
      '<span class="cd-sum">' + (i.available ? yuan(i.price * i.qty) : '不计入') + '</span></div>';
  }

  function cartDrawerHTML(settle) {
    var lines = settle.items.map(cartLine).join('');
    var offLines = settle.unavailable.map(cartLine).join('');

    var discount = '';
    if (settle.couponTotal > 0) {
      discount += settle.couponLines.map(function (l) {
        return '<div class="cd-line"><span>🎟️ ' + esc(l.title) + '</span><b>- ' + yuan(l.amount) + '</b></div>';
      }).join('');
    }
    if (settle.pointsTotal > 0 && settle.chosenOffer) {
      discount += '<div class="cd-line"><span>🎁 ' + esc(settle.chosenOffer.name) + '</span><b>- ' + yuan(settle.pointsTotal) + '</b></div>';
    }
    if (settle.couponUnknown.length) {
      discount += '<div class="cd-line is-muted"><span>另有 ' + settle.couponUnknown.length +
        ' 张券可用（标题未写明金额）</span><b>待核销</b></div>';
    }

    var hasAny = settle.count || settle.unavailableCount;

    return '<div class="cart-drawer" id="cart-drawer" hidden>' +
      '<div class="cd-head"><strong>购物车</strong>' +
      '<button class="btn btn-ghost btn-sm" id="cart-close">收起</button></div>' +
      (hasAny
        ? (settle.count
          ? '<div class="cd-list">' + lines + '</div>' +
          '<div class="cd-total">' +
          '<div class="cd-line"><span>商品小计</span><b>' + yuan(settle.subtotal) + '</b></div>' +
          discount +
          '<div class="cd-line is-total"><span>预计实付</span><b>' + yuan(settle.payable) + '</b></div>' +
          '<p class="cd-note">券面抵扣按已写明的券规则计算；积分换购与最终金额以门店算价为准。</p>' +
          '</div>'
          : '<div class="empty">本店没有可结算的商品</div>') +
        (settle.unavailableCount
          ? '<div class="cd-off"><div class="cd-off-head">本店无售 ' + settle.unavailableCount + ' 件' +
          '<button class="btn btn-ghost btn-sm" data-drop-off>全部移除</button></div>' +
          '<div class="cd-list">' + offLines + '</div></div>' : '')
        : '<div class="empty">购物车还是空的</div>') +
      '</div>';
  }

  function renderCartBar(settle) {
    var old = $('#cart-bar');
    if (old) {
      var bar = document.createElement('div');
      bar.innerHTML = settleBarHTML(settle);
      old.replaceWith(bar.firstChild);
    }
    var drawerOld = $('#cart-drawer');
    if (drawerOld) {
      var d = document.createElement('div');
      d.innerHTML = cartDrawerHTML(settle);
      drawerOld.replaceWith(d.firstChild);
    }
  }

  /* 事件委托：只绑一次，绑在稳定的 #order-root 上。
     卡片数量控件在 refreshCart 时会被替换，若逐节点绑定会叠加监听器，
     导致一次点击加两份。 */
  var orderDelegated = false;

  function ensureOrderDelegation() {
    var root = $('#order-root');
    if (!root || orderDelegated) return;
    orderDelegated = true;

    root.addEventListener('click', function (evt) {
      var t = evt.target;

      var act = t.closest('[data-act][data-code]');
      if (act) {
        evt.stopPropagation();
        setQty(act.getAttribute('data-code'), act.getAttribute('data-act') === 'plus' ? 1 : -1);
        refreshCart();
        return;
      }

      if (t.closest('[data-clear-query]')) {
        state.query = '';
        renderOrder();
        return;
      }

      if (t.closest('[data-drop-off]')) {
        Object.keys(state.cart).forEach(function (code) {
          var inMenu = false;
          data.menuOf(orderStore().store_code).forEach(function (m) { if (m.code === code) inMenu = true; });
          if (!inMenu) delete state.cart[code];
        });
        refreshCart();
        toast('已移除本店无售的商品');
        return;
      }

      if (t.closest('#cart-toggle')) {
        var drawer = $('#cart-drawer');
        if (drawer) drawer.hidden = !drawer.hidden;
        return;
      }

      if (t.closest('#cart-close')) {
        var d = $('#cart-drawer');
        if (d) d.hidden = true;
        return;
      }

      if (t.closest('#go-checkout')) {
        MCD.router.go('/checkout');
        return;
      }

      var card = t.closest('[data-meal-card]');
      if (card) {
        state.detailCode = card.getAttribute('data-meal-card');
        openDetail(state.detailCode);
      }
    });
  }

  function refreshCart() {
    var store = orderStore();
    var settle = calc.settle(store.store_code);
    renderCartBar(settle);
    // 仅更新卡片上的数量控件，避免整页重绘导致的闪烁
    $$('[data-meal-card]', $('#order-root')).forEach(function (card) {
      var code = card.getAttribute('data-meal-card');
      var qty = state.cart[code] || 0;
      card.classList.toggle('is-on', qty > 0);
      var foot = card.querySelector('.meal-foot');
      var meal = null;
      data.menuOf(store.store_code).forEach(function (m) { if (m.code === code) meal = m; });
      if (!meal || !foot) return;
      foot.innerHTML = '<span class="meal-price"><b>' + yuan(meal.price) + '</b>' +
        (meal.original_price > meal.price ? '<s>' + yuan(meal.original_price) + '</s>' : '') + '</span>' +
        (qty
          ? '<span class="qty"><button data-act="minus" data-code="' + esc(code) + '">−</button>' +
          '<span>' + qty + '</span><button data-act="plus" data-code="' + esc(code) + '">+</button></span>'
          : '<button class="btn btn-round" data-act="plus" data-code="' + esc(code) + '" aria-label="加入">＋</button>');
    });
    // 无需重新绑定：所有交互都由 #order-root 上的事件委托统一处理
  }

  /* ------------------------------------------------------------ 商品详情弹窗 */
  function openDetail(code) {
    var store = orderStore();
    var meal = null;
    data.menuOf(store.store_code).forEach(function (m) { if (m.code === code) meal = m; });
    if (!meal) meal = data.mealByCode(code);
    if (!meal) return;

    var comp = data.compositionOf(code);
    var nut = meal.nutrition || null;
    var qty = state.cart[code] || 0;

    var compHtml = '';
    if (comp && comp.rounds && comp.rounds.length) {
      compHtml += '<div class="section-title">套餐组成<em class="src-tag">来源：MCP query-meal-detail</em></div>';
      compHtml += comp.rounds.map(function (r) {
        var chosen = r.choices.filter(function (c) { return c.is_default; });
        return '<div class="comp-round"><div class="comp-head"><strong>' + esc(r.name) + '</strong>' +
          '<span>任选 ' + r.quantity + ' 项</span></div>' +
          '<div class="comp-chosen">' + (chosen.length
            ? chosen.map(function (c) { return '<span class="chip is-on">' + esc(c.name) + '</span>'; }).join('')
            : '<span class="chip">—</span>') + '</div>' +
          '<div class="comp-options">' + r.choices.slice(0, 10).map(function (c) {
            return '<span class="chip' + (c.is_default ? ' is-default' : '') + '">' + esc(c.name) +
              (c.diff && c.diff !== '+ ¥0' ? '<em>' + esc(c.diff) + '</em>' : '') + '</span>';
          }).join('') + (r.choices.length > 10 ? '<span class="chip is-muted">等 ' + r.choices.length + ' 项</span>' : '') +
          '</div></div>';
      }).join('');
    } else if (comp && comp.modifiers && comp.modifiers.length) {
      compHtml += '<div class="section-title">配料（可特调）<em class="src-tag">来源：MCP query-meal-detail</em></div>';
      compHtml += comp.modifiers.map(function (m) {
        return '<div class="comp-round"><div class="comp-options">' + m.values.map(function (v) {
          return '<span class="chip is-default">' + esc(v) + '</span>';
        }).join('') + '</div></div>';
      }).join('');
    } else {
      compHtml += '<div class="notice notice-info"><span class="notice-icon">ℹ️</span>' +
        '<span>该餐品的组成信息未从 MCP 取到（本项目只对部分套餐做了组成抓取），' +
        '配料与规格请以门店出餐为准。</span></div>';
    }

    var nutHtml = '';
    if (nut) {
      var src = nut.match === 'exact' ? '官方营养表'
        : (nut.match === 'computed' ? '按官方组成累加' : '同类餐品参考值');
      nutHtml += '<div class="section-title">营养信息<em class="src-tag">来源：MCP list-nutrition-foods · ' + src + '</em></div>';
      nutHtml += '<div class="nut-grid">' +
        nutCell('热量', Math.round(nut.kcal), '千卡', true) +
        nutCell('蛋白质', nut.protein, 'g') +
        nutCell('脂肪', nut.fat, 'g') +
        nutCell('碳水', nut.carb, 'g') +
        nutCell('钠', nut.sodium, 'mg') +
        nutCell('钙', nut.calcium, 'mg') +
        '</div>';
      if (nut.match === 'computed' && nut.components) {
        nutHtml += '<p class="nut-note">按官方组成累加：' + esc(nut.components.join(' + ')) + '</p>';
      }
      if (nut.match !== 'exact') {
        nutHtml += '<p class="nut-note">非官方逐项原值，仅供参考。</p>';
      }
      if (nut.note) nutHtml += '<p class="nut-note">官方说明：' + esc(nut.note) + '</p>';
    } else {
      nutHtml += '<div class="section-title">营养信息</div>' +
        '<div class="notice notice-info"><span class="notice-icon">ℹ️</span>' +
        '<span>官方营养表未收录该餐品（套餐类通常没有独立条目），因此不展示热量以免误导。</span></div>';
    }

    var html = '<div class="modal-mask" id="meal-modal">' +
      '<div class="modal-card" role="dialog" aria-modal="true">' +
      '<button class="modal-close" id="modal-close" aria-label="关闭">✕</button>' +
      '<div class="modal-hero">' + img(meal.image, 'modal-img', meal.name) + '</div>' +
      '<div class="modal-body">' +
      '<h3 class="modal-name">' + esc(meal.name) + '</h3>' +
      '<div class="modal-price"><b>' + yuan(meal.price) + '</b>' +
      (meal.original_price > meal.price ? '<s>' + yuan(meal.original_price) + '</s>' : '') +
      (meal.saving > 0 ? '<span class="tag is-green">省 ' + yuan(meal.saving) + '</span>' : '') +
      (meal.discount_type ? '<span class="tag">' + esc(meal.discount_type) + '</span>' : '') +
      (data.isFavorite(meal.name) ? '<span class="tag is-fav">你常点</span>' : '') +
      '</div>' +
      '<p class="modal-desc">' + esc(meal.desc || '') + '</p>' +
      (meal.tags && meal.tags.length
        ? '<div class="chips">' + meal.tags.map(function (t) { return '<span class="chip">' + esc(t) + '</span>'; }).join('') + '</div>'
        : '') +
      nutHtml +
      compHtml +
      '<p class="modal-code">餐品码 ' + esc(meal.code) + ' · 门店 ' + esc(store.name) + '</p>' +
      '</div>' +
      '<div class="modal-foot">' +
      '<span class="qty qty-lg"><button data-modal="minus">−</button><span id="modal-qty">' + qty + '</span>' +
      '<button data-modal="plus">＋</button></span>' +
      '<button class="btn btn-primary btn-pay" id="modal-add">' +
      (qty ? '更新购物车 · ' + yuan(meal.price * qty) : '加入购物车 · ' + yuan(meal.price)) + '</button>' +
      '</div></div></div>';

    openDialog(html, function (host) {
      var local = qty;
      function syncFoot() {
        $('#modal-qty').textContent = local;
        $('#modal-add').textContent = local
          ? '更新购物车 · ' + yuan(meal.price * local)
          : '加入购物车 · ' + yuan(meal.price);
      }
      $$('[data-modal]', host).forEach(function (b) {
        b.addEventListener('click', function () {
          local = Math.max(0, local + (b.getAttribute('data-modal') === 'plus' ? 1 : -1));
          syncFoot();
        });
      });
      $('#modal-add').addEventListener('click', function () {
        if (local > 0) state.cart[code] = local; else delete state.cart[code];
        state.detailCode = null;
        closeDialog();
        refreshCart();
        toast(local > 0 ? '已加入购物车：' + meal.name + ' ×' + local : '已从购物车移除：' + meal.name);
      });
    });
  }

  function nutCell(label, value, unit, highlight) {
    return '<div class="nut-cell' + (highlight ? ' is-hl' : '') + '">' +
      '<b>' + (value == null ? '—' : Math.round(Number(value) * 10) / 10) + '<em>' + unit + '</em></b>' +
      '<span>' + label + '</span></div>';
  }

  function closeDetail() {
    state.detailCode = null;
    closeDialog();
  }

  /* ==========================================================================
     结算页
     —— 左栏：取餐门店 / 商品清单 / 优惠与积分
        右栏（桌面端吸顶）：金额明细，底部固定条保留总额与提交入口
     ========================================================================== */
  function renderCheckout() {
    var store = orderStore();
    if (!store) { $('#checkout-root').innerHTML = '<div class="empty">没有可用门店数据</div>'; return; }
    var settle = calc.settle(store.store_code);
    if (!settle.count) {
      $('#checkout-root').innerHTML =
        '<div class="page-head"><button class="btn btn-ghost btn-back" data-back>← 返回点餐</button>' +
        '<h2>确认订单</h2></div>' +
        '<div class="empty">购物车是空的，先去点餐页挑点吃的吧。</div>';
      bindBack($('#checkout-root'), '/order');
      return;
    }
    var row = storeRow(store.store_code) || {};
    var travel = row.travel_minutes != null ? row.travel_minutes : 10;
    var queue = row.queue_minutes != null ? row.queue_minutes : 5;
    var arrive = new Date(Date.now() + travel * 60000);
    var ready = new Date(Date.now() + (travel + queue) * 60000);

    var html = '<div class="page-head">' +
      '<button class="btn btn-ghost btn-back" data-back>← 返回点餐</button>' +
      '<h2>确认订单</h2>' +
      '<span class="pill-demo">演示流程 · 不会真实下单</span></div>' +

      '<div class="co-layout"><div class="co-main">' +

      '<section class="card">' +
      '<div class="card-head"><h3>取餐门店</h3>' +
      '<button class="btn btn-outline btn-sm" id="co-switch">⇄ 换一家</button></div>' +
      '<div class="card-body">' +
      '<div class="co-store"><strong>' + esc(store.name) + '</strong>' +
      '<span>' + esc(store.address) + '</span></div>' +
      '<dl class="kv">' +
      '<dt>取餐方式</dt><dd>' + esc(DINING_LABEL[state.dining]) + ' · ' + esc(store.be_type_label) + '</dd>' +
      '<dt>预计到达</dt><dd>' + clock(arrive) + '（' + esc(row.travel_label || '') + '约 ' + travel + ' 分钟）</dd>' +
      '<dt>预计可取</dt><dd>' + clock(ready) + '（含预估等待 ' + queue + ' 分钟）</dd>' +
      '<dt>门店编号</dt><dd>' + esc(store.store_code) + '</dd>' +
      '</dl></div></section>' +

      '<section class="card">' +
      '<div class="card-head"><h3>商品清单</h3><span>' + settle.count + ' 件' +
      (settle.unavailableCount ? ' · 本店无售 ' + settle.unavailableCount + ' 件' : '') + '</span></div>' +
      '<div class="card-body">' +
      settle.items.map(function (i) {
        return '<div class="cd-row">' + img(i.image, 'cd-thumb') +
          '<div class="cd-info"><div class="cd-name">' + esc(i.name) + '</div>' +
          '<div class="cd-sub">' + yuan(i.price) + ' × ' + i.qty +
          (i.kcal ? ' · ' + Math.round(i.kcal * i.qty) + ' 千卡' : '') + '</div></div>' +
          '<span class="cd-sum">' + yuan(i.price * i.qty) + '</span></div>';
      }).join('') +
      (settle.unavailableCount
        ? '<div class="notice notice-warn"><span class="notice-icon">⚠️</span>' +
        '<span>购物车里有 ' + settle.unavailableCount + ' 件商品本店不售（' +
        esc(settle.unavailable.map(function (i) { return i.name; }).join('、')) +
        '），已从金额中剔除。可点上方「换一家」切到有售门店。</span></div>' : '') +
      '</div></section>' +

      '<section class="card">' +
      '<div class="card-head"><h3>优惠与积分</h3>' +
      '<label class="switch"><input type="checkbox" id="use-coupons"' + (state.useCoupons ? ' checked' : '') + '><span></span>使用优惠券</label>' +
      '</div><div class="card-body">' +
      couponBlock(settle) +
      pointsBlock(settle) +
      '</div></section>' +

      '</div><aside class="co-aside">' +

      '<section class="card co-summary">' +
      '<div class="card-head"><h3>金额明细</h3></div>' +
      '<div class="card-body">' +
      '<div class="cd-line"><span>商品小计</span><b>' + yuan(settle.subtotal) + '</b></div>' +
      (settle.original > settle.subtotal
        ? '<div class="cd-line is-muted"><span>门店划线价合计</span><b>' + yuan(settle.original) + '</b></div>' : '') +
      settle.couponLines.map(function (l) {
        return '<div class="cd-line"><span>🎟️ ' + esc(l.title) + '<em>（' + esc(l.source) + '，作用于' + esc(l.on_item) + '）</em></span>' +
          '<b>- ' + yuan(l.amount) + '</b></div>';
      }).join('') +
      (settle.chosenOffer
        ? '<div class="cd-line"><span>🎁 ' + esc(settle.chosenOffer.name) + '<em>（' + settle.chosenOffer.point + ' 积分 + ¥' +
        settle.chosenOffer.cash + '）</em></span><b>- ' + yuan(settle.pointsTotal) + '</b></div>' : '') +
      '<div class="cd-line is-total"><span>预计实付</span><b>' + yuan(settle.payable) + '</b></div>' +
      (settle.crossStoreSaved > 0
        ? '<div class="co-save">较门店价省 ' + yuan(settle.crossStoreSaved) + '</div>' : '') +
      '<p class="cd-note">券面抵扣按券标题已写明的规则计算，最终金额以门店算价为准。</p>' +
      '</div></section>' +

      '</aside></div>' +

      '<div class="checkout-bar">' +
      '<div class="cb-left"><span>' + esc(DINING_LABEL[state.dining]) + ' · ' + settle.count + ' 件 · ' +
      esc(store.name.replace(/^麦当劳/, '')) + '</span>' +
      '<b>' + yuan(settle.payable) + '</b></div>' +
      '<button class="btn btn-primary btn-pay" id="submit-order">提交订单</button>' +
      '</div>';

    $('#checkout-root').innerHTML = html;
    bindBack($('#checkout-root'), '/order');

    $('#co-switch').addEventListener('click', function () {
      openStoreSwitch(function () { renderCheckout(); });
    });

    var sw = $('#use-coupons');
    if (sw) sw.addEventListener('change', function () {
      state.useCoupons = sw.checked;
      renderCheckout();
    });
    $$('[data-offer]', $('#checkout-root')).forEach(function (b) {
      b.addEventListener('click', function () {
        var id = parseInt(b.getAttribute('data-offer'), 10);
        state.pointsSpuId = state.pointsSpuId === id ? null : id;
        renderCheckout();
      });
    });
    $('#submit-order').addEventListener('click', function () { submitOrder(settle, store, row); });
  }

  function couponBlock(settle) {
    var all = calc.couponsFor();
    var html = '<div class="section-title">优惠券<em class="src-tag">来源：MCP query-store-coupons / available-coupons</em></div>';
    if (!all.length) return html + '<div class="empty">暂无可用券</div>';

    if (!state.useCoupons) {
      return html + '<div class="notice notice-info"><span class="notice-icon">ℹ️</span>' +
        '<span>已关闭用券。当前共 ' + all.length + ' 张券可用。</span></div>';
    }

    var usedCodes = {};
    settle.couponLines.forEach(function (l) { usedCodes[l.code] = true; });
    var unknownTitles = {};
    settle.couponUnknown.forEach(function (a) { unknownTitles[a.coupon.coupon_code || a.coupon.title] = true; });

    html += '<div class="coupon-list">' + all.map(function (c) {
      var key = c.coupon_code || c.title;
      var st = usedCodes[key] ? 'used' : (unknownTitles[key] ? 'unknown' : 'idle');
      var label = st === 'used' ? '已使用' : (st === 'unknown' ? '可用于部分商品' : '暂未匹配到商品');
      var amount = st === 'used'
        ? '-' + yuan((settle.couponLines.filter(function (l) { return l.code === key; })[0] || {}).amount || 0)
        : '';
      return '<div class="coupon-card is-' + st + '">' +
        '<div class="cc-main"><b>' + esc(c.title) + '</b>' +
        '<span>' + esc(c.source) + (c.face_price != null ? ' · 券面价 ¥' + c.face_price : '') +
        (c.valid_to ? ' · 有效期至 ' + esc(String(c.valid_to).slice(0, 10)) : '') + '</span></div>' +
        '<div class="cc-side"><em>' + esc(label) + '</em>' + (amount ? '<b>' + amount + '</b>' : '') + '</div>' +
        '</div>';
    }).join('') + '</div>';

    if (settle.couponTotal > 0) {
      html += '<div class="notice notice-ok"><span class="notice-icon">✅</span><span>已自动为你选用最划算的 ' +
        settle.couponLines.length + ' 张券，共抵扣 ' + yuan(settle.couponTotal) + '。</span></div>';
    } else {
      html += '<div class="notice notice-info"><span class="notice-icon">ℹ️</span>' +
        '<span>当前购物车里的商品没有可计算金额的券。标题未写明价格的券（如「麦旋风任选」）需下单时由门店核销，本页不预估。</span></div>';
    }
    return html;
  }

  function pointsBlock(settle) {
    var acc = data.account();
    var balance = Number(acc.available_points || 0);
    var html = '<div class="section-title">积分换购<em class="src-tag">来源：MCP mall-points-products</em></div>';

    html += '<div class="points-head">' +
      '<div class="ph-balance"><b>' + yuan(balance, false) + '</b><span>' + esc(acc.unit || '积分') + '可用</span></div>' +
      '<p class="ph-note">麦当劳积分用于「积分 + 指定金额」换购，<strong>不是直接折现</strong>；' +
      '下表按单份计价，列出换购后实际能省多少。</p>' +
      '</div>';

    var canUse = settle.offers.filter(function (o) { return o.affordable; });
    var miss = settle.offers.filter(function (o) { return !o.affordable; });

    if (!settle.offers.length) {
      return html + '<div class="empty">购物车里暂时没有能用积分换购的商品</div>';
    }

    if (!canUse.length) {
      html += '<div class="notice notice-info"><span class="notice-icon">ℹ️</span>' +
        '<span>购物车里有可换购的商品，但积分还不够。下方列出了还差多少。</span></div>';
    }

    html += '<div class="offer-list">' + canUse.map(function (o) {
      var on = state.pointsSpuId === o.spu_id;
      return '<div class="offer-card' + (on ? ' is-on' : '') + '">' +
        img(o.image, 'offer-thumb') +
        '<div class="offer-main"><b>' + esc(o.name) +
        (o.from_history ? '<span class="badge is-fav">你常点</span>' : '') + '</b>' +
        '<span>' + o.point + ' 积分 + ¥' + o.cash + ' · 覆盖 ' + esc(o.covered_names.join('、')) + '</span></div>' +
        '<div class="offer-side"><b>省 ' + yuan(o.saving) + '</b>' +
        '<button class="btn btn-outline btn-sm" data-offer="' + o.spu_id + '">' + (on ? '取消' : '采用') + '</button></div>' +
        '</div>';
    }).join('') + '</div>';

    if (miss.length) {
      html += '<div class="offer-miss"><div class="offer-miss-head">积分不足，再攒一点就能换</div>' +
        miss.slice(0, 4).map(function (o) {
          return '<div class="offer-miss-row"><span>' + esc(o.name) + '</span>' +
            '<em>需 ' + o.point + ' 积分 · 还差 ' + yuan(o.shortfall, false) + '</em></div>';
        }).join('') + '</div>';
    }
    return html;
  }

  function bindBack(root, path) {
    $$('[data-back]', root).forEach(function (b) {
      b.addEventListener('click', function () { MCD.router.go(path); });
    });
  }

  /* ==========================================================================
     下单成功页
     —— 状态时间轴 + 取消订单（已出餐不可取消）
     ========================================================================== */
  function submitOrder(settle, store, row) {
    var travel = row && row.travel_minutes != null ? row.travel_minutes : 10;
    var queue = row && row.queue_minutes != null ? row.queue_minutes : 5;
    var now = Date.now();
    var arriveTs = now + travel * 60000;
    var readyTs = now + (travel + queue) * 60000;

    state.orderCancelled = false;
    state.demoReady = false;
    state.order = {
      order_no: 'MCD' + String(now).slice(-10),
      pickup_no: 'A' + String(Math.floor(100 + Math.random() * 899)),
      store_code: store.store_code,
      store_name: store.name,
      address: store.address,
      dining: state.dining,
      count: settle.count,
      payable: settle.payable,
      saved: settle.crossStoreSaved,
      coupon_lines: settle.couponLines,
      points_offer: settle.chosenOffer,
      travel_minutes: travel,
      queue_minutes: queue,
      place_ts: now,
      arrive_ts: arriveTs,
      ready_ts: readyTs,
      arrive_at: clockOf(arriveTs),
      ready_at: clockOf(readyTs),
      created_at: new Date(now).toLocaleString('zh-CN', { hour12: false })
    };
    MCD.router.go('/result');
  }

  /** 订单当前阶段：placed（刚下单）→ preparing（制作中）→ ready（已出餐）/ cancelled。 */
  function orderStage(order) {
    if (state.orderCancelled) return 'cancelled';
    if (state.demoReady) return 'ready';
    var now = Date.now();
    if (now >= order.ready_ts) return 'ready';
    if (now >= order.place_ts + CANCEL_WINDOW_MS) return 'preparing';
    return 'placed';
  }

  var STAGE_TEXT = {
    placed: { label: '已下单', tip: '门店还在接单，此时取消不产生费用' },
    preparing: { label: '制作中', tip: '门店已接单并开始制作，取消需门店确认' },
    ready: { label: '已出餐', tip: '餐品已做好，不能再取消' },
    cancelled: { label: '已取消', tip: '订单已取消，未产生费用' }
  };

  function statusTrackHTML(order, stage) {
    var steps = ['placed', 'preparing', 'ready'];
    var order_ = stage === 'cancelled' ? ['cancelled'] : steps;
    var idx = order_.indexOf(stage);

    return '<section class="order-status is-' + stage + '">' +
      '<div class="os-head"><span class="os-pill">' + esc(STAGE_TEXT[stage].label) + '</span>' +
      '<span class="os-tip">' + esc(STAGE_TEXT[stage].tip) + '</span></div>' +
      '<div class="os-track">' +
      (stage === 'cancelled'
        ? '<div class="os-step is-current"><i></i><b>已取消</b><span>' + esc(clockOf(Date.now())) + '</span></div>'
        : steps.map(function (s, i) {
          var cls = i < idx ? 'is-done' : (i === idx ? 'is-current' : '');
          var when = s === 'placed' ? esc(clockOf(order.place_ts))
            : (s === 'ready' ? '预计 ' + esc(order.ready_at) : '预计 ' + esc(order.arrive_at) + ' 起');
          return '<div class="os-step ' + cls + '"><i></i><b>' + esc(STAGE_TEXT[s].label) + '</b><span>' + when + '</span></div>';
        }).join('')) +
      '</div></section>';
  }

  function renderResult() {
    var order = state.order;
    if (!order) { MCD.router.go('/'); return; }
    var stage = orderStage(order);
    var canCancel = stage === 'placed' || stage === 'preparing';

    var html = '<div class="page-head">' +
      '<button class="btn btn-ghost btn-back" data-back>← 返回地图</button>' +
      '<h2>' + (stage === 'cancelled' ? '订单已取消' : '订单已提交') + '</h2>' +
      '<span class="pill-demo">演示订单 · 未真实下单</span></div>' +

      '<section class="result-hero' + (stage === 'cancelled' ? ' is-cancelled' : '') + '">' +
      '<div class="rh-badge">' + (stage === 'cancelled' ? '订单状态' : '取餐号') + '</div>' +
      '<div class="rh-number">' + (stage === 'cancelled' ? '已取消' : esc(order.pickup_no)) + '</div>' +
      '<div class="rh-sub">' + esc(order.store_name) + ' · ' + esc(DINING_LABEL[order.dining]) + '</div>' +
      '<div class="rh-meta">订单号 ' + esc(order.order_no) + ' · 下单时间 ' + esc(order.created_at) + '</div>' +
      '</section>' +

      statusTrackHTML(order, stage) +

      '<div class="co-layout"><div class="co-main">' +

      '<section class="card">' +
      '<div class="card-head"><h3>取餐信息</h3></div><div class="card-body">' +
      '<dl class="kv">' +
      '<dt>预计到达</dt><dd>' + esc(order.arrive_at) + '（约 ' + order.travel_minutes + ' 分钟）</dd>' +
      '<dt>预计可取</dt><dd>' + esc(order.ready_at) + '</dd>' +
      '<dt>取餐门店</dt><dd>' + esc(order.store_name) + '</dd>' +
      '<dt>门店地址</dt><dd class="is-wrap">' + esc(order.address) + '</dd>' +
      '<dt>本次应付</dt><dd>' + yuan(order.payable) + (order.saved > 0 ? '（省 ' + yuan(order.saved) + '）' : '') + '</dd>' +
      '<dt>商品件数</dt><dd>' + order.count + ' 件</dd>' +
      '</dl>' +
      (order.coupon_lines.length
        ? '<div class="notice notice-ok"><span class="notice-icon">🎟️</span><span>已用券：' +
        esc(order.coupon_lines.map(function (l) { return l.title; }).join('、')) + '</span></div>' : '') +
      (order.points_offer
        ? '<div class="notice notice-ok"><span class="notice-icon">🎁</span><span>积分换购：' +
        esc(order.points_offer.name) + '（' + order.points_offer.point + ' 积分 + ¥' + order.points_offer.cash + '）</span></div>' : '') +
      '</div></section>' +

      '</div><aside class="co-aside">' +
      '<section class="card">' +
      '<div class="card-head"><h3>前往餐厅路线</h3><span class="src-tag">腾讯地图</span></div>' +
      '<div class="card-body no-pad">' +
      '<div id="route-map" class="route-map"></div>' +
      '<div id="route-fallback" class="route-fallback" hidden>' +
      '<div class="rf-line"><span class="rf-dot"></span><b>我的位置</b><i></i><span class="rf-dot is-store"></span><b>' +
      esc(String(order.store_name).replace(/^麦当劳/, '')) + '</b></div>' +
      '<p>地图服务未就绪（离线打开或未配置腾讯地图 Key），已用上方行程示意代替。' +
      '导航请以门店地址为准。</p>' +
      '</div></div></section>' +
      '</aside></div>' +

      '<div class="notice notice-warn result-warn"><span class="notice-icon">⚠️</span><span>' +
      '这是<strong>演示订单</strong>：本项目只调用麦当劳 MCP 的只读接口，不会真实下单或扣款。' +
      '下方「取消订单」同样只是本地演示状态，不会向任何服务端发起撤单请求。</span></div>' +

      '<div class="result-actions">' +
      '<button class="btn btn-danger" id="cancel-btn"' + (canCancel ? '' : ' disabled') + '>' +
      (stage === 'cancelled' ? '订单已取消' : (canCancel ? '取消订单' : '已出餐 · 不可取消')) + '</button>' +
      '<button class="btn btn-outline" id="demo-ready-btn">' +
      (state.demoReady ? '↺ 恢复为制作中' : '⏩ 演示：模拟已出餐') + '</button>' +
      '<button class="btn btn-primary" id="again-btn">再来一单</button>' +
      '<button class="btn btn-outline" id="home-btn">回到雷达地图</button>' +
      '</div>' +

      (stage === 'ready'
        ? '<div class="notice notice-warn result-warn"><span class="notice-icon">🍟</span>' +
        '<span>餐品已出餐（' + esc(order.ready_at) + '），订单进入不可取消状态。请尽快到柜台或取餐屏取餐。</span></div>'
        : '');

    $('#result-root').innerHTML = html;
    bindBack($('#result-root'), '/');

    var cancelBtn = $('#cancel-btn');
    if (cancelBtn) cancelBtn.addEventListener('click', function () {
      if (!canCancel) { toast('订单已出餐，无法取消'); return; }
      openCancelDialog(order);
    });

    $('#demo-ready-btn').addEventListener('click', function () {
      state.demoReady = !state.demoReady;
      renderResult();
      toast(state.demoReady ? '已模拟出餐：此时取消按钮会被拦截' : '已恢复为制作中状态');
    });

    $('#again-btn').addEventListener('click', function () { MCD.router.go('/order'); });
    $('#home-btn').addEventListener('click', function () { MCD.router.go('/'); });

    var ready = MCD.routeMap.available();
    if (ready) {
      MCD.routeMap.show('route-map', order.store_code).then(function (ok) {
        if (!ok) fallbackRoute();
      }).catch(function () { fallbackRoute(); });
    } else {
      fallbackRoute();
    }
    function fallbackRoute() {
      var box = $('#route-map');
      var fb = $('#route-fallback');
      if (box) box.style.display = 'none';
      if (fb) fb.hidden = false;
    }
  }

  function openCancelDialog(order) {
    var html = '<div class="modal-mask" id="cancel-modal">' +
      '<div class="modal-card dialog-card" role="dialog" aria-modal="true">' +
      '<button class="modal-close" id="modal-close" aria-label="关闭">✕</button>' +
      '<div class="modal-body">' +
      '<h3 class="modal-name">确认取消这单？</h3>' +
      '<p class="modal-desc">订单 ' + esc(order.order_no) + ' · ' + order.count + ' 件 · ' +
      yuan(order.payable) + '<br>' +
      '取消后取餐号 ' + esc(order.pickup_no) + ' 作废。餐品已开始制作时，实际能否取消以门店确认为准。</p>' +
      '<div class="notice notice-warn"><span class="notice-icon">⚠️</span>' +
      '<span>演示环境：这一步只是把本地订单状态置为「已取消」，不会调用 MCP 的 <code>cancel-order</code>。</span></div>' +
      '</div>' +
      '<div class="modal-foot">' +
      '<button class="btn btn-outline" id="cancel-no">再想想</button>' +
      '<button class="btn btn-danger" id="cancel-yes">确认取消订单</button>' +
      '</div></div></div>';

    openDialog(html, function (host) {
      var no = $('#cancel-no', host);
      if (no) no.addEventListener('click', closeDialog);
      var yes = $('#cancel-yes', host);
      if (yes) yes.addEventListener('click', function () {
        state.orderCancelled = true;
        closeDialog();
        renderResult();
        toast('订单已取消（演示）');
      });
    });
  }

  /* ==========================================================================
     活动详情页
     ========================================================================== */
  /** 预计抵达时刻 = 此刻出发 + 耗时（模型估值，非实时路况）。 */
  function arriveTime(minutes) {
    return clock(new Date(Date.now() + Math.max(0, minutes || 0) * 60000));
  }

  /** 出行方式小标：步行 + 驾车必给，骑行只在「本次推荐」时补上，避免三个抢视线。 */
  function travelChips(row) {
    var opts = row.travel_options || [];
    if (!opts.length) {
      if (row.travel_minutes == null) return '';
      return '<span class="tv"><em>' + esc(row.travel_label || '出发') + '</em><b>' +
        row.travel_minutes + ' 分钟</b><i>' + arriveTime(row.travel_minutes) + ' 到店</i></span>';
    }
    return opts.filter(function (o) {
      return o.mode === 'walk' || o.mode === 'drive' || o.recommended;
    }).map(function (o) {
      return '<span class="tv' + (o.recommended ? ' is-best' : '') + '">' +
        '<em>' + esc(o.label) + '</em><b>' + o.minutes + ' 分钟</b>' +
        '<i>' + arriveTime(o.minutes) + ' 到店</i></span>';
    }).join('');
  }

  /** 「本地区可参与门店」：活动的地区落地 —— 门店地点 + 距离 + 步行/驾车 + 抵达时间。 */
  function regionStoreListHtml(act) {
    var modes = MCD.DATA.modes || {};
    var rows = (modes.nearby_distance && modes.nearby_distance.stores) || [];
    if (!rows.length) return '';

    var city = MCD.DATA.city || '';
    var kw = MCD.DATA.keyword || '';
    var carried = {};
    (act.products || []).forEach(function (p) {
      (p.stores || []).forEach(function (c) { carried[c] = true; });
    });
    var matched = (act.products || []).length > 0;

    var list = rows.slice(0, 5).map(function (r) {
      var has = !!carried[r.store_code];
      return '<article class="astore">' +
        '<div class="as-head"><span class="as-name">' + esc(r.name) + '</span>' +
        '<span class="as-dist">' + esc(r.distance_label || util.distLabel(r.distance)) + '</span></div>' +
        '<div class="as-addr">' + esc(r.address) + '</div>' +
        '<div class="as-travel">' + travelChips(r) +
        '<span class="tv is-queue"><em>取餐等待*</em><b>约 ' + (r.queue_minutes || 0) + ' 分钟</b>' +
        '<i>' + arriveTime(r.total_minutes) + ' 到手</i></span></div>' +
        (matched
          ? '<div class="as-tag' + (has ? ' is-ok' : '') + '">' +
            (has ? '✅ 该店菜单含活动商品' : '该店菜单未匹配到活动商品') + '</div>'
          : '') +
        '<div class="as-actions"><button class="btn btn-primary btn-sm" data-go-store="' +
        esc(r.store_code) + '">去这家点餐</button></div>' +
        '</article>';
    }).join('');

    return '<section class="card activity-stores"><div class="card-head">' +
      '<h3>本地区可参与门店</h3>' +
      '<span>当前定位：' + esc(city) + (kw ? ' · ' + esc(kw) : '') + '</span></div>' +
      '<div class="card-body">' +
      '<p class="as-lead">活动本身是全国性的；下面是<b>你当前定位范围内</b>的门店，' +
      '按距离排序给出距离、步行 / 驾车耗时与预计抵达时间（按此刻出发推算）。' +
      '换个地点（上方定位框搜地点）整页会一起同步。</p>' +
      list +
      '<p class="as-note">带 * 的耗时与等待为按时段客流 + 门店因子推演的模型估值，非实时路况 / 排队数据。</p>' +
      '</div></section>';
  }

  function renderActivity(index) {
    var act = data.activityAt(index);
    if (!act) { MCD.router.go('/'); return; }
    var list = data.activities();
    var prev = list[act.index - 1];
    var next = list[act.index + 1];

    var when = act.is_today ? '今天' :
      (act.days_until === 1 ? '明天' : (act.days_until > 1 ? act.days_until + ' 天后' : (act.date || '')));

    var html = '<div class="page-head">' +
      '<button class="btn btn-ghost btn-back" data-back>← 返回地图</button>' +
      '<h2>活动详情</h2>' +
      '<span class="pill-demo">' + (act.is_gift ? '限时周边' : '营销活动') + '</span></div>' +

      '<article class="activity-detail">' +
      '<div class="ad-media">' + img(act.image, 'ad-img', act.title) + '</div>' +
      '<div class="ad-panel">' +
      '<div class="ad-when"><span class="act-date' + (act.is_today ? ' is-today' : '') + '">' +
      esc((act.date_label || '') + ' · ' + when) + '</span>' +
      (act.weekday ? '<span class="ad-week">' + esc(act.weekday) + '</span>' : '') + '</div>' +
      '<h1 class="ad-title">' + esc(act.title) + '</h1>' +
      '<div class="ad-body">' + esc(act.body || '').replace(/\n/g, '<br>') + '</div>' +
      ((act.launch_tags && act.launch_tags.length) || act.is_gift
        ? '<div class="chips">' +
        (act.is_gift ? '<span class="badge is-warn">限时周边</span>' : '') +
        (act.launch_tags || []).map(function (t) { return '<span class="badge is-info">' + esc(t) + '</span>'; }).join('') +
        '</div>' : '') +
      '<p class="ad-src">来源：麦当劳 MCP <code>campaign-calendar</code> · 活动日期 ' + esc(act.date || '—') + '</p>' +
      '</div></article>';

    if (act.products && act.products.length) {
      html += '<section class="card activity-products"><div class="card-head"><h3>活动关联餐品</h3>' +
        '<span>可与「追新」模式交叉比对门店在售情况</span></div><div class="card-body">' +
        act.products.map(function (p) {
          var storeNames = (p.stores || []).map(function (c) {
            var s = data.storeByCode(c);
            return s ? s.name.replace(/^麦当劳/, '').replace(/餐厅$/, '') : c;
          });
          return '<div class="prod-row is-clickable" data-order-meal="' + esc(p.name) + '">' + img(p.image, 'prod-thumb') +
            '<div class="prod-info"><div class="prod-name">' + esc(p.name) + '</div>' +
            '<div class="prod-sub">' + (p.partial
              ? '仅 ' + p.store_count + ' 家店在售：' + esc(storeNames.join('、'))
              : '全部 ' + p.store_count + ' 家店在售') + '</div></div>' +
            '<div class="prod-price"><b>' + yuan(p.price) + '</b>' +
            (p.original_price > p.price ? '<s>' + yuan(p.original_price) + '</s>' : '') + '</div>' +
            '<button class="btn btn-primary btn-sm">去点餐</button>' +
            '</div>';
        }).join('') +
        '</div></section>';
    }

    html += regionStoreListHtml(act);

    html += '<div class="activity-nav">' +
      (prev ? '<button class="btn btn-outline" data-goto="' + prev.index + '">← ' + esc(prev.title.slice(0, 14)) + '</button>'
        : '<span></span>') +
      '<button class="btn btn-primary" data-order-cta>现在就点这份活动餐</button>' +
      (next ? '<button class="btn btn-outline" data-goto="' + next.index + '">' + esc(next.title.slice(0, 14)) + ' →</button>'
        : '<span></span>') +
      '</div>';

    $('#activity-root').innerHTML = html;
    bindBack($('#activity-root'), '/');

    $$('[data-goto]', $('#activity-root')).forEach(function (b) {
      b.addEventListener('click', function () { MCD.router.go('/activity/' + b.getAttribute('data-goto')); });
    });
    $$('[data-order-meal]', $('#activity-root')).forEach(function (node) {
      node.addEventListener('click', function () {
        MCD.state.query = node.getAttribute('data-order-meal');
        MCD.router.go('/order');
      });
    });
    $$('[data-go-store]', $('#activity-root')).forEach(function (node) {
      node.addEventListener('click', function () {
        MCD.state.storeCode = node.getAttribute('data-go-store');
        MCD.state.query = '';
        MCD.router.go('/order');
      });
    });
    var cta = $('#activity-root [data-order-cta]');
    if (cta) cta.addEventListener('click', function () {
      MCD.state.query = '';
      MCD.router.go('/order');
    });
  }

  /* ------------------------------------------------------------ 注册 */
  var views = (MCD.views = MCD.views || {});

  views.order = {
    render: function () {
      closeDetail();
      if (!state.storeCode) {
        var stores = data.stores();
        if (stores.length) state.storeCode = stores[0].store_code;
      }
      renderOrder();
    }
  };

  views.checkout = { render: renderCheckout };
  views.result = { render: renderResult };
  views.activity = { render: renderActivity };

  MCD.views.orderApi = {
    toast: toast,
    openDetail: openDetail,
    openStoreSwitch: openStoreSwitch,
    stage: function () { return state.order ? orderStage(state.order) : null; }
  };
})(window.MCD);
