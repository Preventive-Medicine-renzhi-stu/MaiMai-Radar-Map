/* ==========================================================================
   麦麦雷达地图 —— 首屏登录
   --------------------------------------------------------------------------
   打开页面先弹一个登录框：手机号验证码 / 微信快捷登录。

   ⚠️ 诚实声明（页面里也会写出来）：
     · 本项目**没有**接入麦当劳真实账号体系，也没有短信服务与微信开放平台；
     · 这是在本地完成的**演示登录**：登录态只写进这个浏览器的 localStorage，
       不会向任何地方上传手机号或验证码；
     · 麦当劳 MCP 的 35 个 Tool 里也没有「登录 / 注册 / 手机号」这类接口，
       所以券、积分、历史订单依旧来自 MCP 真实返回的账户数据，不依赖这里的登录。

   提供「暂不登录，先逛逛」，避免把只想看效果的评审挡在门外。
   ========================================================================== */
(function (MCD) {
  'use strict';

  var util = MCD.util;
  var $ = util.$, esc = util.esc;

  var STORE_KEY = 'mcd.auth.v1';
  // 旧版本用 sessionStorage 记「本次会话已跳过」。问题：同一个标签页里刷新
  // 也不会再弹，用户会以为「弹窗坏了 / 不见了」。现在改成**只对当次页面加载生效**
  // 的内存标记 —— 刷新或重新打开就会再次出现，符合「打开网页先弹登录框」的原意。
  var LEGACY_SKIP_KEY = 'mcd.auth.skipped';
  var skippedThisLoad = false;

  var session = null;
  var onChange = null;

  /* ------------------------------------------------------------ 存储 */
  function readStore() {
    try {
      var raw = window.localStorage.getItem(STORE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }

  function writeStore(value) {
    try {
      if (value) window.localStorage.setItem(STORE_KEY, JSON.stringify(value));
      else window.localStorage.removeItem(STORE_KEY);
    } catch (e) { /* 隐私模式等场景：内存态照常工作 */ }
  }

  /** 清理历史遗留：老版本会在 sessionStorage 里留一个跳过标记，把它删掉。 */
  function dropLegacySkip() {
    try { window.sessionStorage.removeItem(LEGACY_SKIP_KEY); } catch (e) { /* 忽略 */ }
  }

  function skippedThisSession() {
    return skippedThisLoad;
  }

  function markSkipped() {
    skippedThisLoad = true;
  }

  /* ------------------------------------------------------------ 会话 */
  var auth = {};

  auth.current = function () {
    if (session === null) session = readStore();
    return session;
  };

  auth.signedIn = function () { return !!auth.current(); };

  /** 手机号打码，避免把完整号码长时间摆在顶栏上。 */
  auth.maskPhone = function (phone) {
    var text = String(phone || '');
    return text.length === 11 ? text.slice(0, 3) + '****' + text.slice(7) : text;
  };

  auth.label = function () {
    var s = auth.current();
    if (!s) return '未登录';
    if (s.type === 'wechat') return '微信用户';
    return auth.maskPhone(s.account);
  };

  /** 顶栏用的展示名。 */
  auth.displayName = function () {
    var s = auth.current();
    if (!s) return '登录 / 注册';
    return s.type === 'wechat' ? '微信用户' : '手机用户';
  };

  auth.avatarChar = function () {
    var s = auth.current();
    if (!s) return '?';
    return s.type === 'wechat' ? '微' : '手';
  };

  auth.onChange = function (fn) { onChange = fn; };

  function setSession(next) {
    session = next;
    writeStore(next);
    if (onChange) { try { onChange(next); } catch (e) { /* 渲染失败不影响登录态 */ } }
  }

  auth.logout = function () {
    setSession(null);
    auth.open('logout');
  };

  /** 供测试 / 高级用法直接注入一个登录态。 */
  auth.signIn = function (payload) { setSession(payload); auth.close(); };

  /* ------------------------------------------------------------ 二维码 */
  /** 画一个「长得像二维码」的确定性图案——它不是真二维码，页面已明确标注。 */
  function qrSvg(seed) {
    var N = 21, cell = 120 / N;
    var h = 2166136261;
    for (var i = 0; i < seed.length; i++) {
      h ^= seed.charCodeAt(i);
      h = (h * 16777619) >>> 0;
    }
    function rnd() {
      h ^= h << 13; h >>>= 0;
      h ^= h >> 17;
      h ^= h << 5; h >>>= 0;
      return h / 4294967296;
    }
    function inFinder(x, y) {
      var boxes = [[0, 0], [N - 7, 0], [0, N - 7]];
      for (var k = 0; k < boxes.length; k++) {
        var bx = boxes[k][0], by = boxes[k][1];
        if (x >= bx - 1 && x <= bx + 7 && y >= by - 1 && y <= by + 7) return true;
      }
      return false;
    }
    function finder(x0, y0) {
      return '<rect x="' + (x0 * cell) + '" y="' + (y0 * cell) + '" width="' + (7 * cell) +
        '" height="' + (7 * cell) + '" fill="none" stroke="#1c1c1c" stroke-width="' + cell + '"/>' +
        '<rect x="' + ((x0 + 2) * cell) + '" y="' + ((y0 + 2) * cell) + '" width="' + (3 * cell) +
        '" height="' + (3 * cell) + '" fill="#1c1c1c"/>';
    }

    var cells = '';
    for (var y = 0; y < N; y++) {
      for (var x = 0; x < N; x++) {
        if (inFinder(x, y)) continue;
        if (rnd() > 0.52) {
          cells += '<rect x="' + (x * cell).toFixed(3) + '" y="' + (y * cell).toFixed(3) +
            '" width="' + cell.toFixed(3) + '" height="' + cell.toFixed(3) + '" fill="#1c1c1c"/>';
        }
      }
    }

    return '<svg viewBox="0 0 120 120" width="120" height="120" role="img" aria-label="演示二维码">' +
      '<rect width="120" height="120" fill="#fff"/>' + cells +
      finder(0, 0) + finder(N - 7, 0) + finder(0, N - 7) + '</svg>';
  }

  /* ------------------------------------------------------------ 弹窗 */
  var activeTab = 'phone';
  var countdown = 0;
  var countdownTimer = null;

  function tabButtons() {
    return [
      { key: 'phone', label: '手机号登录', note: '短信验证码' },
      { key: 'wechat', label: '微信快捷登录', note: '扫码授权' }
    ].map(function (t) {
      return '<button type="button" class="lg-tab' + (activeTab === t.key ? ' is-on' : '') +
        '" data-lg-tab="' + t.key + '" role="tab" aria-selected="' + (activeTab === t.key) + '">' +
        '<b>' + esc(t.label) + '</b><span>' + esc(t.note) + '</span></button>';
    }).join('');
  }

  function phonePanel() {
    return '<div class="lg-form">' +
      '<label class="lg-field">' +
      '<span class="lg-label">手机号</span>' +
      '<div class="lg-input"><em>+86</em>' +
      '<input id="lg-phone" type="tel" inputmode="numeric" maxlength="11" autocomplete="tel" ' +
      'placeholder="请输入 11 位手机号"></div>' +
      '</label>' +
      '<label class="lg-field">' +
      '<span class="lg-label">验证码</span>' +
      '<div class="lg-input is-code">' +
      '<input id="lg-code" type="text" inputmode="numeric" maxlength="6" autocomplete="one-time-code" ' +
      'placeholder="6 位数字">' +
      '<button type="button" class="lg-send" id="lg-send">获取验证码</button>' +
      '</div>' +
      '</label>' +
      '<button type="button" class="btn btn-primary lg-submit" id="lg-submit">登录</button>' +
      '<p class="lg-msg" id="lg-msg" hidden></p>' +
      '<p class="lg-hint">演示环境不会真的发短信：点「获取验证码」后，' +
      '<b>任意 6 位数字</b>都能通过。手机号只用于本地展示，不会上传。</p>' +
      '</div>';
  }

  function wechatPanel() {
    return '<div class="lg-wechat">' +
      '<div class="lg-qr">' + qrSvg('mcd-radar-demo-login-v1') +
      '<span class="lg-qr-tag">演示二维码</span></div>' +
      '<p class="lg-scan">用微信「扫一扫」登录</p>' +
      '<button type="button" class="btn btn-outline lg-submit" id="lg-wechat">模拟扫码并确认（演示）</button>' +
      '<p class="lg-hint">本项目<b>未接入微信开放平台</b>，扫码与授权均为演示：' +
      '真实接入需要企业主体的 AppID、回调域名与用户授权流程。' +
      '登录后顶栏展示的是<b>麦当劳 MCP 真实返回</b>的券、积分与历史订单。</p>' +
      '</div>';
  }

  function bodyHTML() {
    return activeTab === 'phone' ? phonePanel() : wechatPanel();
  }

  function maskHTML() {
    return '<div class="login-card" role="dialog" aria-modal="true" aria-labelledby="lg-title">' +
      '<div class="lg-brand">' +
      '<span class="lg-logo">🍔</span>' +
      '<div class="lg-brand-text"><b id="lg-title">登录麦麦雷达地图</b>' +
      '<span>登录后可在顶栏快速查看券、积分与历史订单</span></div>' +
      '</div>' +
      '<div class="lg-tabs" role="tablist">' + tabButtons() + '</div>' +
      '<div class="lg-body" id="lg-body">' + bodyHTML() + '</div>' +
      '<div class="lg-foot">' +
      '<button type="button" class="lg-skip" id="lg-skip">暂不登录，先逛逛</button>' +
      '<span class="lg-note">本地演示登录 · 不上传任何信息 · 未接入麦当劳真实账号体系</span>' +
      '</div>' +
      '</div>';
  }

  function ensureMask() {
    var mask = $('#login-mask');
    if (mask) return mask;
    mask = document.createElement('div');
    mask.id = 'login-mask';
    mask.className = 'login-mask';
    mask.hidden = true;
    document.body.appendChild(mask);
    return mask;
  }

  function message(text, kind) {
    var el = $('#lg-msg');
    if (!el) return;
    if (!text) { el.hidden = true; el.textContent = ''; return; }
    el.hidden = false;
    el.className = 'lg-msg' + (kind ? ' is-' + kind : '');
    el.textContent = text;
  }

  function clearCountdown() {
    if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
    countdown = 0;
  }

  function startCountdown() {
    countdown = 60;
    var btn = $('#lg-send');
    var tick = function () {
      var el = $('#lg-send');
      if (!el) { clearCountdown(); return; }
      if (countdown <= 0) {
        clearCountdown();
        el.disabled = false;
        el.textContent = '重新获取';
        return;
      }
      el.disabled = true;
      el.textContent = countdown + 's 后重发';
      countdown -= 1;
    };
    if (btn) { btn.disabled = true; btn.textContent = '60s 后重发'; }
    countdownTimer = setInterval(tick, 1000);
    return countdownTimer;
  }

  function submitPhone() {
    var phoneEl = $('#lg-phone');
    var codeEl = $('#lg-code');
    var phone = phoneEl ? phoneEl.value.replace(/\s+/g, '') : '';
    var code = codeEl ? codeEl.value.replace(/\s+/g, '') : '';

    if (!/^1[3-9]\d{9}$/.test(phone)) {
      message('请输入有效的 11 位手机号。', 'warn');
      if (phoneEl) phoneEl.focus();
      return;
    }
    if (!/^\d{6}$/.test(code)) {
      message('请输入 6 位数字验证码（演示环境任意 6 位都可以）。', 'warn');
      if (codeEl) codeEl.focus();
      return;
    }

    message('');
    auth.signIn({
      type: 'phone',
      account: phone,
      nickname: '手机用户',
      at: new Date().toISOString(),
      demo: true
    });
    MCD.toast && MCD.toast('登录成功（本地演示）');
  }

  function submitWechat() {
    auth.signIn({
      type: 'wechat',
      account: 'wx_demo_user',
      nickname: '微信用户',
      at: new Date().toISOString(),
      demo: true
    });
    MCD.toast && MCD.toast('微信登录成功（本地演示）');
  }

  /**
   * 事件一律委托到 mask 自身。
   * 关键在于：弹窗内容会被整段重建，绑在子节点上的监听会随之失效；
   * 而 mask 节点本身只被复用、不被替换，所以绑它才是稳的。
   */
  function bindMask(mask) {
    mask.addEventListener('click', function (evt) {
      var target = evt.target;

      if (target.closest('#lg-skip')) {
        markSkipped();
        auth.close();
        return;
      }

      var tab = target.closest('[data-lg-tab]');
      if (tab) { switchTab(tab.getAttribute('data-lg-tab')); return; }

      if (target.closest('#lg-send')) {
        var phoneEl = $('#lg-phone');
        var phone = phoneEl ? phoneEl.value.replace(/\s+/g, '') : '';
        if (!/^1[3-9]\d{9}$/.test(phone)) {
          message('请先填写有效的 11 位手机号，再获取验证码。', 'warn');
          if (phoneEl) phoneEl.focus();
          return;
        }
        message('演示环境不发送真实短信 —— 请直接输入任意 6 位数字。', 'ok');
        startCountdown();
        return;
      }

      if (target.closest('#lg-submit')) { submitPhone(); return; }
      if (target.closest('#lg-wechat')) { submitWechat(); return; }
    });

    // 输入时清掉上一条提示，避免旧提示误导
    mask.addEventListener('input', function (evt) {
      if (evt.target && (evt.target.id === 'lg-phone' || evt.target.id === 'lg-code')) {
        message('');
      }
    });
  }

  /** 切 tab：重建内容，但把已填的手机号带过去。 */
  function switchTab(key) {
    if (key === activeTab) return;
    var phoneEl = $('#lg-phone');
    var keep = phoneEl ? phoneEl.value : '';
    activeTab = key;
    render();
    var next = $('#lg-phone');
    if (next && keep) next.value = keep;
  }

  /** 重建弹窗内容（外壳与监听都不动）。 */
  function render() {
    var mask = ensureMask();
    mask.innerHTML = maskHTML();
  }

  auth.open = function (reason) {
    var mask = ensureMask();
    clearCountdown();
    render();
    mask.hidden = false;
    document.body.classList.add('has-login');

    if (reason === 'logout') {
      message('你已退出登录。', 'ok');
    }

    var first = mask.querySelector('#lg-phone');
    if (first) { try { first.focus(); } catch (e) { /* jsdom 无焦点 */ } }
  };

  auth.close = function () {
    var mask = $('#login-mask');
    if (!mask) return;
    mask.hidden = true;
    clearCountdown();
    document.body.classList.remove('has-login');
  };

  auth.isOpen = function () {
    var mask = $('#login-mask');
    return !!mask && mask.hidden === false;
  };

  /** 首屏：未登录且当次加载没跳过 → 弹出来；否则静默。
   *
   *  注意「当次加载」：刷新页面后会重新弹。这是刻意的 ——
   *  原始需求就是「打开网页后先跳出一个弹窗」。已登录则不再打扰。 */
  auth.gate = function () {
    dropLegacySkip();
    if (auth.signedIn()) return false;
    if (skippedThisSession()) return false;
    auth.open('first-visit');
    return true;
  };

  // 首次加载就把事件委托挂上（此后重建内容也不用重新绑）
  var bound = false;
  auth._bindOnce = function () {
    if (bound) return;
    bindMask(ensureMask());
    bound = true;
  };

  MCD.auth = auth;
  auth._bindOnce();
})(window.MCD);
