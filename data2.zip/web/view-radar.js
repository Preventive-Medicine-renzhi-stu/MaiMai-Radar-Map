/* ==========================================================================
   麦麦雷达地图 —— 雷达首页（三种模式 + 7 天活动日历）
   ========================================================================== */
(function (MCD) {
  'use strict';

  var util = MCD.util, data = MCD.data, state = MCD.state, calc = MCD.calc;
  var $ = util.$, esc = util.esc, yuan = util.yuan, distLabel = util.distLabel, img = util.img;

  var SPEED = { walk: 80, ride: 260, drive: 500 };
  var newestFilter = 'all';

  /* ------------------------------------------------------------ 通用片段 */
  function goOrder(storeCode, query) {
    if (storeCode) state.storeCode = storeCode;
    if (query != null) state.query = query;
    MCD.router.go('/order');
  }

  function bestStoreCode() {
    if (state.mode === 'speed') {
      var speed = MCD.DATA.modes && MCD.DATA.modes.speed;
      return (speed && speed.best_store_code) || '';
    }
    var list = data.nearbyRows();
    return list.length ? list[0].store_code : '';
  }

  /** 门店行里能直接展示的一行摘要（缺失字段不硬凑）。 */
  function rowMeta(row) {
    var parts = [];
    if (row.distance != null) parts.push(distLabel(row.distance));
    if (row.travel_minutes != null) parts.push((row.travel_label || '') + '约 ' + row.travel_minutes + ' 分钟');
    if (row.busy_label) parts.push(row.busy_label);
    return esc(parts.join(' · ') || '门店信息未返回');
  }

  function storeCard(row, opts) {
    opts = opts || {};
    var badges = (row.badges || []).map(function (b) {
      var cls = 'badge';
      if (b.indexOf('常去') >= 0 || b.indexOf('点过') >= 0) cls += ' is-fav';
      if (b.indexOf('预约') >= 0) cls += ' is-info';
      if (b.indexOf('步行') >= 0) cls += ' is-ok';
      return '<span class="' + cls + '">' + esc(b) + '</span>';
    }).join('');
    var busyCls = row.busy_score >= 52 ? 'is-hot' : 'is-cool';
    var isBest = row.store_code === bestStoreCode() && state.mode !== 'newest';

    return '<article class="store-card' + (row.store_code === state.selectedStore ? ' is-selected' : '') +
      (isBest ? ' is-best' : '') + '" data-store="' + esc(row.store_code) + '">' +
      '<div class="store-top"><span class="store-rank">' + row.rank + '</span>' +
      '<span class="store-name">' + esc(row.name) + '</span>' +
      '<span class="store-dist">' + distLabel(row.distance) + '</span></div>' +
      '<div class="store-addr">' + esc(row.address) + '</div>' +
      '<div class="store-metrics">' +
      '<span class="metric"><b>' + row.travel_minutes + ' 分</b><span>' + esc(row.travel_label) + '到达</span></span>' +
      '<span class="metric"><b>' + row.queue_minutes + ' 分</b><span>取餐等待*</span></span>' +
      '<span class="metric ' + busyCls + '"><b>' + esc(row.busy_label) + '</b><span>繁忙度*</span></span>' +
      '</div>' +
      (badges ? '<div class="badges">' + badges + '</div>' : '') +
      (opts.orderButton === false ? '' :
        '<div class="store-actions"><button class="btn btn-order" data-order="' +
        esc(row.store_code) + '">去点餐</button></div>') +
      '</article>';
  }

  function prodRow(p, opts) {
    opts = opts || {};
    var tag = opts.clickable ? ' data-meal="' + esc(p.code) + '" data-meal-name="' + esc(p.name) + '"' : '';
    return '<div class="prod-row' + (opts.clickable ? ' is-clickable' : '') + '"' + tag + '>' + img(p.image, 'prod-thumb') +
      '<div class="prod-info"><div class="prod-name">' + esc(p.name) + '</div>' +
      '<div class="prod-sub">' + esc(p.code) + (p.discount_type ? ' · ' + esc(p.discount_type) : '') +
      (p.kcal ? ' · ' + Math.round(p.kcal) + ' 千卡' : '') + '</div></div>' +
      '<div class="prod-price"><b>' + yuan(p.price) + '</b>' +
      (p.original_price > p.price ? '<s>' + yuan(p.original_price) + '</s>' : '') + '</div></div>';
  }

  /* ------------------------------------------------------------ 模式一 */
  function renderNearbyLeft() {
    $('#left-title').textContent = '附近门店';
    $('#left-actions').innerHTML =
      '<span class="seg" id="nearby-seg">' +
      '<button data-sort="distance" class="' + (state.nearbySort === 'distance' ? 'is-active' : '') + '">距离最近</button>' +
      '<button data-sort="frequent" class="' + (state.nearbySort === 'frequent' ? 'is-active' : '') + '">最常去</button>' +
      '</span>';
    $('#nearby-seg').addEventListener('click', function (evt) {
      var btn = evt.target.closest('button');
      if (!btn) return;
      state.nearbySort = btn.getAttribute('data-sort');
      render();
    });

    var list = data.nearbyRows();
    var html = '';

    /* 置顶：一键点餐 —— 跟着 1.1 的选择走：
       点选过门店就用那家，没点选就用当前排序的第一家（距离最近 / 最常去）。 */
    var picked = MCD.orderStoreRow();
    if (picked) {
      var isChosen = state.selectedStore === picked.store_code;
      html += '<div class="quick-order">' +
        '<span class="qo-tag">一键点餐</span>' +
        '<div class="qo-copy"><strong>' + esc(picked.name) +
        '<em class="qo-src' + (isChosen ? '' : ' is-auto') + '">' +
        (isChosen ? '已选门店' : '按' + (state.nearbySort === 'frequent' ? '「最常去」' : '「距离最近」') + '推荐') +
        '</em></strong>' +
        '<span>' + rowMeta(picked) + '</span></div>' +
        '<button class="btn btn-primary" data-order="' + esc(picked.store_code) + '">用这家店点餐</button>' +
        '</div>' +
        '<p class="qo-note">点左侧任意门店卡片，就能把「一键点餐」切到那家店 —— 右下角的悬浮球用的是同一家。</p>';
    }

    if (state.nearbySort === 'frequent' && !MCD.DATA.modes.nearby_frequent.stores.some(function (r) { return r.order_count > 0; })) {
      html += '<div class="notice notice-info"><span class="notice-icon">ℹ️</span>' +
        '<span>你在附近 5 家门店还没有历史订单，已按距离排序。' +
        '下方「历史消费门店」列出了你真实下过单的店。</span></div>';
    }

    if (state.nearbySort === 'frequent' && MCD.DATA.history_stores && MCD.DATA.history_stores.length) {
      MCD.DATA.history_stores.forEach(function (h) {
        var near = data.storeByCode(h.store_code);
        html += '<article class="store-card" data-nohit="1">' +
          '<div class="store-top"><span class="store-rank">★</span>' +
          '<span class="store-name">' + esc(h.store_name) + '</span>' +
          '<span class="store-dist">' + h.order_count + ' 单</span></div>' +
          '<div class="store-addr">最近一次 ' + esc((h.last_order_time || '').slice(0, 10)) +
          ' · 累计 ' + yuan(h.total_amount) + (near ? '' : ' · 不在当前城市范围') + '</div>' +
          '<div class="badges">' + h.products.slice(0, 3).map(function (p) {
            return '<span class="badge">' + esc(p) + '</span>';
          }).join('') + '</div>' +
          (near ? '<div class="store-actions"><button class="btn btn-order" data-order="' + esc(near.store_code) + '">去这家点餐</button></div>' : '') +
          '</article>';
      });
      html += '<div class="section-title">按距离排序的附近门店</div>';
    }

    html += list.map(function (row) { return storeCard(row); }).join('');
    $('#left-body').innerHTML = html;
    bindCards($('#left-body'));
  }

  function renderNearbyRight() {
    $('#right-title').textContent = '门店详情';
    var code = state.selectedStore || bestStoreCode();
    var row = null;
    data.nearbyRows().forEach(function (r) { if (r.store_code === code) row = r; });
    if (!row) { $('#right-body').innerHTML = '<div class="empty">请选择左侧门店</div>'; return; }

    var menu = data.menuOf(row.store_code).slice()
      .sort(function (a, b) { return (b.saving || 0) - (a.saving || 0); }).slice(0, 6);
    var html = storeDetailHtml(row);
    html += '<div class="section-title">门店在售 · 折扣力度 Top</div>';
    html += menu.length ? menu.map(function (p) { return prodRow(p, { clickable: true }); }).join('')
      : '<div class="empty">该店菜单未返回</div>';

    var history = (MCD.DATA.history_stores || []).filter(function (h) { return h.store_code === row.store_code; });
    if (history.length) {
      html += '<div class="section-title">你的消费记录</div>';
      html += history.map(function (h) {
        return '<div class="notice notice-ok"><span class="notice-icon">🧾</span><span>累计 ' + h.order_count +
          ' 单 · ' + yuan(h.total_amount) + '，最近一次 ' + esc((h.last_order_time || '').slice(0, 10)) + '</span></div>';
      }).join('');
    }
    $('#right-body').innerHTML = html;
    bindCards($('#right-body'));
  }

  function storeDetailHtml(row) {
    var open = row.business_status;
    return '<div class="detail-title"><h3>' + esc(row.name) + '</h3>' +
      '<button class="btn btn-primary btn-sm" data-order="' + esc(row.store_code) + '">去点餐</button></div>' +
      '<div class="detail-addr">' + esc(row.address) + '</div>' +
      '<dl class="kv">' +
      '<dt>门店编号</dt><dd>' + esc(row.store_code) + (row.be_code ? ' / ' + esc(row.be_code) : '') + '</dd>' +
      '<dt>取餐方式</dt><dd>' + esc(row.be_type_label) + '</dd>' +
      '<dt>营业时间</dt><dd>' + (open ? esc(row.open_time + ' - ' + row.close_time) : '休息中') + '</dd>' +
      '<dt>距离</dt><dd>' + distLabel(row.distance) + '</dd>' +
      '<dt>预计到达</dt><dd>' + row.travel_minutes + ' 分钟（' + esc(row.travel_label) + '）</dd>' +
      '<dt>繁忙度预估</dt><dd>' + esc(row.busy_label) + ' · 等待约 ' + row.queue_minutes + ' 分钟</dd>' +
      '<dt>是否支持预约</dt><dd>' + (row.reservation ? '支持' : '不支持') + '</dd>' +
      '</dl>' +
      '<div class="notice notice-info"><span class="notice-icon">📐</span><span>带 * 的为模型预估（按时段客流 + 门店因子推演），' +
      '非实时排队数据；下单前请以门店实际为准。</span></div>';
  }

  /* ------------------------------------------------------------ 模式二 */
  function renderNewestLeft() {
    $('#left-title').textContent = '限时活动';
    $('#left-actions').innerHTML =
      '<span class="seg" id="newest-seg">' +
      '<button data-f="all" class="' + (newestFilter === 'all' ? 'is-active' : '') + '">全部</button>' +
      '<button data-f="product" class="' + (newestFilter === 'product' ? 'is-active' : '') + '">有商品</button>' +
      '<button data-f="gift" class="' + (newestFilter === 'gift' ? 'is-active' : '') + '">限时周边</button>' +
      '</span>';
    $('#newest-seg').addEventListener('click', function (evt) {
      var btn = evt.target.closest('button');
      if (!btn) return;
      newestFilter = btn.getAttribute('data-f');
      render();
    });

    var acts = (MCD.DATA.modes.newest && MCD.DATA.modes.newest.activities) || [];
    var list = acts.filter(function (a) {
      if (newestFilter === 'gift') return a.is_gift;
      if (newestFilter === 'product') return a.products.length > 0;
      return true;
    });

    var html = '';
    if (!list.length) html = '<div class="empty">暂无符合条件的活动</div>';
    list.forEach(function (a) {
      var dateCls = a.days_until === 0 ? 'is-today' : '';
      var dateText = a.days_until === 0 ? '今天' : (a.days_until === 1 ? '明天' : (a.days_until > 1 ? a.days_until + ' 天后' : a.date_label));
      html += '<article class="act-card is-clickable" data-activity="' + esc(activityIndexOf(a)) + '">' + img(a.image, 'act-thumb', a.title) +
        '<div class="act-main">' +
        '<span class="act-date ' + dateCls + '">' + esc(dateText) + '</span>' +
        '<div class="act-title">' + esc(a.title) + '</div>' +
        '<div class="act-body">' + esc(a.body) + '</div>' +
        '<div class="badges" style="margin-top:6px">' +
        (a.is_gift ? '<span class="badge is-warn">限时周边</span>' : '') +
        (a.launch_tags || []).slice(0, 2).map(function (t) { return '<span class="badge is-info">' + esc(t) + '</span>'; }).join('') +
        (a.products.length ? '<span class="badge is-ok">关联 ' + a.products.length + ' 款商品</span>' : '') +
        '<span class="badge is-ghost">查看详情 →</span>' +
        '</div></div></article>';
    });
    $('#left-body').innerHTML = html;
    bindCards($('#left-body'));
  }

  function activityIndexOf(a) {
    var list = data.activities();
    for (var i = 0; i < list.length; i++) {
      if (list[i].title === a.title && list[i].date === a.date) return list[i].index;
    }
    return 0;
  }

  function renderNewestRight() {
    $('#right-title').textContent = '主题活动 · 限时发售';
    var n = MCD.DATA.modes.newest || { activities: [], gifts: [] };
    var html = '<div class="section-title">近期限时周边发售</div>';
    if (!n.gifts.length) {
      html += '<div class="empty">未来 7 天没有周边发售活动</div>';
    } else {
      n.gifts.forEach(function (g) {
        var when = g.days_until === 0 ? '今天开售' : (g.days_until > 0 ? g.days_until + ' 天后开售' : g.date);
        html += '<article class="act-card is-clickable" data-activity="' + esc(activityIndexOf(g)) + '">' + img(g.image, 'act-thumb', g.title) +
          '<div class="act-main"><span class="act-date ' + (g.days_until === 0 ? 'is-today' : '') + '">' +
          esc(g.date_label + ' · ' + when) + '</span>' +
          '<div class="act-title">' + esc(g.title) + '</div>' +
          '<div class="badges" style="margin-top:5px">' + g.tags.map(function (t) {
            return '<span class="badge is-warn">' + esc(t) + '</span>';
          }).join('') + '</div></div></article>';
      });
    }

    html += '<div class="section-title">限时新品 · 哪些店有售</div>';
    var withProducts = n.activities.filter(function (a) { return a.products.length; }).slice(0, 5);
    if (!withProducts.length) {
      html += '<div class="empty">暂无可对齐到具体门店菜单的新品</div>';
    }
    withProducts.forEach(function (a) {
      html += '<div style="margin-bottom:12px"><div style="font-size:12px;font-weight:700;margin-bottom:5px">' + esc(a.title) + '</div>';
      a.products.slice(0, 3).forEach(function (p) {
        var storeNames = p.stores.map(function (c) {
          var s = data.storeByCode(c);
          return s ? s.name.replace(/^麦当劳/, '').replace(/餐厅$/, '') : c;
        });
        html += '<div class="prod-row is-clickable" data-meal="' + esc(p.code) + '" data-meal-name="' + esc(p.name) + '">' + img(p.image, 'prod-thumb') +
          '<div class="prod-info"><div class="prod-name">' + esc(p.name) + '</div>' +
          '<div class="prod-sub">' + (p.partial
            ? '仅 ' + p.store_count + ' 家店在售：' + esc(storeNames.join('、'))
            : '全部 ' + p.store_count + ' 家店在售') + '</div></div>' +
          '<div class="prod-price"><b>' + yuan(p.price) + '</b>' +
          (p.original_price > p.price ? '<s>' + yuan(p.original_price) + '</s>' : '') + '</div></div>';
      });
      html += '</div>';
    });

    $('#right-body').innerHTML = html;
    bindCards($('#right-body'));
  }

  /* ------------------------------------------------------------ 模式三 */
  function cartItems() {
    var all = data.menuOf(data.stores().length ? data.stores()[0].store_code : '');
    return Object.keys(state.cart).filter(function (k) { return state.cart[k] > 0; })
      .map(function (code) {
        var found = null;
        all.forEach(function (m) { if (m.code === code) found = m; });
        if (!found) found = data.mealByCode(code);
        return found ? { code: code, name: found.name, price: found.price, quantity: state.cart[code], image: found.image } : null;
      }).filter(Boolean);
  }

  function computeSpeed() {
    var picked = cartItems();
    var rows = data.speedRows().map(function (r) {
      var menu = data.menuOf(r.store_code);
      var have = {};
      menu.forEach(function (m) { have[m.code] = true; });
      var missing = picked.filter(function (p) { return !have[p.code]; });
      var notes = [];
      if (!r.business_status) notes.push('门店当前未营业');
      if (r.busy_label === '极度繁忙') notes.push('该店预估' + r.busy_label + '，排队约 ' + r.queue_minutes + ' 分钟');
      if (r.reservation) notes.push('支持预约，可提前锁定取餐时间');
      missing.forEach(function (m) { notes.push('「' + m.name + '」该店菜单中暂无售'); });
      return Object.assign({}, r, {
        missing_count: missing.length,
        notes: notes,
        orderable: r.business_status && missing.length === 0
      });
    });

    rows.sort(function (a, b) {
      if (a.orderable !== b.orderable) return a.orderable ? -1 : 1;
      return a.total_minutes - b.total_minutes || a.distance - b.distance;
    });

    var warnings = [];
    var nearest = null;
    rows.forEach(function (r) { if (!nearest || r.distance < nearest.distance) nearest = r; });
    var best = rows[0] || null;
    if (nearest && best && nearest.store_code !== best.store_code && best.orderable) {
      var gap = nearest.total_minutes - best.total_minutes;
      if (gap > 0) warnings.push('最近的门店是「' + nearest.name + '」，但它在' + nearest.busy_label +
        '状态下预计要多等约 ' + gap + ' 分钟；「' + best.name + '」综合更快。');
    }
    if (best && best.busy_label === '极度繁忙') {
      warnings.push('综合最快的「' + best.name + '」当前也处于极度繁忙（预估排队 ' + best.queue_minutes +
        ' 分钟），建议先预约取餐再出发。');
    }
    if (best && best.missing_count) warnings.push('「' + best.name + '」有 ' + best.missing_count + ' 件所选商品不可售。');

    return { rows: rows, best: best, warnings: warnings, picked: picked };
  }

  function pickerContext() {
    var all = data.menuOf(data.stores().length ? data.stores()[0].store_code : '');
    var cats = {};
    all.forEach(function (m) {
      (m.tags || ['其他']).slice(0, 1).forEach(function (t) { (cats[t] = cats[t] || []).push(m); });
    });

    var q = state.pickerQuery.trim();
    var pool;
    if (q) {
      pool = all.filter(function (m) { return m.name.indexOf(q) >= 0 || m.code.indexOf(q) >= 0; });
    } else if (state.pickerCategory === '推荐') {
      pool = all.filter(function (m) {
        return (m.tags || []).indexOf('人气') >= 0 || (m.tags || []).indexOf('单品') >= 0;
      }).slice(0, 12);
    } else {
      pool = cats[state.pickerCategory] || [];
    }
    if (!pool.length && !q) pool = all.slice(0, 12);
    return { all: all, cats: cats, pool: pool, query: q };
  }

  function pickerChipsHtml(cats) {
    return '<button class="badge' + (state.pickerCategory === '推荐' ? ' is-info' : '') + '" data-cat="推荐">推荐组合</button>' +
      Object.keys(cats).slice(0, 6).map(function (c) {
        return '<button class="badge' + (state.pickerCategory === c ? ' is-info' : '') + '" data-cat="' + esc(c) + '">' +
          esc(c) + '</button>';
      }).join('');
  }

  function pickerListHtml(pool, query) {
    var sum = 0;
    cartItems().forEach(function (i) { sum += i.price * i.quantity; });
    var units = Object.keys(state.cart).reduce(function (a, k) { return a + (state.cart[k] || 0); }, 0);

    var html = '<div class="cart-summary">' +
      '<div class="row"><span>已选 ' + cartItems().length + ' 项 / ' + units + ' 件</span>' +
      '<span>门店价合计</span></div>' +
      '<div class="row total"><span>合计</span><b>' + yuan(sum) + '</b></div>' +
      '</div>';

    if (!pool.length) {
      return html + '<div class="empty">没有匹配「' + esc(query) + '」的餐品，换个关键词试试</div>';
    }

    return html + pool.slice(0, 14).map(function (m) {
      var on = state.cart[m.code] > 0;
      return '<div class="picker-item' + (on ? ' is-on' : '') + '" data-code="' + esc(m.code) + '">' +
        img(m.image, 'prod-thumb') +
        '<div class="picker-name">' + esc(m.name) + '</div>' +
        '<div class="picker-price">' + yuan(m.price) + '</div>' +
        (on
          ? '<span class="qty"><button data-act="minus">−</button><span>' + state.cart[m.code] +
            '</span><button data-act="plus">+</button></span>'
          : '<button class="badge is-info" data-act="add">加入</button>') +
        '</div>';
    }).join('');
  }

  function bindPickerItems(root) {
    util.$$('.picker-item', root).forEach(function (node) {
      node.addEventListener('click', function (evt) {
        var target = evt.target.closest('[data-act]');
        var act = target ? target.getAttribute('data-act') : null;
        var code = node.getAttribute('data-code');
        if (act === 'add' || act === 'plus') state.cart[code] = (state.cart[code] || 0) + 1;
        else if (act === 'minus') state.cart[code] = Math.max(0, (state.cart[code] || 0) - 1);
        else return;
        render();
      });
    });
  }

  /** 只重绘列表，**不动输入框节点** —— 见 bindPickerInput 的说明。 */
  function refreshPickerList() {
    var box = $('#picker-list');
    if (!box) return;
    var ctx = pickerContext();
    box.innerHTML = pickerListHtml(ctx.pool, ctx.query);
    bindPickerItems(box);
  }

  /**
   * 搜索框绑定。
   *
   * ⚠️ 关键：这里**绝不能在 input 事件里重绘包含输入框的容器**。
   * 之前的实现是 input → renderSpeedLeft()，把 `#left-body` 整个 innerHTML 换掉，
   * 输入框 DOM 节点每次按键都被销毁重建，中文输入法的组字（composition）随之被打断，
   * 表现就是「拼音能打出来、汉字上不去」。
   * 现在的做法：
   *   ① 输入框与列表拆成两个容器，输入只重绘 `#picker-list`；
   *   ② 组字期间（compositionstart → compositionend）干脆不刷新，
   *      等 compositionend 拿到最终文本再刷一次，避免候选词还没落定就被过滤掉。
   */
  function bindPickerInput() {
    var box = $('#picker-search');
    if (!box) return;
    var composing = false;

    box.addEventListener('compositionstart', function () { composing = true; });
    box.addEventListener('compositionend', function (e) {
      composing = false;
      state.pickerQuery = e.target.value;
      refreshPickerList();
    });
    box.addEventListener('input', function (e) {
      state.pickerQuery = e.target.value;
      if (composing || e.isComposing) return;   // 组字中：等 compositionend
      refreshPickerList();
    });
  }

  function renderSpeedLeft() {
    $('#left-title').textContent = '① 先填要买的商品';
    $('#left-actions').innerHTML = '<span class="badge is-info">共 ' + cartItems().length + ' 项</span>';

    var ctx = pickerContext();

    $('#left-body').innerHTML =
      '<input class="picker-search" id="picker-search" type="search" autocomplete="off" ' +
      'placeholder="搜索餐品，如 巨无霸 / 龙焰 / 薯条" value="' + esc(state.pickerQuery) + '">' +
      '<div class="chips" id="picker-chips">' + pickerChipsHtml(ctx.cats) + '</div>' +
      '<div class="picker-list" id="picker-list">' + pickerListHtml(ctx.pool, ctx.query) + '</div>';

    bindPickerInput();
    bindPickerItems($('#picker-list'));

    util.$$('[data-cat]', $('#picker-chips')).forEach(function (b) {
      b.addEventListener('click', function () {
        state.pickerCategory = b.getAttribute('data-cat');
        state.pickerQuery = '';
        renderSpeedLeft();
      });
    });
  }

  function renderSpeedRight() {
    $('#right-title').textContent = '② 哪个店最快';
    var res = computeSpeed();
    var html = '';

    if (!res.picked.length) {
      html += '<div class="empty">先在左侧选择要买的商品，这里会算出最快的取餐门店</div>';
    } else {
      res.warnings.forEach(function (w) {
        html += '<div class="notice notice-warn"><span class="notice-icon">⚠️</span><span>' + esc(w) + '</span></div>';
      });
      if (!res.warnings.length) {
        html += '<div class="notice notice-ok"><span class="notice-icon">✅</span><span>最近的门店就是最快选择，直接过去即可。</span></div>';
      }
      html += '<div class="section-title">最快取餐排行</div>';
      html += res.rows.map(function (r) { return storeCard(r); }).join('');
    }

    html += '<div class="section-title">极速套餐推荐</div>';
    var combo = MCD.DATA.modes.speed && MCD.DATA.modes.speed.fast_combo;
    if (!combo) {
      html += '<div class="empty">暂无推荐</div>';
    } else {
      html += '<div class="price-box"><div class="pb-head">' + img(combo.image, 'pb-thumb') +
        '<div><div class="pb-name">' + esc(combo.name) + '</div>' +
        '<div class="prod-sub">' + esc(combo.reason) + '</div></div></div>' +
        '<div class="price-tags">' +
        '<span class="tag is-red">现价 ' + yuan(combo.price) + '</span>' +
        (combo.original_price > combo.price ? '<span class="tag">原价 ' + yuan(combo.original_price) + '</span>' : '') +
        '<span class="tag is-green">省 ' + yuan(combo.saving) + '</span>' +
        '<button class="btn btn-primary btn-sm" data-meal="' + esc(combo.code) + '" data-meal-name="' + esc(combo.name) + '">去点餐</button>' +
        '</div></div>';
    }

    html += '<div class="section-title">历史订单置顶</div>';
    var h = MCD.DATA.modes.speed && MCD.DATA.modes.speed.history;
    if (!h) {
      html += '<div class="empty">没有历史订单</div>';
    } else {
      html += '<div class="price-box"><div class="pb-head">' + img(h.image, 'pb-thumb') +
        '<div><div class="pb-name">' + esc(h.name) + '</div>' +
        '<div class="prod-sub">' + esc(h.store_name) + ' · ' + esc((h.last_time || '').slice(0, 10)) +
        ' · 实付 ' + yuan(h.order_amount) + '</div></div></div>' +
        '<div class="price-tags">' +
        (h.price != null ? '<span class="tag is-red">当前门店价 ' + yuan(h.price) + '</span>' : '<span class="tag">该店已下架</span>') +
        (h.original_price != null && h.original_price > h.price ? '<span class="tag">原价 ' + yuan(h.original_price) + '</span>' : '') +
        (h.saving ? '<span class="tag is-green">省 ' + yuan(h.saving) + '</span>' : '') +
        '<button class="btn btn-primary btn-sm" data-meal="' + esc(h.code) + '" data-meal-name="' + esc(h.name) + '">再来一单</button>' +
        '</div></div>';
    }

    html += '<div class="section-title">可用优惠券</div>';
    var coupons = calc.couponsFor();
    if (!coupons.length) {
      html += '<div class="empty">该门店暂无可用券</div>';
    } else {
      html += '<div class="chips">' + coupons.map(function (c) {
        return '<span class="coupon-chip">🎟️ ' + esc(c.title) +
          (c.face_price != null ? '（券面 ¥' + c.face_price + '）' : '') + '</span>';
      }).join('') + '</div>';
      html += '<div class="notice notice-info" style="margin-top:8px"><span class="notice-icon">ℹ️</span>' +
        '<span>券后价需在结算时由门店算价接口确认；标题未写明金额的券，本页不预估抵扣。</span></div>';
    }

    $('#right-body').innerHTML = html;
    bindCards($('#right-body'));
  }

  /* ------------------------------------------------------------ 日历 */
  function renderCalendar() {
    var days = MCD.DATA.calendar || [];
    var html = days.map(function (d) {
      var cls = 'cal-day' + (d.is_today ? ' is-today' : '') + (d.count === 0 ? ' is-empty' : '') +
        (state.selectedDay === d.date ? ' is-selected' : '');
      var titles = (d.activities || []).slice(0, 2).map(function (a) {
        return '<div>' + esc(a.title.replace(/\s+/g, ' ').slice(0, 16)) + '</div>';
      }).join('');
      var more = d.count > 2 ? '<div class="cal-more">+' + (d.count - 2) + ' 条</div>' : '';
      return '<div class="' + cls + '" data-day="' + esc(d.date) + '">' +
        '<div class="cal-date">' + esc(d.month_day) + '<em>' + esc(d.label) + '</em></div>' +
        '<div class="cal-count">' + (d.count ? d.count + ' 个活动' : '无活动') + '</div>' +
        '<div class="cal-titles">' + titles + more + '</div></div>';
    }).join('');
    $('#calendar-days').innerHTML = html;

    util.$$('.cal-day', $('#calendar-days')).forEach(function (node) {
      node.addEventListener('click', function () {
        var day = node.getAttribute('data-day');
        state.selectedDay = state.selectedDay === day ? null : day;
        renderCalendar();
      });
    });

    var detail = $('#calendar-detail');
    if (!state.selectedDay) {
      detail.hidden = true;
      $('#calendar-hint').textContent = '点击某天查看当日全部活动，再点活动可进入详情页';
      return;
    }
    var day = null;
    days.forEach(function (d) { if (d.date === state.selectedDay) day = d; });
    if (!day || !day.count) {
      detail.hidden = false;
      detail.innerHTML = '<div class="empty" style="grid-column:1/-1">' + esc(state.selectedDay) + ' 暂无活动</div>';
      return;
    }
    detail.hidden = false;
    $('#calendar-hint').textContent = day.date + '（' + day.weekday + '）共 ' + day.count + ' 个活动';
    detail.innerHTML = day.activities.map(function (a) {
      return '<article class="act-card is-clickable" data-activity="' + esc(activityIndexOf(a)) + '">' +
        img(a.image, 'act-thumb', a.title) +
        '<div class="act-main"><div class="act-title">' + esc(a.title) + '</div>' +
        '<div class="act-body">' + esc(a.body) + '</div>' +
        '<div class="badges" style="margin-top:6px"><span class="badge is-ghost">查看详情 →</span></div>' +
        '</div></article>';
    }).join('');
    bindCards(detail);
  }

  /* ------------------------------------------------------------ 绑定 */
  function bindCards(root) {
    util.$$('.store-card[data-store]', root).forEach(function (node) {
      node.addEventListener('click', function (evt) {
        if (evt.target.closest('[data-order]')) return; // 「去点餐」按钮另处理
        selectStore(node.getAttribute('data-store'));
      });
    });
    util.$$('[data-order]', root).forEach(function (btn) {
      btn.addEventListener('click', function (evt) {
        evt.stopPropagation();
        goOrder(btn.getAttribute('data-order'));
      });
    });
    util.$$('[data-meal]', root).forEach(function (node) {
      node.addEventListener('click', function (evt) {
        evt.stopPropagation();
        goOrder(null, node.getAttribute('data-meal-name'));
      });
    });
    util.$$('[data-activity]', root).forEach(function (node) {
      node.addEventListener('click', function () {
        MCD.router.go('/activity/' + node.getAttribute('data-activity'));
      });
    });
  }

  function selectStore(code) {
    state.selectedStore = code;
    if (state.mode === 'speed') {
      renderLeft();
      renderRight();
      if (MCD.chrome && MCD.chrome.refreshFab) MCD.chrome.refreshFab();
      return;
    }
    render();
    if (MCD.map.ready()) {
      clearTimeout(selectStore._timer);
      selectStore._timer = setTimeout(function () {
        MCD.map.drawRoute(code, banner);
      }, 60);
    }
  }

  function banner(text, kind) {
    var el = $('#map-banner');
    if (!el) return;
    if (!text) { el.hidden = true; return; }
    el.hidden = false;
    el.className = 'map-banner' + (kind === 'warn' ? ' is-warn' : '');
    el.textContent = text;
  }

  function renderLeft() {
    if (cityMismatch()) {
      $('#left-title').textContent = '门店';
      $('#left-actions').innerHTML = '';
      $('#left-body').innerHTML = mismatchMiniHtml();
      bindCityReset($('#left-body'));
      return;
    }
    if (state.mode === 'nearby') renderNearbyLeft();
    else if (state.mode === 'newest') renderNewestLeft();
    else renderSpeedLeft();
  }

  function renderRight() {
    if (cityMismatch()) {
      $('#right-title').textContent = '怎么拿到这个城市的数据';
      $('#right-body').innerHTML = mismatchCardHtml();
      bindCityReset($('#right-body'));
      return;
    }
    if (state.mode === 'nearby') renderNearbyRight();
    else if (state.mode === 'newest') renderNewestRight();
    else renderSpeedRight();
  }

  function renderTopbar() {
    // 顶栏（快照标记 + 用户信息下拉）由 app.js 的 chrome 模块统一负责，
    // 这里只触发一次刷新，避免把它整个 innerHTML 覆盖掉。
    if (MCD.chrome && MCD.chrome.refresh) MCD.chrome.refresh();
  }

  function bindModeTabs() {
    $('#mode-tabs').addEventListener('click', function (evt) {
      var btn = evt.target.closest('.mode-tab');
      if (!btn) return;
      state.mode = btn.getAttribute('data-mode');
      state.selectedStore = null;
      util.$$('.mode-tab', $('#mode-tabs')).forEach(function (b) {
        b.classList.toggle('is-active', b === btn);
      });
      MCD.map.clearRoute();
      banner('');
      render();
    });
  }

  /* ==========================================================================
     城市 / 定位
     --------------------------------------------------------------------------
     数据来源按优先级：本地服务 /api/status 下发 → 数据包里的 cities →
     下面这份兜底副本。真正的单一真相是 Python 侧的 src/cities.py。

     换城市有两种走法，界面会把当下的能力如实标出来：
       · 本地服务在线且配置了 MCD_MCP_TOKEN → 「点一下就切」，服务端替你
         去麦当劳 MCP 拉真实数据，前端刷新即可看到；
       · 否则（纯静态 / 没配 Token）→ 明确告诉你缺什么，并给出可复制的命令。
     ========================================================================== */
  /* 完全没有数据包、也没有本地服务时的应急城市表（正常都不会走到这里）。
     完整的全国城市表由服务端 /api/status 或数据包的 MCD.DATA.cities 下发。 */
  var FALLBACK_CITIES = [
    { city: '深圳', keyword: '腾讯滨海大厦', province: '广东省' },
    { city: '上海', keyword: '人民广场', province: '上海' },
    { city: '北京', keyword: '国贸', province: '北京' },
    { city: '广州', keyword: '天河城', province: '广东省' },
    { city: '杭州', keyword: '西湖', province: '浙江省' },
    { city: '成都', keyword: '春熙路', province: '四川省' },
    { city: '武汉', keyword: '江汉路', province: '湖北省' },
    { city: '南京', keyword: '新街口', province: '江苏省' },
    { city: '西安', keyword: '钟楼', province: '陕西省' },
    { city: '重庆', keyword: '解放碑', province: '重庆' },
    { city: '苏州', keyword: '观前街', province: '江苏省' },
    { city: '天津', keyword: '滨江道', province: '天津' }
  ];

  /** 城市表：本地服务下发优先，其次数据包，最后兜底。 */
  function cityTable() {
    var live = (MCD.api && MCD.api.cities && MCD.api.cities()) || [];
    if (live.length) return live;
    var packed = (MCD.DATA && MCD.DATA.cities) || [];
    return packed.length ? packed : FALLBACK_CITIES;
  }

  function cityList() {
    return cityTable().map(function (c) { return c.city; });
  }

  /** 该城市的地标关键词（服务端候选链的首选；没有地标就用城市名）。 */
  function cityHint(city) {
    var hit = '';
    cityTable().forEach(function (c) { if (c.city === city) hit = c.keyword; });
    return hit || city || '市中心';
  }

  /** 按省份分组，供下拉罗列「所有城市」。 */
  function cityGroups() {
    var order = [];
    var bucket = {};
    cityTable().forEach(function (c) {
      var prov = c.province || '其他';
      if (!bucket[prov]) { bucket[prov] = []; order.push(prov); }
      bucket[prov].push(c);
    });
    return order.map(function (prov) { return { province: prov, items: bucket[prov] }; });
  }

  /** 本地服务能不能替我们去拉真实数据。 */
  function canSwitch() {
    return !!(MCD.api && MCD.api.live && MCD.api.live());
  }

  function snapCity() { return MCD.DATA.city || '深圳'; }
  function snapKeyword() { return MCD.DATA.keyword || ''; }
  function pickedCity() { return state.city || snapCity(); }
  function pickedKeyword() { return state.keyword == null ? snapKeyword() : state.keyword; }
  function cityMismatch() { return pickedCity() !== snapCity(); }

  /** 重新导出该城市真实数据的命令（没有本地服务时的退路）。 */
  function exportCommand(city) {
    var kw = pickedKeyword() || cityHint(city);
    return 'python -m src.main web --city ' + city + ' --keyword ' + kw;
  }

  function setLocatorStatus(kind, html) {
    var el = $('#locator-status');
    if (!el) return;
    if (!html) { el.hidden = true; el.innerHTML = ''; return; }
    el.hidden = false;
    el.className = 'locator-status' + (kind ? ' is-' + kind : '');
    el.innerHTML = html;

    var copy = el.querySelector('[data-copy-cmd]');
    if (copy) {
      copy.addEventListener('click', function () {
        var text = copy.getAttribute('data-copy-cmd');
        var flash = function () {
          copy.textContent = '已复制 ✓';
          setTimeout(function () { copy.textContent = '复制命令'; }, 1600);
        };
        if (window.navigator && navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(flash, flash);
        } else {
          flash();
        }
      });
    }

    // 有本地服务时，状态条上可以直接「立即切换并拉取」
    var sw = el.querySelector('[data-switch-city]');
    if (sw) {
      sw.addEventListener('click', function () {
        switchCityTo(sw.getAttribute('data-switch-city'));
      });
    }

    // 离线时给一个「重试连接」：服务刚起好，不用整页刷新就能原地恢复
    var retry = el.querySelector('[data-retry-probe]');
    if (retry) {
      retry.addEventListener('click', function () {
        retry.disabled = true;
        retry.textContent = '连接中…';
        Promise.resolve(MCD.api.probe()).then(function () {
          renderLocatorStatus();
          renderCityPicker();
          if (MCD.toast) {
            MCD.toast(MCD.api.live()
              ? '本地服务已连接，城市可以一键切换了'
              : '还是连不上：请确认 start.bat 已在运行（端口默认 8770）');
          }
        });
      });
    }
  }

  /** 状态条尾部的一枚小标：如实说明当前有没有「直接切城市」的能力。
   *
   *  离线时不能只丢一句「纯静态模式」——用户会以为功能被改没了（真实踩过）。
   *  这里把**为什么离线**和**怎么恢复**一并写出来：
   *    · file:// 打开 → 根本没有本地服务，必须改用启动脚本；
   *    · http 打开但探测不到 → 服务没在跑（或跑在别的端口），给一个「重试连接」。
   */
  function serviceChips() {
    var apiState = (MCD.api && MCD.api.state) || {};
    if (!apiState.probed) return '';
    if (!apiState.online) {
      var isFile = window.location.protocol === 'file:';
      return '<span class="ls-chip is-warn">📄 纯静态模式 · 换城市需重新导出</span>' +
        (isFile
          ? '<span class="ls-hint">你现在是<b>直接打开网页文件</b>（<code>file://</code>）：' +
            '门店 / 活动只能是固定快照，「一键切换城市」和地图定位都不会工作。' +
            '请关掉这个页面，改为双击项目根目录的 <b>start.bat</b>（macOS / Linux 用 start.command / start.sh）重新打开。</span>'
          : '<span class="ls-hint">本机服务没有在 <code>' + esc(window.location.origin) +
            '</code> 应答，所以城市切换与地图定位暂时不可用。' +
            '请在项目根目录双击 <b>start.bat</b> 启动服务（端口默认 8770），然后点右侧重试：' +
            '<button class="btn btn-outline btn-sm" data-retry-probe>重试连接</button></span>');
    }
    if (apiState.live) {
      return '<span class="ls-chip is-ok">🚀 本地服务已连接 · 点城市名可直接切换</span>';
    }
    return '<span class="ls-chip is-warn">🔌 本地服务在线，但未配置 MCD_MCP_TOKEN · 无法实时切城市</span>';
  }

  function renderLocatorStatus() {
    var chips = serviceChips();

    if (!cityMismatch()) {
      setLocatorStatus('ok',
        '<span>📍</span><span><b>当前数据快照：' + esc(snapCity()) +
        (snapKeyword() ? ' · ' + esc(snapKeyword()) : '') + '</b> —— 门店、菜单、活动、券都来自这一次真实查询。' +
        (canSwitch()
          ? '麦当劳 MCP 覆盖全国，点城市名就能直接换。'
          : '麦当劳 MCP 覆盖全国，换城市的方式见下拉里的说明。') +
        '</span>' + chips);
      return;
    }

    var city = pickedCity();
    var cmd = exportCommand(city);

    if (canSwitch()) {
      setLocatorStatus('warn',
        '<span>⚠️</span><span>地图视角在 <b>' + esc(city) + '</b>，但尚未拉取该城市数据 —— ' +
        '下面的门店 / 活动仍是 <b>' + esc(snapCity()) + '</b> 的，所以我没有把标记留在图上充数。' +
        '<button class="btn btn-primary btn-sm" data-switch-city="' + esc(city) + '">立即切换并拉取</button>' +
        '</span>' + chips);
      return;
    }

    setLocatorStatus('warn',
      '<span>⚠️</span><span>你选了 <b>' + esc(city) + '</b>，但页面里加载的是 <b>' + esc(snapCity()) +
      (snapKeyword() ? ' · ' + esc(snapKeyword()) : '') + '</b> 的快照 —— 下面的门店和活动都不是 ' + esc(city) +
      ' 的，所以我**没有**把标记留在图上充数。麦当劳 MCP 本身覆盖全国，换城市只要带 Token 重新导出一次：' +
      '<code class="cmd">' + esc(cmd) + '</code>' +
      '<button class="btn btn-outline btn-sm cmd-copy" data-copy-cmd="' + esc(cmd) + '">复制命令</button>' +
      '</span>' + chips);
  }

  function closeCityDrop() {
    var drop = $('#city-drop');
    if (drop) drop.hidden = true;
    var trigger = $('#city-trigger');
    if (trigger) trigger.setAttribute('aria-expanded', 'false');
  }

  /** 本地服务在线但没配 Token 时，就在下拉里把它补上 —— 不用去碰命令行。 */
  function needToken() {
    var s = (MCD.api && MCD.api.state) || {};
    return !!(s.probed && s.online && !s.live);
  }

  function tokenFormHTML() {
    return '<div class="city-token">' +
      '<p class="ct-lead">🔑 本地服务已经跑起来了，但还没有麦当劳 MCP Token —— ' +
      '把它填上，上面的城市就能「点一下就切」。</p>' +
      '<div class="ct-row">' +
      '<input id="token-input" type="password" autocomplete="off" spellcheck="false" ' +
      'placeholder="粘贴 MCD_MCP_TOKEN">' +
      '<button type="button" class="btn btn-primary btn-sm" id="token-save">保存并启用</button>' +
      '</div>' +
      '<p class="ct-note">Token 由本机服务写进项目根目录的 <code>.env</code>（已被 gitignore）：' +
      '不会进入浏览器存储，也不会随页面下发。</p>' +
      '<p class="ct-msg" id="token-msg" hidden></p>' +
      '</div>';
  }

  function saveToken() {
    var input = $('#token-input');
    var msg = $('#token-msg');
    var value = input ? input.value.trim() : '';
    var btn = $('#token-save');

    var show = function (text, kind) {
      if (!msg) return;
      msg.hidden = false;
      msg.className = 'ct-msg' + (kind ? ' is-' + kind : '');
      msg.textContent = text;
    };

    if (value.length < 10) {
      show('Token 看起来不完整，请粘贴完整值。', 'warn');
      if (input) input.focus();
      return;
    }

    if (btn) { btn.disabled = true; btn.textContent = '保存中…'; }
    show('正在保存…', 'ok');

    MCD.api.saveToken(value).then(function (res) {
      if (res && res.ok) {
        if (input) input.value = '';
        // 重新探测，让城市角标从「需先导出」变成「点一下切换」
        MCD.api.probe();
        if (MCD.toast) MCD.toast('Token 已保存，现在可以直接切换城市了');
        return;
      }
      if (btn) { btn.disabled = false; btn.textContent = '保存并启用'; }
      show((res && res.message) || '保存失败。', 'warn');
    });
  }

  function bindTokenForm() {
    var btn = $('#token-save');
    if (btn) {
      btn.addEventListener('click', function (evt) {
        evt.stopPropagation();
        saveToken();
      });
    }
    var input = $('#token-input');
    if (input) {
      input.addEventListener('keydown', function (evt) {
        if (evt.key === 'Enter') { evt.preventDefault(); saveToken(); }
      });
    }
  }

  /** 每个城市选项右上角的小标：如实反映「这个城市当前能不能看」。 */
  /** 单个城市按钮。城市太多（全国 300+），所以角标只在必要时出现：
   *  当前快照城市标一下，其余靠下拉顶部那句话统一说明，避免满屏都是角标。 */
  function cityOptHTML(c, cur, snap) {
    var isCur = c.city === cur;
    var isSnap = c.city === snap;
    return '<button type="button" class="city-opt' + (isCur ? ' is-on' : '') + '"' +
      ' data-city="' + esc(c.city) + '" role="option" aria-selected="' + (isCur ? 'true' : 'false') + '">' +
      '<span class="co-name">' + esc(c.city) + '</span>' +
      (isSnap ? '<span class="co-flag is-snap">当前快照</span>' : '') +
      '</button>';
  }

  /** 下拉里的城市清单（按省份分组；有关键词时改为平铺命中结果）。 */
  function cityGridHTML(query, cur, snap) {
    var q = (query || '').trim().toLowerCase();
    var table = cityTable();

    if (q) {
      var hits = table.filter(function (c) {
        return c.city.toLowerCase().indexOf(q) >= 0 ||
          (c.province || '').toLowerCase().indexOf(q) >= 0 ||
          (c.keyword || '').toLowerCase().indexOf(q) >= 0;
      });
      var body = hits.map(function (c) { return cityOptHTML(c, cur, snap); }).join('');
      // 表里没有完全匹配时，允许直接拿输入词当城市名去查（麦当劳 MCP 支持任意城市名）
      var exact = hits.some(function (c) { return c.city === query.trim(); });
      if (!exact) {
        body = '<button type="button" class="city-opt is-free" data-city="' + esc(query.trim()) + '">' +
          '<span class="co-name">直接查「' + esc(query.trim()) + '」</span>' +
          '<span class="co-flag is-live">自由输入</span></button>' + body;
      }
      return '<div class="city-grid">' + body +
        (hits.length ? '' : '<div class="city-none">城市表里没有匹配项，可点上面那条直接查。</div>') +
        '</div>';
    }

    return cityGroups().map(function (g) {
      return '<div class="city-sec">' +
        '<div class="cs-head">' + esc(g.province) + '<span>' + g.items.length + '</span></div>' +
        '<div class="city-grid">' +
        g.items.map(function (c) { return cityOptHTML(c, cur, snap); }).join('') +
        '</div></div>';
    }).join('');
  }

  /** 下拉顶部那句话：把「点了会发生什么」一次说清楚，取代逐条角标。 */
  function cityHeadHTML() {
    if (canSwitch()) {
      return '<b>点城市名即直接切换</b> —— 本地服务会用 .env 里的 Token ' +
        '实时调用麦当劳 MCP（点一下切换，通常十几秒）';
    }
    if (needToken()) {
      return '<b>需先导出</b> —— 本地服务在线但没有 MCD_MCP_TOKEN，' +
        '在下面粘贴一次即可升级为「点一下切换」';
    }
    return '<b>需先导出</b> —— 当前是纯静态模式（没有本地服务），' +
      '换城市会给出可复制的导出命令';
  }

  function renderCityPicker() {
    var cur = pickedCity();
    var snap = snapCity();
    var live = canSwitch();

    var label = $('#city-current');
    if (label) label.textContent = cur;
    var trigger = $('#city-trigger');
    if (trigger) {
      trigger.title = live
        ? '当前城市：' + cur + ' —— 本地服务已连接，点开可直接切换城市'
        : '当前城市：' + cur + '（数据快照在 ' + snap + '）';
    }

    var drop = $('#city-drop');
    if (!drop) return;
    drop.innerHTML =
      '<div class="city-drop-head">' + cityHeadHTML() + '</div>' +
      '<div class="city-search">' +
      '<input type="text" id="city-search" autocomplete="off" spellcheck="false" ' +
      'placeholder="搜索 ' + cityList().length + ' 座城市（名称 / 省份 / 地标）" aria-label="搜索城市">' +
      '<span class="cs-tip">共 ' + cityList().length + ' 座</span>' +
      '</div>' +
      '<div class="city-scroll" id="city-scroll">' + cityGridHTML('', cur, snap) + '</div>' +
      (needToken() ? tokenFormHTML() : '') +
      '<div class="city-drop-foot">' + (live
        ? '首次切换通常十几秒：服务端要逐店拉菜单，完成后自动刷新'
        : needToken()
          ? '也可以直接改项目根目录的 .env，然后重新双击启动脚本'
          : '想直接切？在 .env 里填好 MCD_MCP_TOKEN，再重新双击启动脚本即可') + '</div>';

    bindCityGrid(drop);
    bindCitySearch();
    bindTokenForm();
  }

  /** 城市按钮一律走事件委托 —— 列表会被搜索整段重建，绑子节点会失效。 */
  function bindCityGrid(drop) {
    if (drop._cityBound) return;
    drop._cityBound = true;
    drop.addEventListener('click', function (evt) {
      var btn = evt.target.closest && evt.target.closest('[data-city]');
      if (!btn || !drop.contains(btn)) return;
      evt.stopPropagation();
      var city = btn.getAttribute('data-city').trim();
      if (!city) return;
      closeCityDrop();
      if (city === pickedCity() && !cityMismatch()) return;   // 已经在这座城
      if (canSwitch()) { switchCityTo(city); return; }
      pickCityLocally(city);
    });
  }

  /** 搜索框：只重建列表容器，**绝不重建输入框本身**（否则中文输入法会被打断）。 */
  function bindCitySearch() {
    var box = $('#city-search');
    var scroll = $('#city-scroll');
    if (!box || !scroll || box._bound) return;
    box._bound = true;

    var paint = function () {
      var grid = $('#city-scroll');
      if (grid) grid.innerHTML = cityGridHTML(box.value, pickedCity(), snapCity());
    };
    var composing = false;

    box.addEventListener('compositionstart', function () { composing = true; });
    box.addEventListener('compositionend', function () { composing = false; paint(); });
    box.addEventListener('input', function () { if (!composing) paint(); });
    box.addEventListener('click', function (evt) { evt.stopPropagation(); });
    box.addEventListener('keydown', function (evt) {
      if (evt.key === 'Escape') { box.value = ''; paint(); }
    });
  }

  /** 没有实时能力时的本地落点：只切视图 + 给出导出命令，绝不假装拿到了数据。 */
  function pickCityLocally(city) {
    state.city = city;
    if (state.keyword == null) state.keyword = snapKeyword();
    var box = $('#keyword-input');
    // 不替用户填关键词：留空 = 让服务端走候选链（地标 → 城市名 → 市中心 → …），
    // 比前端猜一个更可靠。这里只把建议的地标放进 placeholder 提示一下。
    if (box && !box.value.trim()) box.placeholder = '留空则自动选点，如 ' + cityHint(city);
    renderCityPicker();
    applyCity();
  }

  /* ==========================================================================
     切换城市（真实调用）
     --------------------------------------------------------------------------
     这是「不用 bash 换城市」的实现：请求发给本地服务，由它带着 .env 里的
     Token 去麦当劳 MCP 拉这家城市的数据、重写 data.js，前端随后刷新。
     整个过程必须让用户看得见 —— 因为它可能真的要等一分钟。
     ========================================================================== */
  var switching = false;

  function ensureSwitchMask() {
    var el = $('#city-switch-mask');
    if (el) return el;
    el = document.createElement('div');
    el.id = 'city-switch-mask';
    el.className = 'switch-mask';
    el.hidden = true;
    document.body.appendChild(el);
    return el;
  }

  var SWITCH_STEPS = [
    'query-nearby-stores · 查该城市门店',
    'query-meals · 逐店拉菜单（最慢的一步）',
    'campaign-calendar / available-coupons',
    'order-list / query-my-account',
    'list-nutrition-foods / mall-points-products',
    '写入 web/data.js 并刷新页面'
  ];

  function switchCardHTML(city, note, seconds) {
    return '<div class="sw-card" role="dialog" aria-modal="true" aria-live="polite">' +
      '<div class="sw-spin" aria-hidden="true"></div>' +
      '<h3>正在切换到「' + esc(city) + '」</h3>' +
      '<p class="sw-note">' + esc(note) + '</p>' +
      (seconds == null ? '' : '<p class="sw-timer">已等待 <b>' + seconds + '</b> 秒</p>') +
      '<ul class="sw-steps">' + SWITCH_STEPS.map(function (s) {
        return '<li>' + esc(s) + '</li>';
      }).join('') + '</ul>' +
      '<p class="sw-hint">这是真实调用麦当劳 MCP，请保持启动脚本的窗口开着。</p>' +
      '</div>';
  }

  function openSwitchMask(city) {
    switching = true;
    var el = ensureSwitchMask();
    var started = Date.now();
    el.innerHTML = switchCardHTML(city, '正在请求本地服务…', 0);
    el.hidden = false;
    document.body.classList.add('has-switch');

    clearInterval(openSwitchMask._t);
    openSwitchMask._t = setInterval(function () {
      var box = el.querySelector('.sw-timer b');
      var secs = Math.round((Date.now() - started) / 1000);
      if (box) box.textContent = secs;
      var note = el.querySelector('.sw-note');
      if (note && secs > 4) note.textContent = '麦当劳 MCP 正在逐店返回菜单，快则十几秒，门店多时会久一些…';
    }, 1000);
  }

  function closeSwitchMask() {
    switching = false;
    clearInterval(openSwitchMask._t);
    var el = $('#city-switch-mask');
    if (el) { el.hidden = true; el.innerHTML = ''; }
    document.body.classList.remove('has-switch');
  }

  /** 失败时把遮罩变成一张「说清楚为什么」的卡，而不是一闪而过。 */
  function failSwitchMask(payload, city) {
    clearInterval(openSwitchMask._t);
    switching = false;
    var el = ensureSwitchMask();
    el.hidden = false;
    el.innerHTML = '<div class="sw-card is-error" role="alertdialog" aria-modal="true">' +
      '<div class="sw-icon">⚠️</div>' +
      '<h3>没能切换到「' + esc(city) + '」</h3>' +
      '<p class="sw-note">' + esc(payload.message || '未知错误') + '</p>' +
      (payload.hint ? '<p class="sw-hint">' + esc(payload.hint) + '</p>' : '') +
      '<p class="sw-hint">原有数据包没有被改动，你仍然可以正常浏览当前快照。' +
      '也可以点城市下拉里的「复制命令」，去终端手动导出。</p>' +
      '<div class="sw-actions"><button class="btn btn-primary" data-sw-close>知道了</button></div>' +
      '</div>';
    var btn = el.querySelector('[data-sw-close]');
    if (btn) btn.addEventListener('click', closeSwitchMask);
  }

  /**
   * 切城市。
   * @param {string} city
   * @param {{keepKeyword?: boolean}} [opts]
   *   keepKeyword = true 时保留输入框里的关键词（只有「刚点选候选」这一种场景：
   *   那次切换本来就是要拿这个 POI 去检索新城市的门店）。
   */
  function switchCityTo(city, opts) {
    if (switching) return;
    var keepKeyword = !!(opts && opts.keepKeyword);
    var box = $('#keyword-input');
    // 留空就把选点权交给服务端：它会按候选链挑第一个能查到门店的关键词。
    // 用户手打的就照用 —— 不替他改主意。
    var kw = (box && box.value.trim()) || '';
    var askedKw = kw;   // 记下用户原本要用的词，好在服务端换词时如实告知

    // 但「候选自动填进去」的那串字不属于这座城市：它只在那座城市有意义。
    // 实测血案：在深圳选了「深圳湾公园[地铁站]」，再从城市下拉切北京，
    // 这串字被当关键词发给北京 → MCP 在北京查不到 → 返回 0 家门店 →
    // 整座北京被判成「没有门店」，切换失败（页面弹「没能切换到北京」）。
    // 所以从城市下拉切城市时，自动填的关键词必须丢掉，交回服务端的候选链。
    if (kw && locatorAutoFilled && !keepKeyword) {
      kw = '';
      askedKw = '';   // 这是系统自己填的，不算用户「问过」的词，不必提示
      if (box) box.value = '';
      locatorAutoFilled = false;
      closeSuggest();
    }

    openSwitchMask(city);

    MCD.api.switchCity(city, kw).then(function (res) {
      res = res || {};

      if (res.ok) {
        var el = ensureSwitchMask();
        clearInterval(openSwitchMask._t);
        // 用户明确填了的词在目标城市查不到、服务端自动换词了 → 必须说清楚，
        // 否则用户会以为自己填的词生效了（下一个坑）。
        var dropped = (res.explicit_keyword_dropped && askedKw)
          ? '<p class="sw-note">你填的关键词「' + esc(askedKw) + '」在「' + esc(city) +
            '」查不到门店，已自动改用「' + esc(res.matched_keyword || res.keyword || '') + '」。</p>'
          : '';
        el.innerHTML = '<div class="sw-card is-done" role="status">' +
          '<div class="sw-icon">✅</div>' +
          '<h3>' + esc(res.message || ('已切换到「' + city + '」')) + '</h3>' +
          dropped +
          '<p class="sw-note">数据源：' + esc(res.source || '') +
          (res.elapsed != null ? ' · 耗时 ' + res.elapsed + ' 秒' : '') + '</p>' +
          '<p class="sw-hint">正在刷新页面…</p></div>';
        setTimeout(function () { window.location.reload(); }, 900);
        return;
      }

      if (res.unchanged) {
        closeSwitchMask();
        pickCityLocally(city);
        if (MCD.toast) MCD.toast(res.message || '已经在这座城市了');
        return;
      }

      failSwitchMask(res, city);
    });
  }

  /** 本地服务能力就绪后，把城市 UI 重画一遍（角标从「需先导出」变「点一下切换」）。 */
  if (MCD.api && MCD.api.onChange) {
    MCD.api.onChange(function () {
      renderCityPicker();
      renderLocatorStatus();
    });
  }

  function blankRadar(city) {
    var svg = $('#radar-svg');
    if (!svg) return;
    svg.innerHTML =
      '<text x="310" y="218" text-anchor="middle" font-size="13" fill="#9a9186">' +
      '「' + esc(city) + '」暂无已导出数据</text>' +
      '<text x="310" y="242" text-anchor="middle" font-size="11" fill="#b8b0a6">' +
      '距离雷达图只在快照城市下绘制</text>';
  }

  /** 城市变更后的统一落点：状态条 + 地图 + 两侧面板。
   *
   *  返回 Promise：定位输入框选中候选后要**等这次挪动结束后**再把视角钉到
   *  用户选的那个点，否则会被这里异步的 moveTo / locate 覆盖掉。
   */
  function applyCity() {
    renderLocatorStatus();
    MCD.map.clearRoute();

    var mapWork;
    if (!cityMismatch()) {
      banner('');
      if (MCD.map.ready()) {
        mapWork = MCD.map.locate(banner).then(function () {
          MCD.map.drawMarkers(bestStoreCode());
          MCD.map.fit();
        });
      } else {
        MCD.map.radar($('#radar-svg'), data.nearbyRows(), bestStoreCode());
        mapWork = Promise.resolve();
      }
    } else {
      banner('地图视角已切到「' + pickedCity() + '」，但门店数据属于「' + snapCity() +
        '」的快照，标记已清空 —— 重新导出后即可看到该城市真实门店。', 'warn');
      if (MCD.map.ready()) {
        MCD.map.clearMarkers();
        mapWork = MCD.map.moveTo(pickedCity(), pickedKeyword(), banner);
      } else {
        blankRadar(pickedCity());
        mapWork = Promise.resolve();
      }
    }

    renderLeft();
    renderRight();
    if (MCD.chrome && MCD.chrome.refresh) MCD.chrome.refresh();

    return Promise.resolve(mapWork).catch(function () { /* 地图没跟上不该拖垮界面 */ });
  }

  /** 非快照城市时，左侧面板的简版说明（右侧有完整版）。 */
  function mismatchMiniHtml() {
    var city = pickedCity();
    return '<div class="city-mismatch is-compact">' +
      '<div class="cm-icon">🧭</div>' +
      '<h3>「' + esc(city) + '」' + (canSwitch() ? '尚未拉取' : '暂无快照数据') + '</h3>' +
      '<p>本页的门店 / 菜单 / 活动都来自 <b>' + esc(snapCity()) +
      (snapKeyword() ? ' · ' + esc(snapKeyword()) : '') + '</b> 那一次查询，所以这里不展示 ' +
      esc(city) + ' 的内容。</p>' +
      (canSwitch()
        ? '<button class="btn btn-primary btn-sm" data-switch-city="' + esc(city) + '">立即切换并拉取</button>'
        : '<p>右侧有该城市的重新导出命令。</p>') +
      '<button class="btn btn-outline btn-sm" data-city-reset>切回 ' + esc(snapCity()) + '</button>' +
      '</div>';
  }

  /** 非快照城市时，两侧面板换成「怎么拿到该城市数据」的说明卡。 */
  function mismatchCardHtml() {
    var city = pickedCity();
    var cmd = exportCommand(city);
    var live = canSwitch();

    var lead = live
      ? '<p>本页的门店、菜单、活动、券全部来自 <b>' + esc(snapCity()) +
        (snapKeyword() ? ' · ' + esc(snapKeyword()) : '') + '</b> 那一次真实查询的快照。' +
        '本地服务已经连上了，点下面的按钮，它会带着 .env 里的 Token 去麦当劳 MCP ' +
        '实时拉一次「' + esc(city) + '」，拉完自动刷新页面。</p>'
      : '<p>本页的门店、菜单、活动、券全部来自 <b>' + esc(snapCity()) +
        (snapKeyword() ? ' · ' + esc(snapKeyword()) : '') + '</b> 那一次真实查询的快照。' +
        '与其把 ' + esc(snapCity()) + ' 的店摆在 ' + esc(city) + ' 的地图上看，不如直接告诉你实情。</p>';

    var howto = live
      ? '<p class="cm-dim">也可以在终端里重新导出（等价于上面的按钮）：</p>'
      : '<p>麦当劳 MCP 是覆盖全国的 —— 我用 <code>query-nearby-stores</code> 实测过：' +
        '上海「人民广场」返回黄浦华旭国际大厦等 5 家，北京「国贸」返回建外 SOHO 等 5 家，' +
        '广州「天河城」、杭州「西湖」同样有真实门店。换城市只需要带 Token 重新导出一次：</p>';

    return '<div class="city-mismatch">' +
      '<div class="cm-icon">🧭</div>' +
      '<h3>「' + esc(city) + '」' + (live ? '尚未拉取' : '还没有导出数据') + '</h3>' +
      lead + howto +
      '<code class="cmd">' + esc(cmd) + '</code>' +
      '<button class="btn btn-outline btn-sm cmd-copy" data-copy-cmd="' + esc(cmd) + '">复制命令</button>' +
      (live
        ? '<button class="btn btn-primary btn-sm" data-switch-city="' + esc(city) +
          '">立即切换并拉取</button>'
        : '<p class="cm-dim">还没有配置 MCD_MCP_TOKEN？把 .env.example 复制成 .env，' +
          '填好 Token 后重新双击启动脚本，城市下拉里就能直接点了。</p>') +
      '<p class="cm-back">看回快照城市：' +
      '<button class="btn btn-primary btn-sm" data-city-reset>切回 ' + esc(snapCity()) + '</button></p>' +
      '</div>';
  }

  function bindCityReset(root) {
    util.$$('[data-city-reset]', root).forEach(function (btn) {
      btn.addEventListener('click', function () {
        state.city = null;
        state.keyword = null;
        var box = $('#keyword-input');
        if (box) box.value = snapKeyword();
        renderCityPicker();
        applyCity();
      });
    });
    util.$$('[data-switch-city]', root).forEach(function (btn) {
      btn.addEventListener('click', function () {
        switchCityTo(btn.getAttribute('data-switch-city'));
      });
    });
  }

  /* ==========================================================================
     定位输入框：输入地点名 → 腾讯候选下拉（5 条）→ 点一条即定位 + 全量同步
     --------------------------------------------------------------------------
     候选来自本地服务 ``/api/suggest``（服务端转发腾讯「关键词输入提示」），
     不是浏览器直连 —— Key 不出服务端，白名单也由服务端转发 Referer 命中。

     选中一条候选做三件事，这才是「地区同步」的完整含义：
       ① 地图立刻落到该点坐标（坐标是候选自带的，不用再等一次检索）；
       ② 城市 / 关键词换成该候选 —— 关键词用 POI 名，定位比城市名准得多；
       ③ 有本地服务时按新城市 + 新关键词重拉一次数据，于是门店、距离、
          步行 / 驾车时长、抵达时间、活动日历**全部**跟着换过去。
     ========================================================================== */
  var SUGGEST_LIMIT = 5;
  var suggestState = { items: [], active: -1, timer: null, seq: 0, open: false, note: '' };
  //: 最近一次「选中候选」的完成 Promise —— 点候选之后要等它才知道定位到位没有
  var lastPick = Promise.resolve(false);
  //: 输入框里当前那串字是不是「选候补自动填进去的」。
  //  为什么必须区分：候选只属于它所在的那座城市。实测血案 —— 在深圳选了
  //  「深圳湾公园[地铁站]」，再去城市下拉切北京，这串字被当成检索关键词发给北京，
  //  麦当劳 MCP 在北京找不到「深圳湾公园」→ 返回 0 家门店 → 整座北京被判成
  //  「没有门店」，切换失败。用户手打的则保留（那是明确意图，例如填「海拉尔」再切呼伦贝尔）。
  var locatorAutoFilled = false;

  /** 把输入框包一层，好在它正下方挂绝对定位的下拉（CSS 只认「相对定位的父级」）。 */
  function ensureSuggestBox() {
    var input = $('#keyword-input');
    if (!input) return null;
    var box = $('#loc-suggest');
    if (!box) {
      var wrap = input.parentNode;
      if (!wrap || !wrap.classList || !wrap.classList.contains('kw-wrap')) {
        wrap = document.createElement('div');
        wrap.className = 'kw-wrap';
        input.parentNode.insertBefore(wrap, input);
        wrap.appendChild(input);
      }
      box = document.createElement('div');
      box.id = 'loc-suggest';
      box.className = 'loc-suggest';
      box.hidden = true;
      box.setAttribute('role', 'listbox');
      wrap.appendChild(box);
    }
    return box;
  }

  /** 腾讯返回的 city 是「深圳市」「上海市」这类写法，转回城市表里的标准名。 */
  function cityFromSuggestion(raw) {
    var name = String(raw || '').trim();
    if (!name) return '';
    var table = cityTable();
    var i;
    for (i = 0; i < table.length; i++) if (table[i].city === name) return name;
    var stripped = name.replace(/市$/, '');
    for (i = 0; i < table.length; i++) if (table[i].city === stripped) return stripped;
    for (i = 0; i < table.length; i++) {
      if (stripped && table[i].city.indexOf(stripped) === 0) return table[i].city;
    }
    return stripped || name;
  }

  function closeSuggest() {
    var box = $('#loc-suggest');
    if (box) { box.hidden = true; box.innerHTML = ''; }
    suggestState.open = false;
    suggestState.active = -1;
  }

  /** 画候选列表。``note`` 有值时显示一行灰字（例如「没搜到」/「腾讯拒绝了」）。 */
  function renderSuggest(items, note) {
    var box = ensureSuggestBox();
    if (!box) return;
    suggestState.items = items || [];
    suggestState.active = suggestState.items.length ? 0 : -1;
    suggestState.note = note || '';

    if (!suggestState.items.length && !note) { closeSuggest(); return; }

    var rows = suggestState.items.map(function (it, i) {
      return '<button type="button" class="loc-item' + (i === 0 ? ' is-active' : '') +
        '" data-idx="' + i + '" role="option" aria-selected="' + (i === 0 ? 'true' : 'false') + '">' +
        '<span class="li-pin" aria-hidden="true">📍</span>' +
        '<span class="li-main"><span class="li-title">' + esc(it.title) + '</span>' +
        '<span class="li-addr">' + esc(it.address || '暂无地址') + '</span></span>' +
        (it.city || it.district
          ? '<span class="li-city">' + esc((it.city || '').replace(/市$/, '') + (it.district ? ' · ' + it.district : '')) + '</span>'
          : '') +
        '</button>';
    }).join('');

    box.innerHTML = rows +
      (note ? '<div class="loc-note">' + esc(note) + '</div>' : '') +
      '<div class="loc-foot">数据来源：腾讯位置服务「关键词输入提示」· 点一条即定位并同步该地区数据</div>';
    box.hidden = false;
    suggestState.open = true;
  }

  function highlightSuggest(idx) {
    var box = $('#loc-suggest');
    if (!box || !suggestState.items.length) return;
    var n = suggestState.items.length;
    suggestState.active = ((idx % n) + n) % n;
    util.$$('.loc-item', box).forEach(function (node) {
      var i = parseInt(node.getAttribute('data-idx'), 10);
      var on = i === suggestState.active;
      node.classList.toggle('is-active', on);
      node.setAttribute('aria-selected', on ? 'true' : 'false');
    });
  }

  /** 选一条候选：定位 + 切城市/关键词 + 重拉数据。返回 Promise（完成即定位到位）。 */
  function pickSuggestion(item) {
    if (!item) return Promise.resolve(false);
    closeSuggest();
    // 用掉就清空，避免「重新定位」再点到上一次的陈旧候选
    suggestState.items = [];

    var input = $('#keyword-input');
    if (input) {
      input.value = item.title || '';
      locatorAutoFilled = true;   // 标记：这串字是程序填的，跨城市时必须丢掉
    }

    state.city = cityFromSuggestion(item.city) || pickedCity();
    state.keyword = item.title || state.city;
    renderCityPicker();
    renderLocatorStatus();

    // 地图立刻落点（坐标是候选自带的，不用再等一次检索）
    if (MCD.map && MCD.map.focus) MCD.map.focus(item.lat, item.lng, 15);

    // 有本地服务 → 按新城市 + 新关键词真的重拉一次：门店、距离、步行 / 驾车时长、
    // 抵达时间、活动日历会**一起**换到新地点。这就是「地区同步」。
    if (canSwitch()) {
      banner('已定位到「' + item.title + '」，正在同步「' + state.city + '」的门店与活动…', 'info');
      switchCityTo(state.city, { keepKeyword: true });   // 它会读 #keyword-input 的值作为关键词
      lastPick = Promise.resolve(true);
      return lastPick;
    }

    // 纯静态：只能挪视角，数据不会跟着变 —— 如实说清楚，并把定位钉在用户选的点上
    banner('已把地图定位到「' + item.title + '」。当前是纯静态模式，' +
      '要靠这个地点重新拉门店 / 活动数据，请点城市下拉里的「复制命令」跑一次导出。', 'warn');
    lastPick = applyCity().then(function () {
      if (MCD.map && MCD.map.focus) MCD.map.focus(item.lat, item.lng, 15);
      return true;
    });
    return lastPick;
  }

  /** 逗号分隔输入：一次给出若干候选（服务端可用时走真实检索）。 */
  function runSuggest(query) {
    var kw = (query || '').trim();
    if (kw.length < 1) { closeSuggest(); return; }

    if (!MCD.api || !MCD.api.suggest) {
      renderSuggest([], '定位服务不可用：请用启动脚本打开页面（file:// 下无法调用本地服务）。');
      return;
    }

    var seq = ++suggestState.seq;
    MCD.api.suggest(kw, pickedCity(), SUGGEST_LIMIT).then(function (res) {
      if (seq !== suggestState.seq) return;      // 有更新的请求了，丢弃这次结果
      var input = $('#keyword-input');
      if (!input) return;
      // 用户已经改了输入框（敲了别的字）→ 这次结果作废
      var now = input.value.trim();
      if (now && now !== kw) return;

      if (res && res.items && res.items.length) { renderSuggest(res.items, ''); return; }
      renderSuggest([], (res && res.message) || '没搜到这个地点，换个说法试试（如「人民广场」）。');
    });
  }

  function bindSuggest() {
    var input = $('#keyword-input');
    if (!input || input._suggestBound) return;
    input._suggestBound = true;
    ensureSuggestBox();

    var composing = false;
    var fire = function (delay) {
      clearTimeout(suggestState.timer);
      suggestState.timer = setTimeout(function () { runSuggest(input.value); }, delay);
    };

    input.addEventListener('compositionstart', function () { composing = true; });
    input.addEventListener('compositionend', function () { composing = false; fire(60); });
    input.addEventListener('input', function () {
      // 用户动手打字/删字了 → 这串字已经是他的意图，不再是「候选自动填的」
      locatorAutoFilled = false;
      if (!composing) fire(260);
    });
    input.addEventListener('focus', function () { if (input.value.trim()) fire(60); });

    input.addEventListener('keydown', function (evt) {
      if (!suggestState.open) {
        if (evt.key === 'ArrowDown' && input.value.trim()) { fire(0); evt.preventDefault(); }
        return;
      }
      if (evt.key === 'ArrowDown') { evt.preventDefault(); highlightSuggest(suggestState.active + 1); }
      else if (evt.key === 'ArrowUp') { evt.preventDefault(); highlightSuggest(suggestState.active - 1); }
      else if (evt.key === 'Escape') { closeSuggest(); }
      else if (evt.key === 'Enter') {
        if (suggestState.active >= 0 && suggestState.items[suggestState.active]) {
          evt.preventDefault();
          pickSuggestion(suggestState.items[suggestState.active]);
        }
      }
    });

    // 用 mousedown 而不是 click：blur 会先于 click 触发，把下拉收掉就点不到了
    var box = $('#loc-suggest');
    if (box && !box._bound) {
      box._bound = true;
      box.addEventListener('mousedown', function (evt) {
        var btn = evt.target.closest && evt.target.closest('.loc-item');
        if (!btn) return;
        evt.preventDefault();
        evt.stopPropagation();
        pickSuggestion(suggestState.items[parseInt(btn.getAttribute('data-idx'), 10)]);
      });
      box.addEventListener('click', function (evt) { evt.stopPropagation(); });
    }

    input.addEventListener('blur', function () {
      setTimeout(closeSuggest, 180);
    });
  }

  /** 「重新定位」按钮：把输入框里的地名当成关键词，真的重拉一次数据。 */
  function submitLocator() {
    var input = $('#keyword-input');
    var kw = input ? input.value.trim() : '';
    closeSuggest();

    if (kw && suggestState.items.length) {
      // 有候选时按第一条走，行为和「点第一项」一致，避免用户以为没反应
      pickSuggestion(suggestState.items[0]);
      return;
    }
    if (!kw && !cityMismatch()) return;   // 快照城市 + 空关键词：没必要重新定位

    state.keyword = kw || snapKeyword();
    state.city = pickedCity();

    if (kw && canSwitch()) {
      banner('正在用「' + kw + '」重新同步门店与活动…', 'info');
      // 「重新定位」是用户对输入框的显式动作 → 框里写什么就用什么，不丢关键词
      switchCityTo(pickedCity(), { keepKeyword: true });
      return;
    }
    applyCity();
  }

  function bindLocator() {
    renderCityPicker();
    renderLocatorStatus();
    bindSuggest();

    var trigger = $('#city-trigger');
    if (trigger) {
      trigger.addEventListener('click', function (evt) {
        evt.stopPropagation();
        var drop = $('#city-drop');
        if (!drop) return;
        var willOpen = drop.hidden;
        drop.hidden = !willOpen;
        trigger.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
      });
    }
    document.addEventListener('click', function (evt) {
      if (evt.target.closest && evt.target.closest('#city-picker')) return;
      closeCityDrop();
      if (!(evt.target.closest && evt.target.closest('.kw-wrap'))) closeSuggest();
    });
    document.addEventListener('keydown', function (evt) {
      if (evt.key === 'Escape') { closeCityDrop(); closeSuggest(); }
    });

    var form = $('#locator-form');
    if (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        submitLocator();
      });
    }
  }

  /* 对外：定位能力（供页面与测试驱动，不必真的联网） */
  MCD.locate = {
    search: runSuggest,
    render: renderSuggest,
    pick: pickSuggestion,
    close: closeSuggest,
    items: function () { return suggestState.items.slice(); },
    open: function () { return suggestState.open; },
    submit: submitLocator,
    /** 最近一次选中候选的完成 Promise（点完之后 await 它即可断言定位结果） */
    lastPick: function () { return lastPick; }
  };


  function render() {
    renderLeft();
    renderRight();
    renderCalendar();
    renderMapMarkers();
    // 悬浮球上写着「将要下单的门店」，选择一变就得同步
    if (MCD.chrome && MCD.chrome.refreshFab) MCD.chrome.refreshFab();
  }

  function renderMapMarkers() {
    if (cityMismatch()) {
      // 选中的城市没有快照数据：绝不把别城的门店标记留在图上
      if (MCD.map.ready()) MCD.map.clearMarkers();
      else blankRadar(pickedCity());
      return;
    }
    if (MCD.map.ready()) MCD.map.drawMarkers(bestStoreCode());
    else MCD.map.radar($('#radar-svg'), data.nearbyRows(), bestStoreCode());
  }

  /* ------------------------------------------------------------ 对外 */
  var views = (MCD.views = MCD.views || {});

  var chromeBound = false;
  var mapBooted = false;

  /** 首次进入首页时才初始化地图与定位；之后只重绘标记，避免反复发检索请求。 */
  function ensureMap() {
    if (mapBooted) {
      if (cityMismatch()) {
        if (MCD.map.ready()) MCD.map.clearMarkers();
        else blankRadar(pickedCity());
        return;
      }
      if (MCD.map.ready()) MCD.map.drawMarkers(bestStoreCode());
      else MCD.map.radar($('#radar-svg'), data.nearbyRows(), bestStoreCode());
      return;
    }
    mapBooted = true;

    var box = $('#tmap');
    var fb = $('#radar-fallback');

    if (MCD.map.init()) {
      if (box) box.style.display = '';
      if (fb) fb.hidden = true;
      MCD.map.setSelectHandler(selectStore);
      if (cityMismatch()) {
        MCD.map.clearMarkers();
        MCD.map.moveTo(pickedCity(), pickedKeyword(), banner);
        return;
      }
      MCD.map.locate(banner).then(function () {
        MCD.map.drawMarkers(bestStoreCode());
        MCD.map.fit();
      }).catch(function () {
        MCD.map.drawMarkers(bestStoreCode());
      });
      return;
    }

    if (box) box.style.display = 'none';
    if (fb) fb.hidden = false;
    var head = fb && fb.querySelector('.radar-head span');
    if (head) {
      head.textContent = '腾讯地图未就绪（离线打开或未配置 Key 时的正常降级）· 位置按真实距离等比排布，点击门店同样可查看信息。';
    }
    if (cityMismatch()) blankRadar(pickedCity());
    else MCD.map.radar($('#radar-svg'), data.nearbyRows(), bestStoreCode());
  }

  views.radar = {
    render: function () {
      renderTopbar();
      if (!chromeBound) {
        bindModeTabs();
        bindLocator();
        chromeBound = true;
      }
      render();
      util.$$('.mode-tab', $('#mode-tabs')).forEach(function (b) {
        b.classList.toggle('is-active', b.getAttribute('data-mode') === state.mode);
      });
      ensureMap();
    }
  };
})(window.MCD);
