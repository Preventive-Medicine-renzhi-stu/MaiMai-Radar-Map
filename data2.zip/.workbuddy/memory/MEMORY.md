# 麦麦雷达地图 · 项目长期约定

## 地图（`web/map.js`）
- **任何地图落点都必须走 `cityCoord(数据包城市)`，禁止硬编码中心点。**
  历史 bug：雷达首页与结果页小地图都曾写死 `DEFAULT_CENTER`（深圳南山），
  表现是「切到别的城市，地图还停在深圳」。雷达页已修两轮，`routeMap` 是第二轮才补上的。
  新增地图实例时，请一并暴露 `xxx.currentCenter()` 或 `MCD.map.debug()` 作为可断言出口。
- 地图有三种状态：Key 模式（`.env` 的 `TMAP_KEY` → `web/tmap-key.local.js`）、
  WorkBuddy 代理模式、纯本地 SVG 距离雷达图降级。**任何一步缺失都不许白屏**。
- 麦当劳 MCP **不返回门店经纬度**（`longitude/latitude` 恒为 `0.0`），门店坐标靠腾讯「地点搜索」补位；
  搜不到时按距离等比示意排布，并给出 warn 横幅如实说明。
- ⚠️ **GL JS「服务类库」的 `TMap.service.Search` 没有 `search()` 方法！**
  只有 `searchRegion` / `searchNearby` / `searchRectangle` / `explore` / `here` / `searchPoiId`。
  写成 `svc.search({...})` 会抛 `svc.search is not a function`，被 Promise 里的 `catch` **静默吞掉**
  —— 表现是「接口通了、门店坐标永远取不到、`exact` 恒为 0」，极难查。
  正确写法：`svc.searchRegion({ keyword: kw, boundary: 'region(' + city + ',0)' })`，
  参数名是 **`boundary`** 不是 `region`，末位 `0` = 范围不足自动扩页。
  注意 `TMap.service.Driving` **确实**有 `search()`（`drv.search({from, to})`），别一起改坏。
  `tests/css_coverage.js` 已加静态防线（在 `Search` 实例上误调 `.search(` 直接报红）。

## 腾讯位置服务 Key（2026-10-10 实测）
- Key 类型：**JS API GL 授权正常**（底图、控件、标记都渲染，无鉴权失败提示）。
- **WebServiceAPI 起初全部 110**（地点搜索 / 驾车路线 / 逆地址解析 / IP 定位，
  连 Referer 为 `lbs.qq.com` 也被拒）→ 原因是控制台**域名白名单**没配，不是代码问题。
- **2026-10-10 已修**：控制台在「WebServiceAPI → 域名白名单」填入 `127.0.0.1` + `localhost` 后，
  四个接口全部 `status:0`。剩下唯一障碍是**端口参与匹配**（见下节）。
- 判别 110 与 199 的意义：**199 = Key 未开启 WebService 功能**；110 = 卡在白名单。
- 本机出口公网 IP（配授权IP 时可参考）：`218.104.71.202`。
- 排查手法：真 key vs 伪造 key 各开一张 GL 地图截图对照 ——
  假 key 会出现「当前产品鉴权失败，请检查KEY及相关信息是否准确。」覆盖层。

### 白名单具体填什么（2026-10-10 查证官方 FAQ 后确定）
项目调用路径：`web/map.js` 的 `poiSearch()` → `TMap.service.Search` / `TMap.service.Driving`
→ **由浏览器（GL SDK 的 JSONP）发起**，没有任何服务端直连 `apis.map.qq.com`。
→ 所以要配的是 **「域名白名单」**，不是「授权IP」。

官方对三项安全设置的原文定义：
| 设置项 | 适用场景 | 留空含义 | 报错 |
|---|---|---|---|
| **域名白名单** | **浏览器端 JSONP 调 WebServiceAPI**（本项目） | 留空 = 不限制调用来源 | 110 |
| 授权IP | 服务端调用（本项目用不到） | 留空 = 不限制 | 112 |
| SN 校验 | 服务端 + 要算 sig（本项目不用） | — | 111 |

- 填法：**每行一条，只写裸域名**，不要带 `http://`、不要带路径；
  填 `qq.com` 则其子域名 `map.qq.com` 一并授权。→ 本项目填 `127.0.0.1` 与 `localhost`。
- **域名白名单不支持通配符**：只做「字面域名 + 其子域名」匹配，填 `*` 匹配不到任何请求，
  结果仍是 110。想让所有域名都能用，正确做法是**把框清空**（官方：留空则不限制），不是填 `*`。
- 控制台路径：`lbs.qq.com` → 控制台 → 应用管理 → 我的应用 → 该 Key → 设置 →
  「启用产品」勾选 **WebServiceAPI** → 勾选后才会出现安全设置区块。

### ⚠️ 关键：端口会参与白名单匹配（2026-10-10 实测 → 已解决）
白名单里填裸域名**只匹配「不带端口」的来源**。实测（白名单含 `127.0.0.1` 与 `localhost`）：

| 请求 Referer | 结果 |
|---|---|
| `http://127.0.0.1/` | ✅ `status:0` |
| `http://localhost/` | ✅ `status:0` |
| `http://localhost:8770/` | ❌ 110 |
| `http://localhost:1234/` | ❌ 110 |
| `http://localhost:80/`（显式写默认端口也失败） | ❌ 110 |
| 完全不带 Referer | ❌ 110「此次请求无来源信息」 |

**✅ 已解决（2026-10-10）**：在白名单里**再补两行带端口的条目**即可 ——
`127.0.0.1:8770` 与 `localhost:8770`。**腾讯的匹配是「host:port 字面串」比较**，
带端口的域名写在白名单里也认（官方 FAQ 未写这条，属实测结论）。
补完后四个接口全部 `status:0`，本项目即按此配置落地。

- 复测命令（`Referer` 必须带上，否则必然 110）：
  `curl -s -H "Referer: http://127.0.0.1:8770/" "https://apis.map.qq.com/ws/place/v1/search?keyword=人民广场&boundary=region(上海,0)&key=<KEY>"`
- **`121 此key每日调用量已达到上限` 是瞬时抖动**，同一请求重试即过，不要误判成配额用完。
- 备选路（未采用，仅记录）：① 服务跑 80 端口（已验证可绑定、Referer 变不带端口直接命中）；
  ② 由 `src/serve.py` 代理腾讯接口并在请求头自带 `Referer`（最彻底，可把 Key 撤回服务端）。

## 免 key 兜底链路（2026-10-10 实测，尚**未**接入代码）
当腾讯 WebServiceAPI 不可用时，有一条**零 key / 零注册 / 零实名**的完整替代链路：
- **门店坐标** → OSM `Overpass API`，`https://overpass-api.de/api/interpreter`（GET + `data=`）。
  `nwr["name"~"麦当劳"](bbox);out center N;` 返回坐标。实测上海 66 条、北京 242、广州 453、
  深圳 267、成都 47、呼伦贝尔 2、喀什 0 → **主要城市可用，边远城市稀疏**。
  必须过滤 `name` 含「麦当劳叔叔之家」的（慈善机构，非门店）。
  匹配优先级：门牌号精确 > 路名 > 店名相似度。
- **驾车路线** → OSRM 公共服，`https://router.project-osrm.org/route/v1/driving/{lng},{lat};{lng},{lat}?overview=full&geometries=geojson`。
  全国实测可用，返回 GeoJSON 折点，能直接画到腾讯 GL 地图上。备选 Valhalla `https://valhalla1.openstreetmap.de/route`。
- 端到端已验证：人民广场 → 福州路666号 店，1099 米 / 133 秒 / 35 折点。

**踩坑：Overpass 公共镜像大多是坏的，别拿它当判据。**
`overpass.osm.ch` 会 HTTP 200 但**恒返回 0 条**（假数据）；`overpass.private.coffee` 限速会 500；
`overpass.kumi.systems` / `osm.jp` / `mail.ru` 不可用。**可信的是 `overpass-api.de`**（偶发 504，重试即可）。
判断镜像是否可信的方法：用纽约 / 伦敦这类**必然有数据**的地区做基准对照。

**其他候选的实测结论（别再重复试）**
- `photon.komoot.io`（免 key）：中文门牌地址**返回空** → 不能做中文地理编码。
- `Nominatim`：中文门牌覆盖同样弱。
- `Overture Maps`（免 key 公开 S3）：places 单文件约 700MB、全球分片，实时查询要扫数十 GB → 只适合一次性离线构建。
- **高德 / 百度不是「零配置」**：都要实名认证 + Key 绑白名单，属「同一个坑换个控制台」，只是免费额度更大
  （高德约 30 万次/日 vs 腾讯约 1 万次/日）。
- 麦乐送 `delivery-query-stores` 是否带坐标**未验证**（测它需要先造一个配送地址）。

## 本地服务与端口（2026-10-10 踩过大坑）
- **绝不在会话里留常驻后台服务占着 8770**（那是写进腾讯白名单的端口）。
  Windows 的 `allow_reuse_address` 允许**两个进程同时 bind 同一端口**，
  于是「再双击一次 start.bat」会悄悄多起一个实例抢连接 → 页面时好时坏。
  验完就停；确实需要常驻时明确告知用户。
- `src/serve.py` 的 `probe_existing_service(port)`：监听前先探 `/api/status`，
  已经是 `mcd-radar-local` 就**复用**，不再起第二个实例。
  探测必须用 `ProxyHandler({})` 绕开 `http_proxy`，否则回环请求会被代理带走。
- **端口 != 8770 时地图会「看起来正常但取不到数据」**：腾讯白名单按 host:端口精确匹配，
  换端口就得补白名单，否则地点搜索 / 驾车路线 / 定位候选全被拒。
- 页面离线时必须自曝「为什么 + 怎么办」：`file://` → 提示改用 start.bat；
  http 探测不到 → 给「重试连接」按钮（`[data-retry-probe]`）。只丢一句「纯静态模式」
  会被用户读成「功能被改没了」。

## 版本控制（2026-10-10 建立，此前没有）
- **已有 git**：主干 `main`，一次提交 + 标签 **`working-2026-10-10`**
  （本机实测跑通的基线：城市实时切换 / 驾车路线 / 定位候选 5 选 1 全通）。
  用户说「退回上一版」时先看 `git tag -l`，再决定 `git checkout <tag>` 还是精确 `git diff`。
- **⛔ 这个仓库禁止推送到任何公开平台**：用户选择把 `web/data.js` 完整入库，
  里面是真实 `account_id` / 真实订单号。要开源必须先 `--demo` 脱敏
  （命令写在 `.gitignore` 末尾注释里）。
- **不入库**：`.env`、`web/tmap-key.local.js`、`.venv/`、`.tmp/`、`.tmp_geo/`、
  `.workbuddy/`、`_dom.tmp.html`、`web/__*.html`、`_shot*.png`。
- **实测血案（别再犯）**：
  ① 我曾把 `.workbuddy/memory/*.md` 提交进去，而这些笔记里**明文抄了 TMAP_KEY**
     → 只能靠 `git rm --cached` + `commit --amend` + `reflog expire` + `gc --prune=now` 才擦干净。
     **结论：助手的调试笔记一律不得入库。** Key 值现在在笔记里已脱敏为 `63PBZ-****`。
  ② 改 `.gitignore` 时**误删了 `.tmp/` 这一条**，结果 `git add -A` 把无头浏览器落在
     `.tmp/penc/` 的**用户配置目录（书签、扩展、浏览数据）**整个卷进了版本库。
     **临时目录那条忽略规则动不得**，改前先看有没有第三方数据堆在里面。
- `.gitattributes` 写死 `* text=auto eol=lf`（本机 `core.autocrlf=true`，不显式指定
  就会在 checkout 时把全库改写成 CRLF）。`.sh` / `.command` 必须 LF，否则 macOS 报
  `\r: command not found`。
- **换端口/改动后别急着 push**：先扫一遍对象库
  `git cat-file --batch-all-objects --batch | grep -cF "<密钥>"`。
- 交付/收尾时**必须归还环境**：停掉自己起的常驻服务（用 `taskkill //PID <pid> //F`），
  并自查「无 python 进程 + 8770 空闲 + `/api/status` 无响应」三项，再交给用户自己跑 `start.bat`。

## 用户自启动流程（交付口径，2026-10-10）
- 入口是项目根目录的 `start.bat`（会 venv → 装依赖 → 起服务 → 自动开浏览器）。
  **不能双击 `web/index.html`**：`file://` 没有 Referer，腾讯地图全拒 →
  表现为「城市不能切 + 地图不画路径」，会被误读成「功能被改没了」。
- 让用户核对该三联看作是活着：①点城市名能实时切换（≈ MCP 通）；
  ②点门店卡能画驾车路线（≈ 腾讯 WebService 通）；③定位输入框打字能下拉 5 条候选。
  三者同时失效 = 服务 / 端口 / 白名单问题，**不是页面 bug**。

## 城市切换 / 定位关键词（2026-10-10 血案）
- **关键词不跨城市沿用**。`#keyword-input` 里的字有两个来源，必须区分：
  ① `pickSuggestion` **自动填**的 POI 名 —— 只属于那座城市，切城市时必须丢掉并清空输入框；
  ② 用户**手打**的 —— 照用（明确意图，例如填「海拉尔」再切呼伦贝尔）。
  实现：模块级 `locatorAutoFilled` 标志 + `switchCityTo(city, { keepKeyword })`；
  只有 `pickSuggestion` 与 `submitLocator` 传 `keepKeyword: true`。
  不加区分的后果：在深圳选了「深圳湾公园」再切北京 → MCP 在北京查不到 → 0 家门店
  → **整座北京被误判成「没有门店」**（用户看到的就是「没能切换到北京」）。
- **服务端必须有兜底**：显式关键词**第一个**试，取不到就退回 `cities.keyword_candidates(city)`
  继续试，别让一个失效关键词把整座城市堵死；换词要回传 `explicit_keyword_dropped`，
  前端如实写「你填的 X 查不到，已自动改用 Y」。
- 真正全空时**如实报错**（`tried` 列出所有试过的词），不许兜底掩盖。

## 幂等 & 复现纪律
- 报错**必须先复现再改**：本次是 `curl POST /api/city` 对照组（带词 404 / 不带词 200）
  一步定位到「关键词」而不是「北京没门店」。猜着改会浪费好几轮。
- 写前端冒烟用例注意：`[data-city-reset]` 复位按钮**只在纯静态分支**由
  `renderLeft/renderRight → bindCityReset` 渲染并绑定。若测试里把 `api.state.live=true`，
  `pickSuggestion` 会走在线分支、不调 `applyCity()`，面板不重渲染 → 拿不到复位按钮 →
  段尾城市卡住、污染后续 section。正解：**先用离线状态点候选**触发 `applyCity()` 渲出按钮，
  **再**抬 `live` 测切城市，段尾还原标志位后点复位。

## 层叠上下文（`web/styles.css`）
- `.map-area { isolation: isolate }` 与浮层 `z-index >= 9000` 是**两道独立防线，缺一不可**，
  `tests/css_coverage.js` 有静态兜底。腾讯地图 GL SDK 会在 `#tmap` 内注入 `z-index: 1000` 图层。

## 上游 MCP 接口（易换壳，解析必须显式认结构）
- `campaign-calendar` 已由 **Markdown 文本换成结构化 JSON**（2026-10 实测）：
  `data.dailyList[].events[].articleDto{title, content, imgList}`。
  老解析器按通用键名扫描会**取到 0 条却不报错** → 页面安静显示「活动 0 条」。
  现由 `src/parsers.py` 的 `_daily_calendar` / `_parse_activities_daily` 显式解析，保留旧格式兼容。
- 教训：这类「上游换结构、下游静默归零」的坑，单元测试用自家夹具**锁不住**。
  必须靠 `tests/browser_hit_check.sh` 打真实服务 + 真实 MCP，断言「7 天日历 > 0 条活动」。

## 定位输入框 / 地区同步
- `/api/suggest` 由**服务端代理**腾讯「关键词输入提示」`ws/place/v1/suggestion`，
  并**转发浏览器 Referer**（Key 不出服务端）。
- 候选自带 `lat/lng`，选中即 `map.focus()` 落点，不再二次检索。
- `applyCity()` **返回 Promise**；`pickSuggestion` 必须等它结束再 focus，
  否则异步的 `locate/moveTo` 会把用户刚选的点挪回城市中心。
- 检索 260ms 防抖 + 服务端 180s TTL 缓存 + `seq` 序号丢弃过期结果。
- 121「日调用量已达上限」实测多为**瞬时抖动**，重试即过，别误报成配额耗尽。

## 测试
- 前端测试用 `tests/fixtures/demo-data.js` 夹具，**不要读 `web/data.js`**
  （它会被 `/api/city` 重写，读了就会因「上次导出哪座城市」忽绿忽红）。
- 写定位相关断言时注意：`runSuggest` 有「输入框内容已变则丢弃结果」的保护，
  测试必须先 `input.value = kw` 再 `search(kw)`；`MCD.state.city` 初始是 `undefined`，
  断言 region 要写 `state.city || data.city`。
- `map.focus` 在无 TMap 的 jsdom 里直接 `return false`（不设 `mapState.focus`），
  **落点断言只能在真实浏览器里做**。
- 「看得见但点不动 / 位置不对」这类问题 jsdom 测不出来，必须靠
  `tests/browser_hit_check.sh`（真实 Chromium 无头内核）。
- 无头浏览器跑地图时**不要加 `--disable-gpu`**：GL 的大头针图层会画不出来（假 bug）。

## 本机环境
- 前端测试：`export NODE_PATH=C:/Users/Lenovo/.workbuddy/binaries/node/workspace/node_modules`
  （jsdom 装在托管 node 工作区，项目内没有 node_modules）。
- 跑真实数据 / 写 Token：**必须用项目自带的 `.venv` 解释器**
  `.venv/Scripts/python.exe -m src.serve`（`start.bat` 用的就是它，`mcp` + `python-dotenv` 都在里面）。
  两个坑：① 系统 Python 有 `dotenv` 但**没有 `mcp`** → 切城市会报
  `ModuleNotFoundError: No module named 'mcp'`；② 托管 Python 没装 `python-dotenv`
  → 读不到 `.env`（现象：`/api/status` 为 `live:false`、`tmap:false`）。用错解释器时
  「服务能起、状态看似正常，一切换城市才炸」，别被误导。
- 常驻服务用 bash 工具的 `run_in_background: true`，`(cmd &)` 会随工具退出被回收。

## 安全边界
- Token 只留在服务端 `.env`，**不进浏览器、不进 `web/data.js`**（data.js 要提交进公开仓库）。
- `web/data.js` 含 `account_id`、积分、历史订单、本人券等个人信息，公开前先 `--demo` 换回样例。
