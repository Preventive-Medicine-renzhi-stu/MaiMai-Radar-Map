#!/usr/bin/env bash
# ==========================================================================
#  真实浏览器命中测试（登录弹窗控件是否真的点得动）
# --------------------------------------------------------------------------
#  为什么需要它：
#    jsdom 不做布局，也不做层叠上下文（stacking context）计算，
#    所以「某个第三方图层盖在弹窗上面、把点击全部吃掉」这类 bug
#    在 web_smoke.js 里是测不出来的（它一直是全绿的）。
#
#    真实案例：腾讯地图 GL SDK 会在 #tmap 内部注入一个 z-index: 1000 的
#    绝对定位图层。.map-area 若不自建层叠上下文，这个 1000 会逃逸到根层叠
#    上下文，压过登录弹窗，导致弹窗看得见、但所有按钮都点不动。
#
#  运行前提：本地服务已启动（python -m src.serve）
#     bash tests/browser_hit_check.sh
#  或指定地址：
#     MCD_TEST_BASE=http://127.0.0.1:8791 bash tests/browser_hit_check.sh
#
#  未找到 Chromium 内核浏览器时自动跳过（退出码 0），不阻塞其他测试。
# ==========================================================================
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BASE="${MCD_TEST_BASE:-http://127.0.0.1:8770}"
PROBE="$ROOT/web/__hitcheck.html"
PROFILE="$(mktemp -d 2>/dev/null || echo /tmp/hitcheck-profile)"

cleanup() {
  rm -f "$PROBE"
  rm -rf "$PROFILE" 2>/dev/null
}
trap cleanup EXIT

echo "=== 真实浏览器命中测试 ==="

# ---------------------------------------------------------------- 找浏览器
BROWSER="${MCD_BROWSER:-}"
if [ -z "$BROWSER" ]; then
  for c in \
    "/c/Program Files (x86)/Microsoft/Edge/Application/msedge.exe" \
    "/c/Program Files/Microsoft/Edge/Application/msedge.exe" \
    "/c/Program Files/Google/Chrome/Application/chrome.exe" \
    "/c/Program Files (x86)/Google/Chrome/Application/chrome.exe" \
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" \
    "$(command -v google-chrome 2>/dev/null)" \
    "$(command -v chromium 2>/dev/null)" \
    "$(command -v chromium-browser 2>/dev/null)" \
    "/c/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"; do
    [ -n "$c" ] && [ -x "$c" ] && BROWSER="$c" && break
  done
fi

if [ -z "$BROWSER" ] || [ ! -x "$BROWSER" ]; then
  echo "跳过：未找到 Chromium 内核浏览器（可用 MCD_BROWSER=/path/to/chrome 指定）"
  exit 0
fi
echo "浏览器：$BROWSER"

# ---------------------------------------------------------------- 探针就绪
if ! curl -s --max-time 4 "$BASE/api/status" >/dev/null 2>&1; then
  echo "跳过：本地服务未启动（先跑 python -m src.serve，或用 MCD_TEST_BASE 指定地址）"
  exit 0
fi
echo "服务：$BASE"

cat > "$PROBE" <<'PROBE_HTML'
<!doctype html>
<html><head><meta charset="utf-8"><title>hitcheck</title></head>
<body style="margin:0">
<div id="out">running</div>
<script>
var log = [], fails = 0;
function ok(name, cond, extra) {
  log.push((cond ? '\u2714 ' : '\u2718 ') + name + (extra ? ' \u2014 ' + extra : ''));
  if (!cond) fails++;
}
function desc(node) {
  if (!node) return 'null';
  return node.tagName + (node.id ? '#' + node.id : '') +
    (node.className ? '.' + String(node.className).split(' ')[0] : '');
}
var f = document.createElement('iframe');
f.style.cssText = 'width:1280px;height:900px;border:0;display:block';
f.src = '/index.html';
document.body.appendChild(f);

f.onload = function () {
  setTimeout(function () {
    try {
      var w = f.contentWindow, d = f.contentDocument;

      function top(sel) {
        var el = d.querySelector(sel);
        if (!el) return { el: null, good: false, hit: null };
        var r = el.getBoundingClientRect();
        var x = r.left + r.width / 2, y = r.top + r.height / 2;
        var hit = d.elementFromPoint(x, y);
        return { el: el, hit: hit, good: hit === el || el.contains(hit) || el.contains(hit) };
      }
      function checkHit(sel, label) {
        var t = top(sel);
        ok(label + ' \u53ef\u70b9\u51fb', !!t.el && t.good,
           t.good ? '' : ('\u88ab ' + desc(t.hit) + ' \u76d6\u4f4f'));
      }

      var m = d.querySelector('#login-mask');
      ok('\u9996\u5c4f\u5f39\u51fa\u767b\u5f55\u5f39\u7a97', !!m && m.hidden === false && w.MCD.auth.isOpen());

      var mapArea = d.querySelector('.map-area');
      ok('.map-area \u5efa\u7acb\u72ec\u7acb\u5c42\u53e0\u4e0a\u4e0b\u6587\uff08isolation: isolate\uff09',
         !!mapArea && w.getComputedStyle(mapArea).isolation === 'isolate');
      var mz = w.getComputedStyle(m).zIndex;
      ok('\u767b\u5f55\u5f39\u7a97\u5c42\u7ea7\u9ad8\u4e8e\u5730\u56fe SDK \u7684 1000',
         parseInt(mz, 10) > 1000, 'z-index=' + mz);

      // ---- \u5730\u56fe\u5fc5\u987b\u8ddf\u4e0a\u5f53\u524d\u57ce\u5e02 ----
      // \u66fe\u7ecf\u7684 bug\uff1a\u5207\u5230\u4e0a\u6d77\u3001\u5730\u56fe\u8fd8\u505c\u5728\u6df1\u5733\u3002
      // \u6839\u56e0\u662f\u62ff\u4e0d\u5230\u5730\u70b9\u641c\u7d22\u7ed3\u679c\u65f6\u5c31\u9000\u56de\u786c\u7f16\u7801\u9ed8\u8ba4\u70b9\u3002
      var packCity = (w.MCD.DATA && w.MCD.DATA.city) || '';
      var table = (w.MCD.api && w.MCD.api.cities && w.MCD.api.cities()) ||
                  (w.MCD.DATA && w.MCD.DATA.cities) || [];
      ok('\u57ce\u5e02\u8868\u8986\u76d6\u5168\u56fd\uff08>= 300 \u5ea7\uff09', table.length >= 300,
         table.length + ' \u5ea7');
      var want = null;
      for (var ti = 0; ti < table.length; ti++) {
        if (table[ti].city === packCity) { want = table[ti]; break; }
      }
      ok('\u6570\u636e\u5305\u57ce\u5e02\u5728\u8868\u91cc\u4e14\u5e26\u5750\u6807', !!want && !!want.lat && !!want.lng,
         packCity + (want ? ' ' + want.lat + ',' + want.lng : ' \u672a\u627e\u5230'));

      var got = (w.MCD.map && w.MCD.map.currentCenter) ? w.MCD.map.currentCenter() : null;
      if (got && want && want.lat && want.lng) {
        var dLat = Math.abs(got.lat - want.lat), dLng = Math.abs(got.lng - want.lng);
        ok('\u5730\u56fe\u89c6\u89d2\u5df2\u843d\u5728\u300c' + packCity + '\u300d',
           dLat < 1.2 && dLng < 1.2,
           '\u5b9e\u9645 ' + got.lat.toFixed(3) + ',' + got.lng.toFixed(3) +
           ' \u671f\u671b ' + want.lat + ',' + want.lng);
      } else {
        ok('\u672a\u53d6\u5230\u5730\u56fe\u4e2d\u5fc3\uff08\u65e0\u5730\u56fe\u5b9e\u4f8b\uff09', true,
           'center=' + JSON.stringify(got));
      }

      checkHit('#lg-phone', '\u624b\u673a\u53f7\u8f93\u5165\u6846');
      checkHit('#lg-code', '\u9a8c\u8bc1\u7801\u8f93\u5165\u6846');
      checkHit('#lg-send', '\u83b7\u53d6\u9a8c\u8bc1\u7801\u6309\u94ae');
      checkHit('#lg-submit', '\u767b\u5f55\u6309\u94ae');
      checkHit('[data-lg-tab="phone"]', '\u624b\u673a\u53f7 tab');
      checkHit('[data-lg-tab="wechat"]', '\u5fae\u4fe1 tab');
      checkHit('#lg-skip', '\u6682\u4e0d\u767b\u5f55\uff0c\u5148\u901b\u901b');

      // 切到微信 tab 后，扫码按钮也应可点
      var wt = d.querySelector('[data-lg-tab="wechat"]');
      if (wt) wt.click();
      checkHit('#lg-wechat', '\u5fae\u4fe1\u626b\u7801\u767b\u5f55\u6309\u94ae');

      // 回到手机号 tab，点「暂不登录」
      var pt = d.querySelector('[data-lg-tab="phone"]');
      if (pt) pt.click();
      var sk = d.querySelector('#lg-skip');
      if (sk) sk.click();
      ok('\u70b9\u51fb\u300c\u6682\u4e0d\u767b\u5f55\u300d\u540e\u5f39\u7a97\u5173\u95ed',
         m.hidden === true && d.body.classList.contains('has-login') === false);
      // \u8df3\u8fc7\u53ea\u5bf9\u5f53\u6b21\u9875\u9762\u52a0\u8f7d\u751f\u6548\uff08\u5237\u65b0\u4f1a\u518d\u5f39\uff09\uff0c
      // \u6240\u4ee5\u4e0d\u80fd\u5199\u8fdb sessionStorage\u3002
      ok('\u8df3\u8fc7\u4e0d\u518d\u5199\u5165 sessionStorage\uff08\u5237\u65b0\u540e\u4f1a\u91cd\u65b0\u5f39\u51fa\uff09', (function () {
        try { return w.sessionStorage.getItem('mcd.auth.skipped') === null; } catch (e) { return true; }
      })());
      ok('\u8df3\u8fc7\u540e\u518d\u6b21\u8c03\u7528 gate() \u4e0d\u4f1a\u91cd\u5f39', (function () {
        try { return w.MCD.auth.gate() === false; } catch (e) { return false; }
      })());

      // ---- \u7ed3\u679c\u9875\u300c\u524d\u5f80\u9910\u5385\u300d\u5c0f\u5730\u56fe\u4e5f\u5fc5\u987b\u8ddf\u4e0a\u5f53\u524d\u57ce\u5e02 ----
      // \u5b83\u66fe\u7ecf\u5199\u6b7b\u6df1\u5733\u5357\u5c71\uff08DEFAULT_CENTER\uff09\uff1a\u5207\u5230\u522b\u7684\u57ce\u5e02\u4e0b\u5355\u540e\uff0c
      // \u7ed3\u679c\u9875\u5c0f\u5730\u56fe\u7167\u65e7\u505c\u5728\u6df1\u5733 \u2014\u2014 \u4e0e\u96f7\u8fbe\u9875\u65e9\u5148\u4fee\u6389\u7684\u90a3\u4e2a\u662f\u540c\u4e00\u4e2a bug\u3002
      window.__rm = (function () {
        if (!w.MCD.map.ready()) {
          ok('\u7ed3\u679c\u9875\u5c0f\u5730\u56fe\u843d\u70b9\uff08\u5730\u56fe\u672a\u5c31\u7eea\uff0c\u8df3\u8fc7\uff09', true, '\u5df2\u964d\u7ea7\u4e3a\u884c\u7a0b\u793a\u610f\u6761');
          return Promise.resolve();
        }
        var box = d.createElement('div');
        box.id = '__rm_probe__';
        box.style.cssText = 'width:600px;height:400px;position:fixed;left:0;top:0;z-index:99999';
        d.body.appendChild(box);
        var city = (w.MCD.DATA && w.MCD.DATA.city) || '';
        var table = (w.MCD.api && w.MCD.api.cities && w.MCD.api.cities()) ||
                    (w.MCD.DATA && w.MCD.DATA.cities) || [];
        var want = null;
        for (var i = 0; i < table.length; i++) if (table[i].city === city) { want = table[i]; break; }
        var stores = w.MCD.data.stores();
        if (!stores.length) {
          ok('\u7ed3\u679c\u9875\u5c0f\u5730\u56fe\u843d\u70b9\uff08\u65e0\u95e8\u5e97\uff0c\u8df3\u8fc7\uff09', true, '');
          return Promise.resolve();
        }
        return Promise.race([
          w.MCD.routeMap.show('__rm_probe__', stores[0].store_code),
          new Promise(function (r) { setTimeout(r, 8000); })
        ]).then(function () {
          var c = w.MCD.routeMap.currentCenter();
          if (!c || !want) {
            ok('\u7ed3\u679c\u9875\u5c0f\u5730\u56fe\u843d\u70b9\uff08\u5730\u56fe\u5c1a\u672a\u5c31\u7eea\uff0c\u8df3\u8fc7\uff09', true,
               'center=' + JSON.stringify(c));
            return;
          }
          ok('\u7ed3\u679c\u9875\u5c0f\u5730\u56fe\uff08\u524d\u5f80\u9910\u5385\uff09\u843d\u5728\u5f53\u524d\u57ce\u5e02',
             Math.abs(c.lat - want.lat) < 1.2 && Math.abs(c.lng - want.lng) < 1.2,
             'city=' + city + ' \u5b9e\u9645=' + JSON.stringify(c) +
             ' \u671f\u671b=' + want.lat + ',' + want.lng);
        }).catch(function (e) {
          ok('\u7ed3\u679c\u9875\u5c0f\u5730\u56fe\u63a2\u9488\u6267\u884c\u65e0\u5f02\u5e38', false, e.message);
        });
      })();
      window.__rm2 = (window.__rm || Promise.resolve()).then(function () {
        // ---- \u670d\u52a1\u7c7b\u5e93 API \u540d\uff08\u79bb\u7ebf\u53ef\u5224\uff09----
        // \u771f\u5b9e\u8e29\u8fc7\u7684\u5751\uff1aGL JS \u7684 Search \u7c7b**\u6ca1\u6709 search()**\uff0c
        // \u5199\u6210 svc.search(...) \u4f1a\u629b\u5f02\u5e38\u88ab catch \u541e\u6389\uff0c
        // \u8868\u73b0\u4e3a\u300c\u63a5\u53e3\u901a\u4e86\u3001\u95e8\u5e97\u5750\u6807\u8fd8\u662f\u53d6\u4e0d\u5230\u300d\u3002
        try {
          var Search = w.TMap && w.TMap.service && w.TMap.service.Search;
          if (Search) {
            var svc = new Search({ pageSize: 5 });
            ok('GL JS Search \u63d0\u4f9b searchRegion \u65b9\u6cd5\uff08\u800c\u975e search\uff09',
               typeof svc.searchRegion === 'function',
               'searchRegion=' + typeof svc.searchRegion + ' search=' + typeof svc.search);
          } else {
            ok('GL JS \u670d\u52a1\u7c7b\u5e93\u672a\u52a0\u8f7d\uff08\u8df3\u8fc7\uff09', true, '');
          }
        } catch (e) {
          ok('Search \u63a2\u9488\u65e0\u5f02\u5e38', false, e.message);
        }

        // ---- \u95e8\u5e97\u771f\u5b9e\u5750\u6807\uff08\u9700\u5728\u7ebf Key + \u914d\u989d\uff09----
        if (!w.MCD.map.ready()) {
          ok('\u96f7\u8fbe\u5730\u56fe\u672a\u5c31\u7eea\uff08\u8df3\u8fc7\u5750\u6807\u65ad\u8a00\uff09', true, '');
          return;
        }
        return Promise.race([
          w.MCD.map.locate(), new Promise(function (r) { setTimeout(r, 14000); })
        ]).then(function (r) {
          r = r || {};
          if ((r.exact || 0) > 0) {
            ok('\u95e8\u5e97\u62ff\u5230\u771f\u5b9e\u5750\u6807\uff08exact=' + r.exact + '\uff09', true,
               'city=' + ((w.MCD.DATA && w.MCD.DATA.city) || ''));
          } else {
            ok('\u95e8\u5e97\u5750\u6807\u65ad\u8a00\uff08\u8df3\u8fc7\uff1aWebServiceAPI \u672a\u8fd4\u56de\uff0c\u53ef\u80fd\u662f\u914d\u989d\u6216\u7f51\u7edc\uff09',
               true, 'exact=0');
          }
          var rd = (w.MCD.routeMap && w.MCD.routeMap.debug) ? w.MCD.routeMap.debug() : null;
          if (rd && rd.ready) {
            ok('\u7ed3\u679c\u9875\u5c0f\u5730\u56fe\u753b\u51fa\u771f\u5b9e\u9a7e\u8f66\u8def\u7ebf', rd.mode === 'driving' && rd.routePoints > 2,
               'mode=' + rd.mode + ' points=' + rd.routePoints);
          }
        });
      });

      window.__rm3 = (window.__rm2 || Promise.resolve()).then(function () {
        // ---- 活动日历：MCP 已把 campaign-calendar 换成结构化 JSON ----
        // 老解析器只认 Markdown / 通用键名，遇到 data.dailyList[].events[].articleDto
        // 会解析出 0 条 —— 页面表现就是「活动全没了」。
        var cal = (w.MCD.DATA && w.MCD.DATA.calendar) || [];
        var total = 0;
        cal.forEach(function (day) { total += (day.activities || []).length; });
        ok('活动日历解析出活动（MCP 新版 JSON 结构）', total > 0,
           '7 天共 ' + total + ' 条，今天 ' + ((cal[0] && cal[0].count) || 0) + ' 条');
        var dayNodes = d.querySelectorAll('#calendar-days .cal-day').length;
        ok('日历条渲染出 7 天', dayNodes === 7, '实际 ' + dayNodes);

        var acts = (w.MCD.data && w.MCD.data.activities) ? w.MCD.data.activities() : [];
        ok('活动详情索引可用', acts.length > 0, '活动数 ' + acts.length);

        // ---- 活动详情页：本地区门店 + 距离 + 步行/驾车时长 + 抵达时间 ----
        if (acts.length) {
          w.MCD.views.activity.render('0');
          var cards = d.querySelectorAll('#activity-root .activity-stores .astore');
          ok('活动详情页列出本地区门店', cards.length > 0, '门店卡 ' + cards.length + ' 张');
          var first = cards[0];
          if (first) {
            var chips = first.querySelectorAll('.as-travel .tv');
            var txt = first.textContent || '';
            ok('门店卡给出步行 / 驾车时长与抵达时刻',
               chips.length >= 2 && /\d{2}:\d{2}/.test(txt), 'chips=' + chips.length);
            var distEl = first.querySelector('.as-dist');
            ok('门店卡给出距离与地址',
               !!distEl && !!first.querySelector('.as-addr'),
               distEl ? distEl.textContent : '(无距离)');
          }
          w.MCD.router.go('/');
        }

        // ---- 定位输入框：腾讯候选下拉 5 条 + 点一条即定位 ----
        var inp = d.querySelector('#keyword-input');
        ok('定位输入框提示可下拉候选',
           !!inp && /下拉/.test(inp.getAttribute('placeholder') || ''),
           inp ? inp.getAttribute('placeholder') : 'null');
        if (!inp || !(w.MCD.api && w.MCD.api.suggest)) {
          ok('定位候选接口不可用（跳过）', true, 'MCD.api.suggest 缺失');
          return;
        }

        return w.MCD.api.suggest('人民广场', '上海', 5).then(function (res) {
          var items = (res && res.items) || [];
          ok('腾讯「关键词输入提示」返回候选（不超过 5 条）',
             items.length > 0 && items.length <= 5,
             'count=' + items.length + (res && res.message ? ' · ' + res.message : ''));
          if (!items.length) return;

          // 暂时关掉实时切换能力：否则点候选会真的触发一次全量导出并刷新页面
          var liveFn = w.MCD.api.live;
          w.MCD.api.live = function () { return false; };

          w.MCD.locate.render(items);
          var box = d.querySelector('#loc-suggest');
          var nodes = d.querySelectorAll('#loc-suggest .loc-item');
          ok('下拉渲染出候选列表', !!box && box.hidden === false && nodes.length === items.length,
             'items=' + nodes.length);
          if (!nodes.length) { w.MCD.api.live = liveFn; return; }

          nodes[0].dispatchEvent(new w.MouseEvent('mousedown', { bubbles: true, cancelable: true }));
          ok('点候选后输入框写入该地点名', inp.value === items[0].title, inp.value);
          ok('选中后下拉收起', d.querySelector('#loc-suggest').hidden === true, '');

          return w.MCD.locate.lastPick().then(function () {
            var fp = (w.MCD.map && w.MCD.map.focusedPoint) ? w.MCD.map.focusedPoint() : null;
            var want = items[0];
            if (w.MCD.map.ready()) {
              ok('点候选后地图落到该点坐标',
                 !!fp && Math.abs(fp.lat - want.lat) < 1e-6 && Math.abs(fp.lng - want.lng) < 1e-6,
                 '实际 ' + JSON.stringify(fp) + ' 期望 ' + want.lat + ',' + want.lng);
            } else {
              ok('地图未就绪（跳过落点断言）', true, '候选下拉仍可用');
            }
            w.MCD.api.live = liveFn;
          });
        });
      });
    } catch (err) {
      ok('\u63a2\u9488\u6267\u884c\u65e0\u5f02\u5e38', false, err.message);
      window.__rm = Promise.resolve();
      window.__rm2 = Promise.resolve();
      window.__rm3 = Promise.resolve();
    }
    (window.__rm3 || window.__rm2 || window.__rm || Promise.resolve()).then(finish, finish);
    function finish() {
      document.getElementById('out').textContent =
        '===PROBE===\n' + log.join('\n') + '\nFAILS=' + fails + '\n===END===';
    }
  }, 3000);
};
</script>
</body></html>
PROBE_HTML

DUMP="$(curl -s --max-time 5 "$BASE/__hitcheck.html" >/dev/null 2>&1 && \
  "$BROWSER" --headless=new --disable-gpu --no-first-run --no-default-browser-check \
  --window-size=1280,900 --user-data-dir="$PROFILE" --virtual-time-budget=60000 \
  --dump-dom "$BASE/__hitcheck.html" 2>/dev/null)"

RESULT="$(printf '%s' "$DUMP" | awk '/===PROBE===/{f=1} f && !/===PROBE===/{print} /===END===/{exit}')"

if [ -z "$RESULT" ]; then
  echo "跳过：浏览器没有产出探针结果（可能是无头模式在该环境不可用）"
  exit 0
fi

printf '%s\n' "$RESULT" | sed 's/===END===.*$//' | sed 's/^/  /'
FAILS="$(printf '%s' "$RESULT" | sed -n 's/^FAILS=\([0-9]*\).*$/\1/p' | head -1)"
echo
if [ "${FAILS:-0}" = "0" ]; then
  echo "结果：全部通过"
  exit 0
fi
echo "结果：$FAILS 项失败（真实浏览器里弹窗控件被遮挡 —— 检查 CSS 层叠上下文与 z-index）"
exit 1
