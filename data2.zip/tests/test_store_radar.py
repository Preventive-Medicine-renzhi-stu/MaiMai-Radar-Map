"""雷达地图核心逻辑的单元测试（门店 / 菜单 / 订单 / 三模式 / 日历）。"""

from __future__ import annotations

import unittest
from datetime import date, datetime

from src.catalog import (
    parse_account,
    parse_meals,
    parse_orders,
    parse_store_coupons,
    parse_stores,
)
from src.demo_data import ACCOUNT, ORDERS, STORE_COUPONS, menu_payload, nearby_stores_payload
from src.geo import (
    build_calendar_days,
    estimate_busy,
    estimate_travel,
    is_open_at,
    pick_mode,
    radial_layout,
)
from src.models import Activity, Store
from src.store_radar import (
    build_bundle,
    build_nearby_mode,
    build_newest_mode,
    build_speed_mode,
)


class GeoTest(unittest.TestCase):
    def test_pick_mode_by_distance(self) -> None:
        self.assertEqual(pick_mode(300), "walk")
        self.assertEqual(pick_mode(2500), "ride")
        self.assertEqual(pick_mode(9000), "drive")

    def test_travel_monotonic(self) -> None:
        near = estimate_travel(500)
        far = estimate_travel(5000)
        self.assertLess(near.minutes, far.minutes)
        self.assertEqual(near.mode_label, "步行")

    def test_busy_higher_at_peak(self) -> None:
        store = Store(store_code="1420944", name="测试店", address="", distance=100)
        off_peak = estimate_busy(store, datetime(2026, 10, 9, 15, 0))
        peak = estimate_busy(store, datetime(2026, 10, 9, 12, 0))
        self.assertGreater(peak.score, off_peak.score)
        self.assertTrue(peak.is_estimate)

    def test_busy_closed_store(self) -> None:
        store = Store(
            store_code="x", name="打烊店", address="", distance=100, business_status=False
        )
        busy = estimate_busy(store)
        self.assertEqual(busy.label, "未营业")
        self.assertEqual(busy.score, 0)

    def test_is_open_across_midnight(self) -> None:
        store = Store(
            store_code="1420094",
            name="跨天店",
            address="",
            distance=100,
            open_time="06:00",
            close_time="02:00",
        )
        self.assertTrue(is_open_at(store, datetime(2026, 10, 9, 1, 0)))
        self.assertTrue(is_open_at(store, datetime(2026, 10, 9, 8, 0)))
        self.assertFalse(is_open_at(store, datetime(2026, 10, 9, 4, 0)))

    def test_radial_layout(self) -> None:
        points = radial_layout(4)
        self.assertEqual(len(points), 4)
        self.assertAlmostEqual(points[0][0], -90.0)

    def test_calendar_covers_seven_days(self) -> None:
        activities = [Activity(date="2026-10-09", title="A"), Activity(date="2026-10-12", title="B")]
        days = build_calendar_days(activities, days=7, today=date(2026, 10, 9))
        self.assertEqual(len(days), 7)
        self.assertTrue(days[0]["is_today"])
        self.assertEqual(days[0]["count"], 1)
        self.assertEqual(days[3]["count"], 1)
        self.assertEqual(days[6]["count"], 0)
        self.assertTrue(days[1]["is_weekend"])


class CatalogTest(unittest.TestCase):
    def test_parse_stores(self) -> None:
        stores = parse_stores(nearby_stores_payload(1), be_type=1, city="深圳")
        self.assertEqual(len(stores), 5)
        nearest = min(stores, key=lambda s: s.distance)
        self.assertEqual(nearest.store_code, "1420944")
        self.assertEqual(nearest.distance, 109)
        self.assertTrue(nearest.reservation)
        self.assertFalse(nearest.has_coords)  # MCP 恒返回 0.0

    def test_parse_meals_and_store_diff(self) -> None:
        base = {m.code: m for m in parse_meals(menu_payload("1420944"))}
        other = {m.code: m for m in parse_meals(menu_payload("1420728"))}
        self.assertIn("1100", base)
        # 真实差异：海岸城店没有「姜汁撞奶风味派」
        self.assertIn("521907", base)
        self.assertNotIn("521907", other)
        # 真实差异：同款薯条两家店价格不同
        self.assertEqual(base["4810"].price, 14.5)
        self.assertEqual(other["4810"].price, 13.5)

    def test_meal_discount_fields(self) -> None:
        meals = {m.code: m for m in parse_meals(menu_payload("1420944"))}
        combo = meals["9900016073"]  # 龙焰鸡腿堡三件套
        self.assertEqual(combo.price, 26.9)
        self.assertEqual(combo.original_price, 48.5)
        self.assertAlmostEqual(combo.saving, 21.6, places=2)
        self.assertTrue(combo.has_discount)

    def test_parse_orders(self) -> None:
        orders = parse_orders(ORDERS)
        self.assertEqual(len(orders), 1)
        self.assertEqual(orders[0].store_name, "麦当劳马鞍山湖东路餐厅")
        self.assertAlmostEqual(orders[0].amount, 73.0)
        self.assertIn("堡堡随心拼", orders[0].summary)

    def test_parse_orders_keeps_combo_items(self) -> None:
        """套餐子项要单独留存：它比「堡堡随心拼」更能反映真实口味偏好。"""
        order = parse_orders(ORDERS)[0]
        self.assertEqual(len(order.products), 1)
        self.assertEqual(order.products[0]["productName"], "堡堡随心拼（7件任选）")
        self.assertIn("巨无霸", order.combo_names)
        self.assertIn("麦辣鸡腿汉堡", order.combo_names)

    def test_preferred_names_combines_combo_and_top_level(self) -> None:
        order = parse_orders(ORDERS)[0]
        names = order.preferred_names
        # 子项在前，顶层商品名在后
        self.assertEqual(names[0], "麦辣鸡腿汉堡")
        self.assertEqual(names[-1], "堡堡随心拼（7件任选）")
        # 去重
        self.assertEqual(len(names), len(set(names)))
        self.assertEqual(len(names), len(order.combo_names) + len(order.products))

    def test_parse_store_coupons_validity(self) -> None:
        coupons = parse_store_coupons(STORE_COUPONS)
        self.assertEqual(len(coupons), 2)
        first = coupons[0]
        self.assertEqual(first.title, "麦旋风任选")
        self.assertEqual(first.coupon_code, "MCD620H09YX110090XLH0")
        self.assertTrue(first.valid_from.startswith("2026-10-05"))
        self.assertTrue(first.valid_to.endswith("23:59:59"))

    def test_parse_account(self) -> None:
        account = parse_account(ACCOUNT)
        self.assertAlmostEqual(account.available_points, 100.9, places=1)
        self.assertAlmostEqual(account.accumulated_points, 370.0, places=1)
        self.assertAlmostEqual(account.expired_points, 269.1, places=1)

    def test_parse_account_extra_fields(self) -> None:
        """账户 ID / 已使用 / 冻结 / 各期过期积分都要带出来，供用户信息下拉展示。"""
        account = parse_account(ACCOUNT)
        self.assertEqual(account.account_id, "02001068760976359282457786702")
        self.assertAlmostEqual(account.used_points, 0.0)
        self.assertAlmostEqual(account.frozen_points, 0.0)
        self.assertAlmostEqual(account.expiring_this_month, 0.0)
        self.assertAlmostEqual(account.expiring_next_month, 0.0)
        self.assertEqual(account.unit, "麦享会积分")

    def test_expired_not_confused_with_frozen(self) -> None:
        """冻结积分 ≠ 已过期积分：老实现把 frozenPoints 当作过期兜底，会串数。"""
        account = parse_account({"data": {"frozenPoint": "88", "expiredPoint": "12"}})
        self.assertAlmostEqual(account.expired_points, 12.0)
        self.assertAlmostEqual(account.frozen_points, 88.0)

    def test_parse_handles_garbage(self) -> None:
        self.assertEqual(parse_stores("not json"), [])
        self.assertEqual(parse_meals(None), [])
        self.assertEqual(parse_orders({"data": {}}), [])
        self.assertEqual(parse_store_coupons("oops"), [])


class ModeOneTest(unittest.TestCase):
    def setUp(self) -> None:
        self.stores = parse_stores(nearby_stores_payload(1), be_type=1, city="深圳")
        self.orders = parse_orders(ORDERS)

    def test_sorted_by_distance(self) -> None:
        result = build_nearby_mode(self.stores, self.orders, sort="distance")
        distances = [row["distance"] for row in result["stores"]]
        self.assertEqual(distances, sorted(distances))
        self.assertEqual(result["stores"][0]["rank"], 1)

    def test_frequent_falls_back_when_no_local_orders(self) -> None:
        result = build_nearby_mode(self.stores, self.orders, sort="frequent")
        # 历史订单在别的城市 —— 应如实回落并给出标记
        self.assertEqual(result["sort"], "frequent_fallback")
        self.assertTrue(all(row["order_count"] == 0 for row in result["stores"]))

    def test_frequent_orders_first(self) -> None:
        from src.models import OrderRecord

        orders = [
            OrderRecord(
                order_id="1",
                store_code="1420094",
                store_name="南山书城",
                create_time="2026-09-01 12:00:00",
                amount=30.0,
            )
        ]
        result = build_nearby_mode(self.stores, orders, sort="frequent")
        self.assertEqual(result["sort"], "frequent")
        self.assertEqual(result["stores"][0]["store_code"], "1420094")
        self.assertEqual(result["stores"][0]["order_count"], 1)

    def test_badges_and_metrics(self) -> None:
        row = build_nearby_mode(self.stores, self.orders, sort="distance")["stores"][0]
        for key in ("travel_minutes", "queue_minutes", "busy_label", "total_minutes", "badges"):
            self.assertIn(key, row)
        self.assertIn("步行可达", row["badges"])


class ModeTwoTest(unittest.TestCase):
    def setUp(self) -> None:
        self.stores = parse_stores(nearby_stores_payload(1), be_type=1, city="深圳")
        self.menus = {
            s.store_code: parse_meals(menu_payload(s.store_code)) for s in self.stores
        }

    def test_matches_products_from_activity_text(self) -> None:
        activities = [
            Activity(
                date="2026-10-09",
                title="麦当劳联动G-DRAGON",
                body="龙焰鸡腿堡三件套 26.9 元起即刻开吃",
                status="today",
            )
        ]
        result = build_newest_mode(activities, self.stores, self.menus, today=date(2026, 10, 9))
        card = result["activities"][0]
        names = [p["name"] for p in card["products"]]
        self.assertIn("龙焰鸡腿堡三件套", names)

    def test_availability_reflects_real_menu_diff(self) -> None:
        activities = [
            Activity(
                date="2026-10-09",
                title="蘸酱韩式甜辣酱鸡块上新",
                body="蘸酱韩式甜辣酱鸡块仅需11.9元起",
                status="today",
            )
        ]
        result = build_newest_mode(activities, self.stores, self.menus, today=date(2026, 10, 9))
        product = result["activities"][0]["products"][0]
        self.assertEqual(product["name"], "蘸酱韩式甜辣酱鸡块")
        self.assertNotIn("1420728", product["stores"])  # 真实：海岸城店无此品
        self.assertTrue(product["partial"])

    def test_gift_detection(self) -> None:
        activities = [
            Activity(
                date="2026-10-15",
                title="麦当劳 X PEACEMINUSONE 联名徽章即将发售",
                body="周边第二弹 限量珍藏 加39.9元即可得",
                status="upcoming",
            )
        ]
        result = build_newest_mode(activities, self.stores, self.menus, today=date(2026, 10, 9))
        self.assertTrue(result["activities"][0]["is_gift"])
        self.assertEqual(len(result["gifts"]), 1)

    def test_skips_activities_beyond_window(self) -> None:
        activities = [
            Activity(date="2026-11-30", title="很远的活动", status="upcoming"),
        ]
        result = build_newest_mode(activities, self.stores, self.menus, today=date(2026, 10, 9), days=7)
        self.assertEqual(result["activities"], [])


class ModeThreeTest(unittest.TestCase):
    def setUp(self) -> None:
        self.stores = parse_stores(nearby_stores_payload(1), be_type=1, city="深圳")
        self.menus = {
            s.store_code: parse_meals(menu_payload(s.store_code)) for s in self.stores
        }
        self.orders = parse_orders(ORDERS)
        self.coupons = parse_store_coupons(STORE_COUPONS)
        self.now = datetime(2026, 10, 9, 12, 15)

    def test_recommends_fastest_store(self) -> None:
        selected = [{"code": "1100", "name": "巨无霸", "quantity": 1}]
        result = build_speed_mode(
            self.stores, self.menus, self.orders, self.coupons, selected, now=self.now
        )
        self.assertTrue(result["best_store_code"])
        totals = [row["total_minutes"] for row in result["stores"]]
        self.assertEqual(totals, sorted(totals))

    def test_flags_item_missing_in_some_store(self) -> None:
        selected = [{"code": "9900016096", "name": "蘸酱韩式甜辣酱鸡块", "quantity": 1}]
        result = build_speed_mode(
            self.stores, self.menus, self.orders, self.coupons, selected, now=self.now
        )
        blocked = sorted(r["store_code"] for r in result["stores"] if not r["orderable"])
        # 真实数据：海岸城西区店与厚德品园店都没有这一款
        self.assertEqual(blocked, ["1420728", "1420919"])
        for row in result["stores"]:
            if row["store_code"] in blocked:
                self.assertTrue(any("暂无售" in n for n in row["notes"]))

    def test_marks_unorderable_first_false(self) -> None:
        selected = [{"code": "9900016096", "name": "蘸酱韩式甜辣酱鸡块", "quantity": 1}]
        result = build_speed_mode(
            self.stores, self.menus, self.orders, self.coupons, selected, now=self.now
        )
        self.assertTrue(result["stores"][-1]["missing_count"] > 0)

    def test_fast_combo_is_a_discounted_set(self) -> None:
        result = build_speed_mode(
            self.stores, self.menus, self.orders, self.coupons, [], now=self.now
        )
        combo = result["fast_combo"]
        self.assertIsNotNone(combo)
        self.assertGreater(combo["saving"], 0)
        self.assertTrue(any(k in combo["name"] for k in ("套餐", "三件套", "四件套")))

    def test_history_pin_carries_price_pair(self) -> None:
        result = build_speed_mode(
            self.stores, self.menus, self.orders, self.coupons, [], now=self.now
        )
        history = result["history"]
        self.assertEqual(history["code"], "9900004066")
        self.assertGreater(history["original_price"], history["price"])
        self.assertAlmostEqual(history["order_amount"], 73.0)

    def test_warns_when_nearest_store_is_busier(self) -> None:
        # 午市高峰下最近门店必然处在高峰，应给出提示或明确「最近即最快」
        result = build_speed_mode(
            self.stores,
            self.menus,
            self.orders,
            self.coupons,
            [{"code": "1100", "name": "巨无霸", "quantity": 1}],
            now=self.now,
        )
        self.assertIsInstance(result["warnings"], list)
        self.assertTrue(result["coupons"])

    def test_no_selection_still_works(self) -> None:
        result = build_speed_mode(self.stores, self.menus, now=self.now)
        self.assertEqual(len(result["stores"]), len(self.stores))


class BundleTest(unittest.TestCase):
    """数据包契约：前端「用户信息下拉 / 积分换购 / 换店」依赖这些字段。"""

    def setUp(self) -> None:
        self.stores = parse_stores(nearby_stores_payload(1), be_type=1, city="深圳")
        self.menus = {
            s.store_code: parse_meals(menu_payload(s.store_code)) for s in self.stores
        }
        self.orders = parse_orders(ORDERS)
        self.now = datetime(2026, 10, 9, 12, 15)

    def _bundle(self) -> dict:
        return build_bundle(
            city="深圳",
            keyword="腾讯滨海大厦",
            stores=self.stores,
            menus_by_store=self.menus,
            activities=[],
            orders=self.orders,
            account=parse_account(ACCOUNT),
            now=self.now,
            demo=True,
            points_mall=[{"spu_id": 1, "name": "3.9元圆筒冰淇淋", "point": 100, "cash": 3.9}],
        )

    def test_account_payload_exposes_new_fields(self) -> None:
        account = self._bundle()["account"]
        for key in (
            "available_points", "accumulated_points", "expired_points", "unit",
            "account_id", "used_points", "frozen_points",
            "expiring_this_month", "expiring_next_month", "expired_last_month",
        ):
            self.assertIn(key, account)
        self.assertEqual(account["account_id"], "02001068760976359282457786702")

    def test_orders_payload_carries_preferred_names(self) -> None:
        orders = self._bundle()["orders"]
        self.assertEqual(len(orders), 1)
        self.assertEqual(orders[0]["products"][0]["name"], "堡堡随心拼（7件任选）")
        self.assertIn("巨无霸", orders[0]["preferred_names"])

    def test_points_mall_and_compositions_present(self) -> None:
        bundle = self._bundle()
        self.assertEqual(len(bundle["points_mall"]), 1)
        self.assertIn("compositions", bundle)


if __name__ == "__main__":
    unittest.main()
