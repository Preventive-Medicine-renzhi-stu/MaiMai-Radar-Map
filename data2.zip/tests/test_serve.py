"""本地一键服务（src.serve）与城市表的单元测试。

重点覆盖「诚实性」相关的边界：

* 没有 Token 时**不会**假装能实时切城市；
* 切换失败**绝不覆盖**已有数据包；
* 空结果（0 家门店）被视为失败而不是写出空数据；
* API 层的响应头与错误码。
"""

from __future__ import annotations

import http.client
import json
import os
import socket
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

from src import cities
from src import serve as serve_mod
from src.demo_client import DemoMCPClient
from src.serve import RadarApp, create_server, fetch_suggestions, resolve_now


def _json_response(payload: dict) -> mock.MagicMock:
    """伪装 urllib 的响应对象（支持 with 语句）。"""
    resp = mock.MagicMock()
    resp.read.return_value = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    resp.__enter__ = lambda s: s
    resp.__exit__ = lambda s, *a: False
    return resp


def _snapshot(city: str = "深圳", keyword: str = "腾讯滨海大厦") -> dict:
    return {
        "city": city,
        "keyword": keyword,
        "generated_at": "2026-10-09 12:15:00",
        "stores": [{"store_code": "1"}],
        "calendar": [{"date": "2026-10-09"}],
    }


class CityTableTest(unittest.TestCase):
    def test_table_covers_the_whole_country(self) -> None:
        """麦当劳 MCP 覆盖大陆全部有门店的城市，表里应当是地级行政区全量。"""
        self.assertGreaterEqual(len(cities.CITY_ORDER), 300)

    def test_every_city_has_a_keyword(self) -> None:
        for city in cities.CITY_ORDER:
            self.assertTrue(cities.default_keyword(city).strip(), city)

    def test_normalize_tolerates_suffix(self) -> None:
        self.assertEqual(cities.normalize_city("深圳市"), "深圳")
        self.assertEqual(cities.normalize_city("  上海 "), "上海")
        self.assertEqual(cities.normalize_city("广州市"), "广州")
        self.assertEqual(cities.normalize_city("不存在的城"), "不存在的城")

    def test_unknown_city_uses_its_own_name(self) -> None:
        """未知城市的首选关键词就是城市名本身 —— 实测这是最可能命中的词。"""
        self.assertEqual(cities.default_keyword("火星"), "火星")
        self.assertEqual(cities.keyword_candidates("火星")[0], "火星")

    def test_chain_always_ends_with_generic_words(self) -> None:
        """候选链的尾部必须包含通用兜底词，城市名救不回来时靠它们。"""
        for city in ("深圳", "呼伦贝尔", "阿坝藏族羌族自治州", "火星"):
            chain = cities.keyword_candidates(city)
            self.assertIn(cities.FALLBACK_KEYWORD, chain, city)
            self.assertIn("麦当劳", chain, city)
            self.assertEqual(len(chain), len(set(chain)), f"{city} 候选链有重复")

    def test_major_cities_keep_curated_landmark_first(self) -> None:
        """大城市保留人工地标（市中心店比火车站店更合理），且排在城市名之前。"""
        for city, landmark in (("上海", "人民广场"), ("深圳", "腾讯滨海大厦"), ("杭州", "西湖")):
            self.assertEqual(cities.default_keyword(city), landmark, city)
            self.assertEqual(cities.keyword_candidates(city)[1], city)

    def test_coordinates_available_for_map(self) -> None:
        """坐标用于把地图定位到城市，不依赖腾讯地图接口。"""
        for city in ("深圳", "上海", "拉萨", "呼伦贝尔"):
            coord = cities.coordinates(city)
            self.assertIsNotNone(coord, city)
            lat, lng = coord  # type: ignore[misc]
            self.assertTrue(3 < lat < 54, f"{city} 纬度异常 {lat}")
            self.assertTrue(73 < lng < 136, f"{city} 经度异常 {lng}")

    def test_hong_kong_macao_taiwan_excluded(self) -> None:
        """麦当劳 MCP 服务不含港澳台，表里不该出现（免得点了必然查不到）。"""
        for name in cities.CITY_ORDER:
            self.assertNotIn(name, {"香港", "澳门", "台北", "高雄"})

    def test_payload_shape(self) -> None:
        payload = cities.as_payload()
        self.assertGreaterEqual(len(payload), 300)
        self.assertTrue(
            all(set(item) == {"city", "keyword", "province", "lat", "lng"} for item in payload)
        )
        self.assertTrue(all(item["province"] for item in payload))


class SuggestTest(unittest.TestCase):
    """定位输入框的候选接口（腾讯「关键词输入提示」的服务端代理）。

    这里全部用 mock 打掉网络 —— 单测不该依赖外网与配额，也不该把 Token 带进 CI。
    """

    KEY = "K" * 20
    REFERER = "http://127.0.0.1:8770/index.html"

    def setUp(self) -> None:
        serve_mod._SUGGEST_CACHE.clear()

    def test_maps_records_to_candidates(self) -> None:
        payload = {
            "status": 0,
            "data": [
                {
                    "title": "人民广场[地铁站]",
                    "address": "地铁1号线,地铁2号线",
                    "province": "上海市",
                    "city": "上海市",
                    "district": "黄浦区",
                    "location": {"lat": 31.232572, "lng": 121.475242},
                },
                {"title": "脏数据：没有坐标", "location": {}},
            ],
        }
        with mock.patch("src.serve.urllib.request.urlopen", return_value=_json_response(payload)):
            out, status = fetch_suggestions("人民广场", "上海", key=self.KEY, referer=self.REFERER)

        self.assertEqual(status, 200)
        self.assertTrue(out["ok"])
        self.assertEqual(len(out["items"]), 1, "没有坐标的脏记录必须丢掉")
        item = out["items"][0]
        self.assertEqual(item["title"], "人民广场[地铁站]")
        self.assertEqual(item["city"], "上海市")
        self.assertEqual(item["district"], "黄浦区")
        self.assertAlmostEqual(item["lat"], 31.232572)
        self.assertAlmostEqual(item["lng"], 121.475242)

    def test_forwards_browser_referer(self) -> None:
        """Referer 必须原样转发。

        腾讯的白名单是「host:port 字面串」比较 —— 服务端自己发请求**不带 Referer**
        会直接 110。把浏览器带上来的 Referer 转过去，正好命中用户已配好的白名单。
        """
        seen: dict[str, str] = {}

        def fake_urlopen(request, timeout=None):  # noqa: ANN001
            seen["referer"] = request.get_header("Referer") or ""
            seen["url"] = request.full_url
            return _json_response({"status": 0, "data": []})

        with mock.patch("src.serve.urllib.request.urlopen", side_effect=fake_urlopen):
            fetch_suggestions("人民广场", "上海", key=self.KEY, referer=self.REFERER)

        self.assertEqual(seen["referer"], self.REFERER)
        self.assertIn("keyword=", seen["url"])
        self.assertIn("region=", seen["url"])
        self.assertIn("page_size=5", seen["url"])

    def test_missing_key_is_explicit_not_empty(self) -> None:
        """没配 Key 时必须说清楚，**不能返回空候选假装「没搜到」**。"""
        out, status = fetch_suggestions("人民广场", key="")
        self.assertFalse(out["ok"])
        self.assertEqual(out["code"], "no_key")
        self.assertEqual(status, 409)
        self.assertIn("TMAP_KEY", out["message"])

    def test_blank_keyword_rejected(self) -> None:
        out, status = fetch_suggestions("   ", key=self.KEY)
        self.assertFalse(out["ok"])
        self.assertEqual(status, 400)

    def test_whitelist_error_is_explained(self) -> None:
        payload = {"status": 110, "message": "来源域名未被授权"}
        with mock.patch("src.serve.urllib.request.urlopen", return_value=_json_response(payload)):
            out, status = fetch_suggestions("人民广场", key=self.KEY, referer=self.REFERER)
        self.assertFalse(out["ok"])
        self.assertEqual(out["code"], "tmap_110")
        self.assertIn("白名单", out["message"])
        self.assertEqual(status, 200, "腾讯的业务错误不是 HTTP 错误")

    def test_quota_error_mentions_retry(self) -> None:
        payload = {"status": 121, "message": "此key每日调用量已达到上限"}
        with mock.patch("src.serve.urllib.request.urlopen", return_value=_json_response(payload)):
            out, _ = fetch_suggestions("人民广场", key=self.KEY, referer=self.REFERER)
        self.assertEqual(out["code"], "tmap_121")
        self.assertIn("瞬时", out["message"])

    def test_network_failure_is_wrapped(self) -> None:
        with mock.patch("src.serve.urllib.request.urlopen", side_effect=OSError("boom")):
            out, status = fetch_suggestions("人民广场", key=self.KEY, referer=self.REFERER)
        self.assertFalse(out["ok"])
        self.assertEqual(out["code"], "network")
        self.assertEqual(status, 502)

    def test_repeat_query_hits_cache(self) -> None:
        """逐字敲键盘会连打十几次接口 —— 相同的词不该重复烧配额。"""
        calls: list[str] = []

        def fake_urlopen(request, timeout=None):  # noqa: ANN001
            calls.append(request.full_url)
            return _json_response(
                {"status": 0, "data": [{"title": "A", "location": {"lat": 1.0, "lng": 2.0}}]}
            )

        with mock.patch("src.serve.urllib.request.urlopen", side_effect=fake_urlopen):
            fetch_suggestions("人民广场", "上海", key=self.KEY, referer=self.REFERER)
            out, _ = fetch_suggestions("人民广场", "上海", key=self.KEY, referer=self.REFERER)

        self.assertEqual(len(calls), 1, "第二次应当命中缓存")
        self.assertTrue(out.get("cached"))
        self.assertEqual(len(out["items"]), 1)


class ResolveNowTest(unittest.TestCase):
    def test_fixed_clock(self) -> None:
        now = resolve_now("12:15")
        self.assertEqual((now.hour, now.minute, now.second), (12, 15, 0))

    def test_bad_input_warns_but_returns_now(self) -> None:
        self.assertIsNotNone(resolve_now("oops").year)


class StatusTest(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self._tmp.name)
        self.app = RadarApp(web_dir=self.dir, demo=True)

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_status_without_snapshot(self) -> None:
        status = self.app.status()
        self.assertTrue(status["ok"])
        self.assertFalse(status["live"])
        self.assertEqual(status["mode"], "demo")
        self.assertIn("--demo", status["live_reason"])
        self.assertEqual(status["store_count"], 0)
        self.assertEqual(len(status["cities"]), len(cities.CITY_ORDER))

    def test_status_reads_snapshot_metadata(self) -> None:
        (self.dir / "data.json").write_text(
            json.dumps(_snapshot(), ensure_ascii=False), encoding="utf-8"
        )
        status = self.app.status()
        self.assertEqual(status["city"], "深圳")
        self.assertEqual(status["keyword"], "腾讯滨海大厦")
        self.assertEqual(status["store_count"], 1)
        self.assertEqual(status["calendar_days"], 1)

    def test_broken_snapshot_does_not_crash(self) -> None:
        (self.dir / "data.json").write_text("{ not json", encoding="utf-8")
        self.assertEqual(self.app.snapshot(), {})
        self.assertTrue(self.app.status()["ok"])


class SwitchCityTest(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self._tmp.name)
        (self.dir / "data.json").write_text(
            json.dumps(_snapshot(), ensure_ascii=False), encoding="utf-8"
        )

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_rejects_empty_city(self) -> None:
        app = RadarApp(web_dir=self.dir, demo=True)
        payload, status = app.switch_city("   ")
        self.assertEqual(status, 400)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["code"], "bad_request")

    def test_offline_refuses_other_city(self) -> None:
        app = RadarApp(web_dir=self.dir, demo=True)
        payload, status = app.switch_city("上海")
        self.assertEqual(status, 409)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["code"], "offline")
        self.assertIn("MCD_MCP_TOKEN", payload["hint"])

    def test_offline_same_city_is_noop(self) -> None:
        app = RadarApp(web_dir=self.dir, demo=True)
        payload, status = app.switch_city("深圳")
        self.assertEqual(status, 200)
        self.assertTrue(payload["ok"])
        self.assertTrue(payload["unchanged"])

    def test_city_name_is_normalized(self) -> None:
        app = RadarApp(web_dir=self.dir, demo=True)
        payload, _ = app.switch_city("深圳市")
        self.assertTrue(payload["unchanged"])

    def test_live_switch_writes_assets(self) -> None:
        """有 Token 时：真的走一遍 collect + write_assets（客户端用离线快照冒充）。"""
        with mock.patch.object(RadarApp, "settings", new=staticmethod(lambda: object())), \
                mock.patch("src.serve.HttpMCPClient", DemoMCPClient):
            app = RadarApp(web_dir=self.dir, demo=False)
            self.assertTrue(app.live)
            payload, status = app.switch_city("上海", "人民广场")

        self.assertEqual(status, 200, payload)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["city"], "上海")
        self.assertGreater(payload["store_count"], 0)
        self.assertIn("data.js", payload["files"])

        written = json.loads((self.dir / "data.json").read_text(encoding="utf-8"))
        self.assertEqual(written["city"], "上海")
        self.assertEqual(written["keyword"], "人民广场")
        # 城市表随数据包下发，前端不用再维护第二份
        self.assertEqual(len(written["cities"]), len(cities.CITY_ORDER))
        self.assertTrue((self.dir / "data.js").exists())

    def test_empty_result_keeps_old_snapshot(self) -> None:
        """关键防线：拿到 0 家门店时必须报错，不能把好数据换成空数据。

        显式关键词仍然**第一个**试（用户说了用「观前街」就先试它），但不再只试它 ——
        见 test_explicit_keyword_falls_back_to_city_chain：一个失效关键词不该把
        整座城市堵死。这里让它连候选链一起全空，验证失败时报错且不动旧快照。
        """
        before = (self.dir / "data.json").read_text(encoding="utf-8")

        class Empty(DemoMCPClient):
            async def call(self, tool, arguments=None):
                if tool == "query-nearby-stores":
                    return {"success": True, "code": 200, "data": {"stores": []}}
                return await super().call(tool, arguments)

        with mock.patch.object(RadarApp, "settings", new=staticmethod(lambda: object())), \
                mock.patch("src.serve.HttpMCPClient", Empty):
            app = RadarApp(web_dir=self.dir, demo=False)
            payload, status = app.switch_city("苏州", "观前街")

        self.assertEqual(status, 404)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["code"], "empty")
        self.assertIn("没有返回任何门店", payload["message"])
        # 用户的词排第一位，后面接上该城市的候选链
        self.assertEqual(payload["tried"][0], "观前街")
        self.assertEqual(payload["tried"], cities.keyword_candidates("苏州"))
        self.assertEqual((self.dir / "data.json").read_text(encoding="utf-8"), before)

    def test_auto_keyword_chain_retries_until_a_hit(self) -> None:
        """候选链：不填关键词时，第一个词查不到就应该自动换下一个，而不是直接失败。

        实测场景：呼伦贝尔的门店店名写的是「海拉尔」，用城市名查不到，
        但「市中心」能查到。这里用假客户端复现这条链路。
        """
        calls: list[str] = []

        class OnlyCenterWorks(DemoMCPClient):
            async def call(self, tool, arguments=None):
                if tool == "query-nearby-stores":
                    calls.append((arguments or {}).get("keyword", ""))
                    if (arguments or {}).get("keyword") == "市中心":
                        return await super().call(tool, arguments)
                    return {"success": True, "code": 200, "data": {"stores": []}}
                return await super().call(tool, arguments)

        with mock.patch.object(RadarApp, "settings", new=staticmethod(lambda: object())), \
                mock.patch("src.serve.HttpMCPClient", OnlyCenterWorks):
            app = RadarApp(web_dir=self.dir, demo=False)
            payload, status = app.switch_city("呼伦贝尔", "")

        self.assertEqual(status, 200, payload)
        self.assertEqual(payload["matched_keyword"], "市中心")
        self.assertTrue(payload["keyword_guessed"])
        # 应该按候选链顺序试：地标（无）→ 城市名 → 市中心
        self.assertEqual(calls, ["呼伦贝尔", "市中心"])

    def test_explicit_keyword_falls_back_to_city_chain(self) -> None:
        """显式关键词取不到时，必须退回城市候选链兜底（线上实测 bug）。

        场景：在深圳选了「深圳湾公园[地铁站]」，再从城市下拉切北京 ——
        这串字被当成检索关键词发给北京，MCP 在北京查不到 → 返回 0 家门店 →
        整座北京被误判成「没有门店」，切换失败。
        断言：第一个试的仍是用户显式给的词（不擅自改主意），但没被它堵死，
        退回候选链后成功，并标记 explicit_keyword_dropped 让前端如实提示。
        """
        calls: list[str] = []

        class BeijingHatesShenzhenKw(DemoMCPClient):
            async def call(self, tool, arguments=None):
                if tool == "query-nearby-stores":
                    kw = (arguments or {}).get("keyword", "")
                    calls.append(kw)
                    if "深圳湾公园" in kw:
                        return {"success": True, "code": 200, "data": {"stores": []}}
                    return await super().call(tool, arguments)
                return await super().call(tool, arguments)

        with mock.patch.object(RadarApp, "settings", new=staticmethod(lambda: object())), \
                mock.patch("src.serve.HttpMCPClient", BeijingHatesShenzhenKw):
            app = RadarApp(web_dir=self.dir, demo=False)
            payload, status = app.switch_city("北京", "深圳湾公园[地铁站]")

        self.assertEqual(status, 200, payload)
        self.assertEqual(calls[0], "深圳湾公园[地铁站]")
        self.assertNotEqual(payload["matched_keyword"], "深圳湾公园[地铁站]")
        self.assertIn(payload["matched_keyword"], cities.keyword_candidates("北京"))
        self.assertTrue(payload["keyword_guessed"])
        self.assertTrue(payload["explicit_keyword_dropped"])

    def test_explicit_keyword_that_works_is_not_marked_guessed(self) -> None:
        """显式关键词第一个就命中时，不能被标成「系统猜的」，也不该提示已换词。"""
        with mock.patch.object(RadarApp, "settings", new=staticmethod(lambda: object())), \
                mock.patch("src.serve.HttpMCPClient", DemoMCPClient):
            app = RadarApp(web_dir=self.dir, demo=False)
            payload, status = app.switch_city("杭州", "西湖")

        self.assertEqual(status, 200, payload)
        self.assertEqual(payload["matched_keyword"], "西湖")
        self.assertFalse(payload["keyword_guessed"])
        self.assertFalse(payload["explicit_keyword_dropped"])

    def test_all_keywords_failing_reports_what_was_tried(self) -> None:
        """整条链都空 → 如实说「该城市可能没有门店」，并列出试过哪些词。"""
        before = (self.dir / "data.json").read_text(encoding="utf-8")

        class NeverAny(DemoMCPClient):
            async def call(self, tool, arguments=None):
                if tool == "query-nearby-stores":
                    return {"success": True, "code": 200, "data": {"stores": []}}
                return await super().call(tool, arguments)

        with mock.patch.object(RadarApp, "settings", new=staticmethod(lambda: object())), \
                mock.patch("src.serve.HttpMCPClient", NeverAny):
            app = RadarApp(web_dir=self.dir, demo=False)
            payload, status = app.switch_city("喀什", "")

        self.assertEqual(status, 404)
        self.assertEqual(payload["code"], "empty")
        self.assertEqual(payload["tried"], cities.keyword_candidates("喀什"))
        self.assertGreaterEqual(len(payload["tried"]), 3)
        self.assertEqual((self.dir / "data.json").read_text(encoding="utf-8"), before)

    def test_export_failure_keeps_old_snapshot(self) -> None:
        before = (self.dir / "data.json").read_text(encoding="utf-8")

        class Boom(DemoMCPClient):
            def __init__(self, *args, **kwargs):
                raise RuntimeError("网络断了")

        with mock.patch.object(RadarApp, "settings", new=staticmethod(lambda: object())), \
                mock.patch("src.serve.HttpMCPClient", Boom):
            app = RadarApp(web_dir=self.dir, demo=False)
            payload, status = app.switch_city("北京", "国贸")

        self.assertEqual(status, 502)
        self.assertIn("原有数据包未被改动", payload["hint"])
        self.assertEqual((self.dir / "data.json").read_text(encoding="utf-8"), before)

    def test_default_keyword_fills_in(self) -> None:
        with mock.patch.object(RadarApp, "settings", new=staticmethod(lambda: object())), \
                mock.patch("src.serve.HttpMCPClient", DemoMCPClient):
            app = RadarApp(web_dir=self.dir, demo=False)
            payload, _ = app.switch_city("杭州", "")
        self.assertEqual(payload["keyword"], "西湖")


class SaveTokenTest(unittest.TestCase):
    """网页里直接填 Token —— 让「配置」也不用碰命令行。"""

    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.env = Path(self._tmp.name) / ".env"
        self.app = RadarApp(web_dir=Path(self._tmp.name), demo=True)

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_rejects_short_token(self) -> None:
        payload, status = self.app.save_token("abc", env_path=self.env)
        self.assertEqual(status, 400)
        self.assertEqual(payload["code"], "bad_token")
        self.assertFalse(self.env.exists(), "校验失败时不应该写文件")

    def test_rejects_newline(self) -> None:
        payload, status = self.app.save_token("x" * 40 + "\nrm -rf /", env_path=self.env)
        self.assertEqual(status, 400)
        self.assertFalse(self.env.exists())

    def test_creates_env_when_missing(self) -> None:
        with mock.patch.dict(os.environ):
            payload, status = self.app.save_token("t" * 32, env_path=self.env)
            # 环境变量必须在 with 内断言：patch.dict 退出时会把新增的键还原掉
            self.assertEqual(os.environ.get("MCD_MCP_TOKEN"), "t" * 32)
        self.assertEqual(status, 200)
        self.assertTrue(payload["ok"])
        self.assertIn("MCD_MCP_TOKEN=" + "t" * 32, self.env.read_text(encoding="utf-8"))

    def test_replaces_only_token_line(self) -> None:
        self.env.write_text(
            "# 注释\nMCD_MCP_TOKEN=\nTMAP_KEY=keep-me\n", encoding="utf-8"
        )
        with mock.patch.dict(os.environ):
            _, status = self.app.save_token("z" * 24, env_path=self.env)
        self.assertEqual(status, 200)
        text = self.env.read_text(encoding="utf-8")
        self.assertIn("MCD_MCP_TOKEN=" + "z" * 24, text)
        self.assertIn("TMAP_KEY=keep-me", text)
        self.assertIn("# 注释", text)
        self.assertNotIn("MCD_MCP_TOKEN=\n", text)

    def test_token_never_echoed_back(self) -> None:
        secret = "s" * 28
        with mock.patch.dict(os.environ):
            payload, _ = self.app.save_token(secret, env_path=self.env)
        self.assertNotIn(secret, json.dumps(payload, ensure_ascii=False))

    def test_becomes_live_after_saving(self) -> None:
        app = RadarApp(web_dir=Path(self._tmp.name), demo=False)
        with mock.patch.dict(os.environ, {"MCD_MCP_TOKEN": ""}):
            self.assertFalse(app.live, "空 Token 时不该声称能实时切城市")
            payload, _ = app.save_token("k" * 30, env_path=self.env)
            self.assertTrue(payload["live"])
            self.assertTrue(app.live, "写入 Token 后应立即生效，无需重启")


class ServeHttpTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls._tmp = tempfile.TemporaryDirectory()
        cls.dir = Path(cls._tmp.name)
        (cls.dir / "index.html").write_text("<h1>radar</h1>", encoding="utf-8")
        (cls.dir / "data.json").write_text(
            json.dumps(_snapshot(), ensure_ascii=False), encoding="utf-8"
        )
        cls.app = RadarApp(web_dir=cls.dir, demo=True)
        cls.httpd, cls.port = create_server(cls.app, 18631, tries=8)
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls._tmp.cleanup()

    def _request(self, method: str, path: str, body: dict | None = None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        payload = json.dumps(body).encode("utf-8") if body is not None else None
        headers = {"Content-Type": "application/json"} if payload else {}
        try:
            conn.request(method, path, body=payload, headers=headers)
            res = conn.getresponse()
            raw = res.read().decode("utf-8")
            return res, raw
        finally:
            conn.close()

    def test_status_endpoint(self) -> None:
        res, raw = self._request("GET", "/api/status")
        self.assertEqual(res.status, 200)
        self.assertIn("application/json", res.getheader("Content-Type"))
        self.assertEqual(res.getheader("Cache-Control"), "no-store")
        data = json.loads(raw)
        self.assertTrue(data["ok"])
        self.assertEqual(data["service"], "mcd-radar-local")
        self.assertEqual(data["city"], "深圳")
        self.assertFalse(data["live"])

    def test_static_index(self) -> None:
        res, raw = self._request("GET", "/index.html")
        self.assertEqual(res.status, 200)
        self.assertIn("radar", raw)

    def test_static_assets_are_not_cached(self) -> None:
        """静态资源必须带 no-cache。

        本地服务是开发用的：改了 styles.css / *.js 之后刷新看不到效果，
        很容易被误判成「改了没用」。所以静态资源一律走校验式缓存，
        而 API 响应继续用 no-store。
        """
        res, _ = self._request("GET", "/index.html")
        self.assertEqual(res.status, 200)
        self.assertIn("no-cache", res.getheader("Cache-Control", ""))

        # API 不能被这条规则覆盖掉
        api_res, _ = self._request("GET", "/api/status")
        self.assertEqual(api_res.getheader("Cache-Control"), "no-store")

    def test_missing_tmap_key_returns_empty_script(self) -> None:
        res, raw = self._request("GET", "/tmap-key.local.js")
        self.assertEqual(res.status, 200)
        self.assertIn("javascript", res.getheader("Content-Type"))
        self.assertIn("未配置 TMAP_KEY", raw)

    def test_suggest_without_key_explains_itself(self) -> None:
        """没配 TMAP_KEY 时 /api/suggest 要明确报错，而不是回一个空列表假装搜过了。"""
        serve_mod._SUGGEST_CACHE.clear()
        with mock.patch("src.serve.load_tmap_key", return_value=""):
            res, raw = self._request("GET", "/api/suggest?keyword=%E4%BA%BA%E6%B0%91%E5%B9%BF%E5%9C%BA")
        data = json.loads(raw)
        self.assertEqual(res.status, 409)
        self.assertFalse(data["ok"])
        self.assertEqual(data["code"], "no_key")

    def test_suggest_proxies_tencent_with_local_referer(self) -> None:
        """端到端（打掉外网）：/api/suggest 会转发请求，且 Referer 指向本机服务。

        为什么非要带 Referer：腾讯白名单按 host:port 字面串比较，
        服务端裸请求必然 110。转发本机地址即可命中用户已配的白名单。
        """
        serve_mod._SUGGEST_CACHE.clear()
        seen: dict[str, str] = {}
        payload = {
            "status": 0,
            "data": [
                {"title": "人民广场", "address": "地铁", "city": "上海市",
                 "district": "黄浦区", "location": {"lat": 31.2, "lng": 121.5}},
            ],
        }

        def fake_urlopen(request, timeout=None):  # noqa: ANN001
            seen["referer"] = request.get_header("Referer") or ""
            return _json_response(payload)

        with mock.patch("src.serve.load_tmap_key", return_value="K" * 20), \
             mock.patch("src.serve.urllib.request.urlopen", side_effect=fake_urlopen):
            res, raw = self._request(
                "GET", "/api/suggest?keyword=%E4%BA%BA%E6%B0%91%E5%B9%BF%E5%9C%BA&region=%E4%B8%8A%E6%B5%B7"
            )

        self.assertEqual(res.status, 200)
        data = json.loads(raw)
        self.assertTrue(data["ok"])
        self.assertEqual(data["items"][0]["title"], "人民广场")
        self.assertTrue(seen["referer"].startswith("http://127.0.0.1:"),
                        f"Referer 应指向本机服务，实际 {seen['referer']!r}")

    def test_unknown_api_returns_404(self) -> None:
        res, raw = self._request("POST", "/api/nope", {})
        self.assertEqual(res.status, 404)
        self.assertFalse(json.loads(raw)["ok"])

    def test_switch_city_offline_conflict(self) -> None:
        res, raw = self._request("POST", "/api/city", {"city": "上海"})
        self.assertEqual(res.status, 409)
        payload = json.loads(raw)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["code"], "offline")

    def test_switch_city_same_city_ok(self) -> None:
        res, raw = self._request("POST", "/api/city", {"city": "深圳"})
        self.assertEqual(res.status, 200)
        self.assertTrue(json.loads(raw)["unchanged"])

    def test_options_preflight(self) -> None:
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        try:
            conn.request("OPTIONS", "/api/city")
            res = conn.getresponse()
            res.read()
            self.assertEqual(res.status, 204)
            self.assertEqual(res.getheader("Access-Control-Allow-Origin"), "*")
        finally:
            conn.close()

    def test_token_endpoint_is_wired(self) -> None:
        # 空 Token 会在校验阶段就被拒（400），不会碰到项目里的 .env
        res, raw = self._request("POST", "/api/token", {"token": ""})
        self.assertEqual(res.status, 400)
        self.assertEqual(json.loads(raw)["code"], "bad_token")


class PortFallbackTest(unittest.TestCase):
    def test_busy_port_is_skipped(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            blocker = socket.socket()
            blocker.bind(("127.0.0.1", 0))
            blocker.listen(1)
            busy_port = blocker.getsockname()[1]
            try:
                app = RadarApp(web_dir=Path(tmp), demo=True)
                httpd, bound = create_server(app, busy_port, tries=4)
                try:
                    self.assertNotEqual(bound, busy_port)
                    self.assertGreater(bound, busy_port)
                finally:
                    httpd.server_close()
            finally:
                blocker.close()


class ExistingInstanceTest(unittest.TestCase):
    """端口上已经有本服务时，不能再起第二个实例。

    真实踩到的坑：Windows 的 ``allow_reuse_address`` 允许**两个进程同时 bind 同一个端口**，
    所以「再双击一次 start.bat」会悄悄多起一个实例，两个实例抢同一条连接 ——
    用户看到的是「一会儿正常一会儿不正常」。前置探测就是为这件事守的门。
    """

    def _start_stub(self, payload: dict):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

        body = json.dumps(payload).encode("utf-8")

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):  # 测试输出保持干净
                pass

        httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        return httpd, httpd.server_address[1]

    def test_false_when_nothing_listens(self) -> None:
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            free_port = probe.getsockname()[1]
        self.assertFalse(serve_mod.probe_existing_service(free_port, timeout=0.4))

    def test_true_when_our_service_answers(self) -> None:
        httpd, port = self._start_stub({"ok": True, "service": "mcd-radar-local"})
        try:
            self.assertTrue(serve_mod.probe_existing_service(port, timeout=0.8))
        finally:
            httpd.shutdown()
            httpd.server_close()

    def test_false_when_the_port_belongs_to_someone_else(self) -> None:
        httpd, port = self._start_stub({"ok": True, "service": "some-other-app"})
        try:
            self.assertFalse(serve_mod.probe_existing_service(port, timeout=0.8))
        finally:
            httpd.shutdown()
            httpd.server_close()

    def test_run_server_reuses_the_running_instance(self) -> None:
        httpd, port = self._start_stub({"ok": True, "service": "mcd-radar-local"})
        try:
            with mock.patch("src.serve.create_server") as create, \
                    mock.patch("src.serve.webbrowser.open") as opener:
                rc = serve_mod.run_server(
                    mock.MagicMock(live=False), port=port, open_browser=True
                )
            self.assertEqual(rc, 0)
            create.assert_not_called()          # 没有再起第二个实例
            opener.assert_called_once()          # 直接复用，把浏览器指过去
            self.assertIn(f":{port}/index.html", opener.call_args[0][0])
        finally:
            httpd.shutdown()
            httpd.server_close()


if __name__ == "__main__":
    unittest.main()
