/**
 * 腾讯地图加载策略测试：验证 index.html 的「Key / 代理」双模式选择逻辑。
 *
 * 不依赖网络：只解析 index.html 的内联脚本，拦截 document.head.appendChild
 * 以捕获动态创建的 SDK <script>，检查其 src 与全局标记是否正确。
 *
 * 运行：
 *   NODE_PATH=<node_modules> node tests/test_tmap_loader.js
 */

const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const WEB = path.join(__dirname, '..', 'web');
const html = fs.readFileSync(path.join(WEB, 'index.html'), 'utf8');
const appSrc = fs.readFileSync(path.join(WEB, 'app.js'), 'utf8');

let pass = 0;
let fail = 0;

function check(label, ok, extra) {
  if (ok) {
    pass++;
    console.log('  \u2713 ' + label);
  } else {
    fail++;
    console.log('  \u2717 ' + label + (extra ? '  \u2192 ' + extra : ''));
  }
}

/** 取出 index.html 中「没有 src 属性」的内联脚本（即我们的加载策略） */
function inlineScripts(source) {
  const out = [];
  const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while ((m = re.exec(source))) out.push(m[1]);
  return out;
}

/** 在隔离的 jsdom 中执行加载策略，返回捕获到的动态 script */
function load(tmapKey) {
  const dom = new JSDOM(html, {
    runScripts: 'outside-only',
    url: 'http://127.0.0.1:8770/index.html'
  });
  const { window } = dom;
  if (tmapKey) window.__TMAP_KEY__ = tmapKey;

  const captured = [];
  const head = window.document.head;
  const origAppend = head.appendChild.bind(head);
  head.appendChild = function (el) {
    if (el && el.tagName === 'SCRIPT') {
      captured.push(el);
      return el;
    }
    return origAppend(el);
  };

  inlineScripts(html).forEach(function (code) {
    window.eval(code);
  });
  return { window: window, captured: captured };
}

console.log('[1] 未配置 TMAP_KEY → 回退 WorkBuddy 代理模式');
const a = load('');
check('__TMAP_MODE__ = proxy', a.window.__TMAP_MODE__ === 'proxy', String(a.window.__TMAP_MODE__));
check(
  '已设置 _TMapSecurityConfig.serviceHost',
  !!(a.window._TMapSecurityConfig && a.window._TMapSecurityConfig.serviceHost)
);
check('动态创建了 1 个 SDK script', a.captured.length === 1, '实际 ' + a.captured.length);
check('SDK src 不带 key 参数', !!a.captured[0] && a.captured[0].src.indexOf('key=') < 0, a.captured[0] && a.captured[0].src);
check('SDK src 带 libraries=service', !!a.captured[0] && a.captured[0].src.indexOf('libraries=service') >= 0);
check('__TMAP_PENDING__ = true', a.window.__TMAP_PENDING__ === true);

console.log('');
console.log('[2] 配置 TMAP_KEY → 腾讯标准 Key 模式');
const b = load('OB4BZ-DEMO-TEST-KEY');
check('__TMAP_MODE__ = key', b.window.__TMAP_MODE__ === 'key', String(b.window.__TMAP_MODE__));
check('未设置 _TMapSecurityConfig（不走向代理）', b.window._TMapSecurityConfig === undefined);
check('SDK src 携带 key', !!b.captured[0] && b.captured[0].src.indexOf('key=OB4BZ-DEMO-TEST-KEY') >= 0, b.captured[0] && b.captured[0].src);
check('SDK src 仍保留 libraries=service', !!b.captured[0] && b.captured[0].src.indexOf('libraries=service') >= 0);

console.log('');
console.log('[3] SDK 加载成功 → 通知 app.js 就绪');
const c = load('OB4BZ-DEMO-TEST-KEY');
if (c.captured[0] && c.captured[0].onload) c.captured[0].onload();
check('__TMAP_PENDING__ = false', c.window.__TMAP_PENDING__ === false);
check('__TMAP_READY__ = true', c.window.__TMAP_READY__ === true);

console.log('');
console.log('[4] SDK 加载失败 → 标记 error，触发降级链路');
const d = load('');
if (d.captured[0] && d.captured[0].onerror) d.captured[0].onerror();
check('__TMAP_PENDING__ = false', d.window.__TMAP_PENDING__ === false);
check('__TMAP_READY__ = "error"', d.window.__TMAP_READY__ === 'error', String(d.window.__TMAP_READY__));

console.log('');
console.log('[5] app.js 启动钩子（防止回归：必须等 SDK 再 boot）');
check('含 waitForTMap 实现', appSrc.indexOf('function waitForTMap') >= 0);
check('启动被 start() 包裹', appSrc.indexOf('function start()') >= 0);
check('DOMContentLoaded 绑定的是 start 而非 boot', appSrc.indexOf("addEventListener('DOMContentLoaded', start)") >= 0);
check('仅在 __TMAP_PENDING__ 时等待', appSrc.indexOf('if (!window.__TMAP_PENDING__) return resolve') >= 0);

console.log('');
console.log('结果：' + pass + ' 通过 / ' + fail + ' 失败');
process.exit(fail ? 1 : 0);
