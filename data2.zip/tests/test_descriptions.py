"""餐品简介模块单元测试。

麦当劳 MCP 不提供营销文案，简介由本项目三层兜底生成。
这里锁住三件事：
  1. 手写文案必须命中主流餐品，且**不得为空**；
  2. 关键词规则按声明顺序生效（顺序即优先级）；
  3. 兜底 ``generic()`` 只依据真实属性，**不编造**卖点。
"""

from __future__ import annotations

import unittest

from src import descriptions
from src.descriptions import DESCRIPTIONS, KEYWORD_RULES, all_keywords, describe, generic


class DescriptionTableTest(unittest.TestCase):
    def test_table_not_empty(self) -> None:
        self.assertGreaterEqual(len(DESCRIPTIONS), 40)

    def test_no_blank_copy(self) -> None:
        for code, text in DESCRIPTIONS.items():
            with self.subTest(code=code):
                self.assertTrue(text.strip(), f"{code} 的简介为空")

    def test_known_code_hits_handwritten_copy(self) -> None:
        # 巨无霸
        self.assertEqual(describe("1100", "巨无霸"), DESCRIPTIONS["1100"])
        # 薯条
        self.assertEqual(describe("4810", "薯条"), DESCRIPTIONS["4810"])

    def test_code_is_coerced_to_str(self) -> None:
        self.assertEqual(describe(1100, "巨无霸"), DESCRIPTIONS["1100"])

    def test_unknown_code_falls_back_to_keyword_rule(self) -> None:
        text = describe("__nope__", "香辣鸡腿堡套餐")
        self.assertIn("套餐", text)
        self.assertEqual(text, dict(KEYWORD_RULES)["套餐"])

    def test_keyword_order_is_priority(self) -> None:
        """「巨无霸三件套」同时含「三件套」与「套餐」，应命中靠前的「三件套」。"""
        text = describe("__nope__", "巨无霸三件套")
        self.assertEqual(text, dict(KEYWORD_RULES)["三件套"])

    def test_handwritten_beats_keyword(self) -> None:
        # 9900005466 是「巨无霸三件套」，有手写文案，不该被关键词规则抢走
        self.assertEqual(describe("9900005466", "巨无霸三件套"), DESCRIPTIONS["9900005466"])

    def test_all_keywords_exposed(self) -> None:
        keywords = list(all_keywords())
        self.assertEqual(len(keywords), len(KEYWORD_RULES))
        self.assertIn("套餐", keywords)


class GenericFallbackTest(unittest.TestCase):
    def test_no_tags_no_discount_gives_neutral_copy(self) -> None:
        text = generic("神秘新品")
        self.assertIn("神秘新品", text)
        self.assertIn("门店实际出餐为准", text)

    def test_includes_real_tags(self) -> None:
        text = generic("神秘新品", tags=["单品", "人气"])
        self.assertIn("标签", text)
        self.assertIn("单品", text)
        self.assertIn("人气", text)

    def test_includes_discount_context(self) -> None:
        text = generic("神秘新品", tags=["单品"], discount_type="第二份半价")
        self.assertIn("第二份半价", text)

    def test_price_pair_only_when_actually_discounted(self) -> None:
        shown = generic("神秘新品", price=10.0, original_price=15.0)
        self.assertIn("现价", shown)
        self.assertIn("划线价", shown)

    def test_no_fabricated_price_when_prices_equal(self) -> None:
        flat = generic("神秘新品", price=10.0, original_price=10.0)
        self.assertNotIn("划线价", flat)

    def test_no_fabricated_claims(self) -> None:
        """兜底文案不得出现「最好吃 / 第一 / 秒杀」这类主观或违规表述。"""
        text = generic("神秘新品", tags=["单品"], price=9.9, original_price=12.9, discount_type="特惠")
        for banned in ("最好", "第一", "秒杀", "全网", "之首"):
            with self.subTest(banned=banned):
                self.assertNotIn(banned, text)

    def test_handwritten_copy_has_no_superlative_claims(self) -> None:
        for code, text in DESCRIPTIONS.items():
            with self.subTest(code=code):
                for banned in ("最好吃", "第一名", "秒杀", "全网最低"):
                    self.assertNotIn(banned, text)


if __name__ == "__main__":
    unittest.main()
