"""重新生成前端冒烟测试用的数据包夹具。

    python -m tests.make_fixture

为什么需要它
------------
``web/data.js`` 是**真实数据包**，会随着用户在网页上切换城市而被重写
（本地服务的 ``/api/city`` 直接改它）。前端冒烟测试如果直接读它，
测试结果就会取决于「这次导出的是哪座城市」——换一座门店结构不同的城市，
断言就会莫名其妙地变红。

所以测试改为读 ``tests/fixtures/demo-data.js``：一份由 ``--demo``
内置快照生成的确定性数据，与真实数据完全解耦。

什么时候需要重跑
----------------
* ``src/demo_client.py`` 里的快照结构改了；
* 数据包结构变了（``build_bundle`` 增删字段）；
* 前端新增了依赖数据包字段的功能。
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

from src.demo_client import DemoMCPClient
from src.webexport import collect

FIXTURE = Path(__file__).resolve().parent / "fixtures" / "demo-data.js"
CITY = "深圳"
KEYWORD = "腾讯滨海大厦"

HEADER = """// 前端冒烟测试夹具：由 `--demo` 内置快照生成，与 web/data.js 解耦。
//
// web/data.js 是真实数据包，会随着用户切换城市而变；测试若直接读它，
// 就会因「这次导出的是哪座城市」而忽绿忽红。因此测试统一读本夹具。
//
// 请勿手工编辑。重新生成： python -m tests.make_fixture
"""


async def build() -> dict:
    client = DemoMCPClient()
    return await collect(client, city=CITY, keyword=KEYWORD, demo=True)


def render(bundle: dict) -> str:
    body = json.dumps(bundle, ensure_ascii=False, separators=(",", ":"))
    return HEADER + "window.MCD_DATA = " + body + ";\n"


def main() -> int:
    bundle = asyncio.run(build())
    FIXTURE.parent.mkdir(parents=True, exist_ok=True)
    FIXTURE.write_text(render(bundle), encoding="utf-8")

    stores = bundle.get("stores") or []
    activities = sum(len(day.get("activities") or []) for day in bundle.get("calendar") or [])
    print(f"已写出 {FIXTURE}")
    print(f"  city={bundle.get('city')} 门店={len(stores)} 活动={activities} "
          f"日历={len(bundle.get('calendar') or [])} 天")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
