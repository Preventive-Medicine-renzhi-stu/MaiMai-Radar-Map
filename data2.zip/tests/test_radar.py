"""核心逻辑单元测试（stdlib unittest，零额外依赖）。

运行： python -m unittest discover -s tests -t .
"""

from __future__ import annotations

import unittest
from datetime import date

from src.demo_data import AVAILABLE_COUPONS_TEXT as COUPONS_TEXT
from src.demo_data import calendar_text
from src.mcp_client import _try_parse_json, extract_payload
from src.models import Activity
from src.parsers import parse_activities, parse_coupons
from src.radar import build_radar, _match_highlights

CALENDAR_TEXT = calendar_text()


class ParseActivitiesTest(unittest.TestCase):
    def setUp(self) -> None:
        self.activities = parse_activities(CALENDAR_TEXT, today=date(2026, 10, 9))

    def test_counts_all_activities(self) -> None:
        self.assertEqual(len(self.activities), 17)

    def test_status_assignment(self) -> None:
        by_status: dict[str, int] = {}
        for activity in self.activities:
            by_status[activity.status] = by_status.get(activity.status, 0) + 1
        self.assertEqual(by_status.get("today"), 6)
        self.assertEqual(by_status.get("upcoming"), 8)
        self.assertEqual(by_status.get("past"), 3)

    def test_date_normalized(self) -> None:
        self.assertTrue(all(len(a.date) == 10 and a.date[4] == "-" for a in self.activities))

    def test_body_and_image_captured(self) -> None:
        with_image = [a for a in self.activities if a.image]
        self.assertEqual(len(with_image), len(self.activities))
        self.assertTrue(any("蓝莓" in a.body for a in self.activities))


class ParseActivitiesDailyTest(unittest.TestCase):
    """MCP 新版 ``campaign-calendar`` 返回结构化 JSON 时的解析。

    真实踩过的坑（2026-10-10）：麦当劳把该接口从 Markdown 文本换成了
    ``{"data": {"dailyList": [{"date", "dateText", "events": [{"articleDto": {...}}]}]}}``。
    老解析器只在 ``_LIST_KEYS``（data/list/items…）里找列表、在 ``_TITLE_KEYS``
    里找标题，于是 ``dailyList`` 和 ``articleDto.title`` 全落空 →
    **解析出 0 条活动**，页面上「活动全没了」。
    """

    PAYLOAD = {
        "success": True,
        "code": 200,
        "data": {
            "currentTime": "2026-10-10 12:31:18",
            "dailyList": [
                {
                    "date": "2026-10-09",
                    "dateText": "2026年10月9日 往期回顾",
                    "events": [
                        {
                            "activityCode": "a1",
                            "activityTitle": "",
                            "articleDto": {
                                "title": "昨天的活动",
                                "content": "第一行内容\n第二行内容",
                                "imgList": ["https://img/old.jpg"],
                            },
                        }
                    ],
                },
                {
                    "date": "2026-10-10",
                    "dateText": "2026年10月10日 今日",
                    "events": [
                        {
                            "activityCode": "a2",
                            "articleDto": {
                                "title": "今天的联名周边",
                                "content": "限时周边开售",
                                "imgList": ["https://img/new.jpg", "https://img/alt.jpg"],
                            },
                        },
                        {
                            "activityCode": "a3",
                            "articleDto": {
                                "title": "今天的新品",
                                "content": "韩式风味上新",
                                "imgList": [],
                            },
                        },
                    ],
                },
                {
                    "date": "2026-10-12",
                    "dateText": "2026年10月12日",
                    "events": [
                        {
                            "activityCode": "a4",
                            "articleDto": {
                                "title": "后天的活动",
                                "content": "预告",
                                "imgList": [],
                            },
                        }
                    ],
                },
            ],
        },
    }

    def setUp(self) -> None:
        self.acts = parse_activities(self.PAYLOAD, today=date(2026, 10, 10))

    def test_all_events_parsed(self) -> None:
        self.assertEqual(len(self.acts), 4)
        self.assertEqual(
            [a.title for a in self.acts],
            ["昨天的活动", "今天的联名周边", "今天的新品", "后天的活动"],
        )

    def test_status_from_date_text_and_date(self) -> None:
        by_title = {a.title: a for a in self.acts}
        self.assertEqual(by_title["昨天的活动"].status, "past")
        self.assertEqual(by_title["今天的联名周边"].status, "today")
        self.assertEqual(by_title["后天的活动"].status, "upcoming")

    def test_body_and_first_image_captured(self) -> None:
        by_title = {a.title: a for a in self.acts}
        self.assertIn("第二行内容", by_title["昨天的活动"].body)
        self.assertEqual(by_title["今天的联名周边"].image, "https://img/new.jpg")
        self.assertEqual(by_title["今天的新品"].image, "")

    def test_bare_daily_list_also_works(self) -> None:
        """dailyList 直接挂在顶层（或缺 events 外壳）时也要认。"""
        out = parse_activities({"dailyList": self.PAYLOAD["data"]["dailyList"]},
                               today=date(2026, 10, 10))
        self.assertEqual(len(out), 4)

    def test_blank_title_events_are_skipped(self) -> None:
        payload = {"data": {"dailyList": [
            {"date": "2026-10-10", "dateText": "2026年10月10日 今日",
             "events": [{"activityCode": "x", "articleDto": {"title": "", "content": "无标题"}}]},
        ]}}
        self.assertEqual(parse_activities(payload, today=date(2026, 10, 10)), [])


class ParseCouponsTest(unittest.TestCase):
    def setUp(self) -> None:
        self.coupons = parse_coupons(COUPONS_TEXT)

    def test_count(self) -> None:
        self.assertEqual(len(self.coupons), 5)

    def test_status_split(self) -> None:
        claimable = [c for c in self.coupons if "可领取" in c.status]
        owned = [c for c in self.coupons if "可领取" not in c.status]
        self.assertEqual(len(claimable), 3)
        self.assertEqual(len(owned), 2)

    def test_title_clean(self) -> None:
        self.assertIn("麦旋风任选", [c.title for c in self.coupons])
        self.assertFalse(any(c.title.endswith("\\") for c in self.coupons))


class RadarTest(unittest.TestCase):
    def setUp(self) -> None:
        today = date(2026, 10, 9)
        self.activities = parse_activities(CALENDAR_TEXT, today=today)
        self.coupons = parse_coupons(COUPONS_TEXT)
        self.items = build_radar(self.activities, self.coupons, today=today)

    def test_past_excluded(self) -> None:
        self.assertTrue(all(i.activity.status != "past" for i in self.items))

    def test_sorted_desc(self) -> None:
        scores = [i.score for i in self.items]
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_today_base_outranks_future(self) -> None:
        """同样的活动文案下，今日的基础分必须高于未来（40 vs 25）。"""
        items = build_radar(
            [
                Activity(date="2026-10-09", title="同款活动", body="同样的内容", status="today"),
                Activity(date="2026-10-16", title="同款活动", body="同样的内容", status="upcoming"),
            ],
            [],
            today=date(2026, 10, 9),
        )
        by_status = {item.activity.status: item.score for item in items}
        self.assertGreater(by_status["today"], by_status["upcoming"])

    def test_highlight_can_lift_future_activity(self) -> None:
        """亮点权重足够大 —— 限量周边类活动可以反超普通今日活动（有意设计）。"""
        items = build_radar(
            [
                Activity(date="2026-10-09", title="普通今日活动", body="无亮点", status="today"),
                Activity(
                    date="2026-10-15",
                    title="联名限量周边即将开售",
                    body="限量珍藏 加39.9元即可得",
                    status="upcoming",
                ),
            ],
            [],
            today=date(2026, 10, 9),
        )
        top = items[0]
        self.assertEqual(top.activity.status, "upcoming")
        self.assertIn("亮点", "".join(top.reasons))

    def test_coupon_match_reason(self) -> None:
        matched = [i for i in self.items if any("可用券" in r for r in i.reasons)]
        self.assertTrue(matched, "应至少有一条活动命中可用券")


class HighlightBoundaryTest(unittest.TestCase):
    def test_price_keyword_needs_boundary(self) -> None:
        self.assertTrue(_match_highlights("9.9元中杯冰美式"))
        self.assertFalse(_match_highlights("仅需29.9元"))

    def test_discount_boundary(self) -> None:
        self.assertTrue(_match_highlights("早餐卡6折优惠"))
        self.assertFalse(_match_highlights("满15折上折"))


class PayloadExtractionTest(unittest.TestCase):
    def test_plain_json(self) -> None:
        self.assertEqual(_try_parse_json('{"a": 1}'), {"a": 1})

    def test_wrapped_json(self) -> None:
        text = '说明文字\n## Original Response\n{"success": true, "code": 200}'
        self.assertEqual(_try_parse_json(text), {"success": True, "code": 200})

    def test_structured_preferred(self) -> None:
        class Result:
            is_error = False
            structured_content = {"data": [1, 2]}
            content: list = []

        self.assertEqual(extract_payload(Result()), {"data": [1, 2]})

    def test_plain_text_passthrough(self) -> None:
        class Result:
            is_error = False
            structured_content = None
            content = [type("T", (), {"text": "纯文本结果"})()]

        self.assertEqual(extract_payload(Result()), "纯文本结果")


if __name__ == "__main__":
    unittest.main()
