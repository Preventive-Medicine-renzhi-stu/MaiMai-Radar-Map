/* ==========================================================================
   CSS 覆盖体检（Node + jsdom）
   --------------------------------------------------------------------------
   把页面跑一遍（首页 / 登录弹窗 / 城市下拉 / 切换遮罩 / 点餐 / 结算 /
   下单成功 / 活动详情 / 用户下拉），收集真实用到的 class，和 styles.css 里
   定义过的 class 做差集。

   为什么需要它：纯静态、零构建的项目没有编译期检查，漏一个 class 只会
   在页面上表现为「这块没样式」，很难靠肉眼发现。

   运行：
     NODE_PATH=<managed>/node/workspace/node_modules node tests/css_coverage.js
   ========================================================================== */
'use strict';

const fs = require('fs');
const path = require('path');

let JSDOM;
try {
  ({ JSDOM } = require('jsdom'));
} catch (err) {
  console.error('缺少 jsdom，请先安装：npm install jsdom');
  process.exit(2);
}

const ROOT = path.resolve(__dirname, '..');
const WEB = path.join(ROOT, 'web');
const css = fs.readFileSync(path.join(WEB, 'styles.css'), 'utf8');

let problems = 0;

/* ---- 1. 花括号平衡 ---- */
let balance = 0;
for (const ch of css) {
  if (ch === '{') balance += 1;
  else if (ch === '}') balance -= 1;
}
console.log('CSS 花括号平衡：' + (balance === 0 ? 'OK' : '异常（余额 ' + balance + '）'));
if (balance !== 0) problems += 1;

/* ---- 2. 收集 CSS 里定义过的 class ---- */
const defined = new Set();
(css.match(/\.[A-Za-z_][A-Za-z0-9_-]*/g) || []).forEach((c) => defined.add(c.slice(1)));

/* ---- 3. 跑一遍页面，收集用到的 class ---- */
const html = fs.readFileSync(path.join(WEB, 'index.html'), 'utf8')
  .replace(/<script[\s\S]*?<\/script>/g, '');

const dom = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'http://localhost/' });
const w = dom.window;
w.scrollTo = function () {};

['data.js', 'core.js', 'api.js', 'auth.js', 'map.js', 'view-radar.js', 'view-order.js', 'app.js']
  .forEach((f) => w.eval(fs.readFileSync(path.join(WEB, f), 'utf8')));

const used = new Set();
function harvest() {
  w.document.querySelectorAll('*').forEach((el) => {
    (el.getAttribute('class') || '').split(/\s+/).forEach((c) => { if (c) used.add(c); });
  });
}
function click(sel) {
  const node = w.document.querySelector(sel);
  if (node) node.dispatchEvent(new w.Event('click', { bubbles: true }));
  return !!node;
}
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async function () {
  w.document.dispatchEvent(new w.Event('DOMContentLoaded'));
  await wait(20);
  harvest();

  // 登录弹窗（首屏已自动弹出）+ 微信面板
  w.MCD.auth.open();
  harvest();
  click('#login-mask [data-lg-tab="wechat"]');
  harvest();
  w.MCD.auth.signIn({ type: 'phone', account: '13800138000', at: '2026-10-09T12:00:00Z' });
  harvest();

  // 本地服务在线态 + 城市下拉 + 切换遮罩
  w.fetch = function () {
    return Promise.resolve({
      status: 200,
      ok: true,
      text: () => Promise.resolve(JSON.stringify({
        ok: true, live: true, city: '深圳', keyword: '腾讯滨海大厦', cities: []
      }))
    });
  };
  await w.MCD.api.probe();
  click('#city-trigger');
  harvest();
  w.MCD.api.switchCity = function () {
    return Promise.resolve({ ok: false, code: 'offline', message: '拉取失败', hint: '请在 .env 里填好 Token' });
  };
  click('#city-drop [data-city="北京"]');
  await wait(30);
  harvest();
  click('#city-switch-mask [data-sw-close]');
  harvest();

  // 各页面
  w.MCD.state.cart = { '1100': 1, '1440': 1 };
  ['/order', '/checkout', '/activity/0'].forEach((r) => { w.MCD.router.go(r); harvest(); });
  click('#cart-toggle');
  harvest();
  click('#switch-store');
  harvest();
  click('#modal-host #modal-close');
  harvest();
  w.MCD.state.cart = {};
  w.MCD.router.go('/order');
  harvest();

  // 用户下拉
  click('#user-trigger');
  harvest();

  /* ---- 4. 差集 ---- */
  const missing = [...used].filter((c) => !defined.has(c)).sort();
  console.log('页面用到但 CSS 未定义的 class：' +
    (missing.length ? missing.join(', ') : '（无）'));
  if (missing.length) problems += 1;

  /* ---- 5. CSS 变量是否有悬空引用 ---- */
  const declaredVars = new Set((css.match(/--[a-z0-9-]+(?=\s*:)/g) || []).map((s) => s.trim()));
  const usedVars = new Set((css.match(/var\((--[a-z0-9-]+)/g) || []).map((s) => s.replace('var(', '')));
  const dangling = [...usedVars].filter((v) => !declaredVars.has(v));
  console.log('引用但未定义的 CSS 变量：' + (dangling.length ? dangling.join(', ') : '（无）'));
  if (dangling.length) problems += 1;

  /* ---- 6. 层叠上下文防线（防回归） ----
     真实踩过的坑：腾讯地图 GL SDK 会在 #tmap 内部注入一个 z-index: 1000 的图层。
     .map-area 一旦不自建层叠上下文，这个 1000 就逃逸到根层叠上下文，
     压过登录弹窗，表现为「弹窗看得见、但所有按钮点不动」。
     完整验证见 tests/browser_hit_check.sh（需要真实浏览器），这里做快速静态兜底。 */
  function ruleBody(selector) {
    const i = css.indexOf(selector + ' {');
    if (i < 0) return '';
    const j = css.indexOf('}', i);
    return css.slice(i, j);
  }
  function zIndexOf(selector) {
    const m = ruleBody(selector).match(/z-index:\s*(\d+)/);
    return m ? parseInt(m[1], 10) : NaN;
  }

  const guards = [];
  if (!/isolation:\s*isolate/.test(ruleBody('.map-area'))) {
    guards.push('.map-area 缺少 isolation: isolate（地图 SDK 的 z-index:1000 会逃逸出来盖住弹窗）');
  }
  [['.login-mask', 9000], ['.switch-mask', 9000], ['#modal-host', 9000]]
    .forEach(([sel, floor]) => {
      const z = zIndexOf(sel);
      if (!(z >= floor)) guards.push(sel + ' 的 z-index 应为 >=' + floor + '，实际 ' + (isNaN(z) ? '未找到' : z));
    });
  console.log('层叠上下文防线：' + (guards.length ? '缺失 —— ' + guards.join('；') : 'OK（地图隔离 + 弹窗高层级）'));
  if (guards.length) problems += 1;

  /* ---- 7. 地图服务类库 API 名（防回归） ----
     真实踩过的坑：腾讯 GL JS「服务类库」的 Search 类**没有 search() 方法**，
     只有 searchRegion / searchNearby / searchRectangle / explore / here / searchPoiId。
     写成 svc.search(...) 会抛 "svc.search is not a function"，被 catch 静默吞掉，
     结果是「接口通了、门店坐标还是取不到」——异常静默最难查，所以静态卡一道。
     完整验证见 tests/browser_hit_check.sh（需要真实浏览器 + 在线 Key）。 */
  // 先剥掉注释再扫，否则注释里写的反例（比如“别写成 svc.search(...)”）会把体检自己带红。
  const mapJs = fs.readFileSync(path.join(WEB, 'map.js'), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|[^:])\/\/[^\n]*/g, '$1');
  const apiGuards = [];
  // 找出所有「Search 服务实例」的变量名，只对这些变量检查是否误用了 .search()
  // （Driving 服务**确实**有 search()，不能一刀切全禁 .search(）
  const searchVars = [...mapJs.matchAll(/(\w+)\s*=\s*new\s+TMap\.service\.Search\b/g)].map((m) => m[1]);
  searchVars.forEach((v) => {
    if (new RegExp('\\b' + v + '\\.search\\s*\\(').test(mapJs)) {
      apiGuards.push(v + '.search(...) —— GL JS 的 Search 类无此方法，应改用 ' + v + '.searchRegion()');
    }
  });
  if (!/searchRegion\s*\(/.test(mapJs) && !/searchNearby\s*\(/.test(mapJs)) {
    apiGuards.push('map.js 未调用 searchRegion() / searchNearby()，门店坐标可能取不到');
  }
  console.log('地图服务类库 API 名：' + (apiGuards.length ? '缺失 —— ' + apiGuards.join('；') : 'OK（使用 searchRegion）'));
  if (apiGuards.length) problems += 1;

  console.log('\n' + (problems ? problems + ' 项需要处理' : '体检通过'));
  process.exit(problems ? 1 : 0);
})();
