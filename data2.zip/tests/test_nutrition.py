"""营养数据匹配单元测试。

要锁住的核心设计约束：
  * 三档匹配必须**如实标注来源**（exact / alias / approx / computed），
    前端据此区分「官方原值」与「参考值」；
  * 套餐名**不能**被当成单品去近似匹配——否则「麦辣鸡腿汉堡三件套」
    会错误地取到单个汉堡的热量，这是比「查不到」更糟的误导；
  * 套餐优先按官方组成累加，任一组成项查不到就整体放弃，不给半截数字。
"""

from __future__ import annotations

import unittest

from src.catalog import (
    COMBO_MARKERS,
    NUTRITION_ALIASES,
    is_combo_name,
    lookup_nutrition,
    nutrition_from_composition,
    parse_nutrition,
    resolve_nutrition,
)

# 一张最小但结构真实的营养表（单位与 MCP list-nutrition-foods 对齐）
TABLE = {
    "巨无霸": {"kcal": 513, "protein": 27.0, "fat": 26.0, "carb": 42.0, "sodium": 961.0, "calcium": 171.0, "kj": 2146.0, "note": ""},
    "中薯条": {"kcal": 291, "protein": 3.4, "fat": 13.6, "carb": 38.4, "sodium": 249.0, "calcium": 23.0, "kj": 1217.0, "note": ""},
    "可乐中杯": {"kcal": 145, "protein": 0.0, "fat": 0.0, "carb": 36.3, "sodium": 12.0, "calcium": 4.0, "kj": 607.0, "note": ""},
    "麦乐鸡5块": {"kcal": 232, "protein": 13.0, "fat": 13.0, "carb": 15.0, "sodium": 470.0, "calcium": 20.0, "kj": 970.0, "note": ""},
    "麦辣鸡翅-2块": {"kcal": 240, "protein": 17.0, "fat": 16.0, "carb": 8.0, "sodium": 560.0, "calcium": 14.0, "kj": 1004.0, "note": ""},
}


class ParseNutritionTest(unittest.TestCase):
    def test_parses_text_table(self) -> None:
        text = (
            "[2]{productName,nutritionDescription,energyKj,energyKcal,protein,fat,carbohydrate,sodium,calcium}:\n"
            "巨无霸,null,2146,513,27,26,42,961,171\n"
            "中薯条,null,1217,291,3.4,13.6,38.4,249,23\n"
        )
        table = parse_nutrition({"data": text})
        self.assertEqual(set(table), {"巨无霸", "中薯条"})
        self.assertAlmostEqual(table["巨无霸"]["kcal"], 513.0)
        self.assertAlmostEqual(table["中薯条"]["fat"], 13.6)

    def test_parses_structured_rows(self) -> None:
        table = parse_nutrition([
            {"productName": "巨无霸", "energyKcal": "513", "protein": "27",
             "fat": "26", "carbohydrate": "42", "sodium": "961", "calcium": "171",
             "energyKj": "2146", "nutritionDescription": "null"},
        ])
        self.assertEqual(set(table), {"巨无霸"})
        self.assertEqual(table["巨无霸"]["note"], "")  # "null" 字符串归一为空

    def test_garbage_returns_empty(self) -> None:
        self.assertEqual(parse_nutrition(None), {})
        self.assertEqual(parse_nutrition({"data": 12345}), {})
        self.assertEqual(parse_nutrition({"data": "无关文本\n没有表头\n"}), {})


class LookupTest(unittest.TestCase):
    def test_exact_match(self) -> None:
        hit = lookup_nutrition("巨无霸", TABLE)
        self.assertEqual(hit["match"], "exact")
        self.assertAlmostEqual(hit["kcal"], 513.0)

    def test_alias_match_marks_source(self) -> None:
        hit = lookup_nutrition("薯条", TABLE)
        self.assertEqual(hit["match"], "alias")
        self.assertEqual(hit["source_name"], "中薯条")
        self.assertAlmostEqual(hit["kcal"], 291.0)

    def test_alias_table_covers_menu_shortnames(self) -> None:
        for menu_name, full_name in NUTRITION_ALIASES.items():
            with self.subTest(menu_name=menu_name):
                self.assertTrue(full_name.strip())
                self.assertNotEqual(menu_name, full_name)

    def test_approx_disabled_returns_none_for_unknown(self) -> None:
        self.assertIsNone(lookup_nutrition("麦辣鸡腿汉堡三件套", TABLE, allow_approx=False))

    def test_approx_enabled_can_match_unknown_shortname(self) -> None:
        # 「巨无霸」在表里，"巨无霸" 与 "巨无霸（大）」互相包含
        table = dict(TABLE)
        table["巨无霸（大）"] = TABLE["巨无霸"]
        hit = lookup_nutrition("巨无霸汉堡", table)
        self.assertIsNotNone(hit)
        self.assertIn(hit["match"], ("exact", "alias", "approx"))

    def test_empty_inputs(self) -> None:
        self.assertIsNone(lookup_nutrition("", TABLE))
        self.assertIsNone(lookup_nutrition("巨无霸", {}))


class ComboTest(unittest.TestCase):
    def test_combo_markers(self) -> None:
        for name in ("麦辣鸡腿汉堡三件套", "堡堡随心拼（7件任选）", "双人餐", "超值套餐"):
            with self.subTest(name=name):
                self.assertTrue(is_combo_name(name))

    def test_single_item_is_not_combo(self) -> None:
        for name in ("巨无霸", "中薯条", "麦乐鸡5块"):
            with self.subTest(name=name):
                self.assertFalse(is_combo_name(name))

    def test_markers_non_empty(self) -> None:
        self.assertTrue(COMBO_MARKERS)


class ResolveNutritionTest(unittest.TestCase):
    def test_single_item_uses_exact(self) -> None:
        hit = resolve_nutrition("1100", "巨无霸", TABLE)
        self.assertEqual(hit["match"], "exact")

    def test_combo_without_composition_returns_none(self) -> None:
        """套餐在营养表里没有条目、又没有真实组成时，必须返回 None，
        而不是退化成「按名字近似匹配单品」。"""
        self.assertIsNone(resolve_nutrition("9900005456", "麦辣鸡腿汉堡三件套", TABLE))

    def test_combo_computed_from_composition(self) -> None:
        composition = {
            "code": "9900005466",
            "rounds": [
                {"name": "主食", "quantity": 1, "choices": [{"name": "巨无霸", "is_default": 1, "quantity": 1}]},
                {"name": "小食", "quantity": 1, "choices": [{"name": "中薯条", "is_default": 1, "quantity": 1}]},
                {"name": "饮料", "quantity": 1, "choices": [{"name": "可乐中杯", "is_default": 1, "quantity": 1}]},
            ],
        }
        hit = resolve_nutrition("9900005466", "巨无霸三件套", TABLE, {"9900005466": composition})
        self.assertEqual(hit["match"], "computed")
        self.assertAlmostEqual(hit["kcal"], 513 + 291 + 145, places=1)
        self.assertEqual(hit["components"], ["巨无霸×1", "中薯条×1", "可乐中杯×1"])

    def test_computation_respects_quantity(self) -> None:
        composition = {
            "rounds": [
                {"name": "主食", "quantity": 1, "choices": [{"name": "巨无霸", "is_default": 1, "quantity": 2}]},
            ],
        }
        hit = nutrition_from_composition(composition, TABLE)
        self.assertAlmostEqual(hit["kcal"], 1026.0, places=1)
        self.assertEqual(hit["components"], ["巨无霸×2"])

    def test_gives_up_when_any_component_unknown(self) -> None:
        """任一组成项查不到就整体放弃——不给「只累加了一半」的误导数字。"""
        composition = {
            "rounds": [
                {"name": "主食", "quantity": 1, "choices": [{"name": "巨无霸", "is_default": 1, "quantity": 1}]},
                {"name": "神秘小食", "quantity": 1, "choices": [{"name": "不存在的小食", "is_default": 1, "quantity": 1}]},
            ],
        }
        self.assertIsNone(nutrition_from_composition(composition, TABLE))

    def test_gives_up_when_round_has_no_default(self) -> None:
        composition = {
            "rounds": [
                {"name": "主食", "quantity": 2, "choices": [{"name": "巨无霸", "is_default": 0, "quantity": 0}]},
            ],
        }
        self.assertIsNone(nutrition_from_composition(composition, TABLE))

    def test_falls_back_to_round_quantity_when_choice_quantity_missing(self) -> None:
        composition = {
            "rounds": [
                {"name": "主食", "quantity": 3, "choices": [{"name": "巨无霸", "is_default": 1}]},
            ],
        }
        hit = nutrition_from_composition(composition, TABLE)
        self.assertAlmostEqual(hit["kcal"], 513.0 * 3, places=1)

    def test_empty_rounds(self) -> None:
        self.assertIsNone(nutrition_from_composition({"rounds": []}, TABLE))


if __name__ == "__main__":
    unittest.main()
