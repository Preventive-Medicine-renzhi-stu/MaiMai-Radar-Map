/* ==========================================================================
   前端冒烟测试（Node + jsdom）
   在真实 DOM 环境里跑一遍整套前端脚本（data → core → api → auth → map → views → app），验证：
     [0]  首屏登录弹窗（手机号 / 微信、本地演示登录、退出）
     [1]  雷达首页三种模式与降级雷达图
     [1b] 顶栏用户信息下拉（积分 / 券 / 历史订单 / 账号）
     [1c] 一键点餐跟随 1.1 选中门店
     [1d] 城市下拉：快照 / 需导出 三态
     [1e] 本地服务探测：离线降级 + 在线可直切
     [1f] 切换城市：失败不伪装成功（错误卡 + 可关闭）
     [1i] 全国城市表：300+ 座、可搜索、支持自由输入
     [1j] 定位输入框：地点名 → 下拉 5 候选 → 点一条即定位并同步城市
     [1k] 切城市不携带上一座城市的定位关键词（自动填的丢掉 / 手打的照用）
     [2]  模式一「最常去」
     [3]  模式二「追新」
     [4]  模式三「极速」空购物车态
     [5]  模式三选品后重算
     [5b] 极速选品搜索框：中文组字期间不重建输入框
     [6]  未来 7 天日历
     [7]  一键点餐入口 → 点餐页
     [8]  点餐页结构 / 空购物车初始化
     [8b] 堂食 ↔ 打包
     [8c] 分类与搜索
     [8d] 临时换店（保留购物车 + 本店无售剔除）
     [9]  商品详情弹窗（营养 + 套餐组成）
     [10] 加购（事件委托防重复绑定回归）
     [11] 结算页（两栏布局 / 券 / 积分换购）
     [12] 提交订单 → 取餐号 / 状态时间轴 / 取消订单
     [13] 活动详情页
     [13e] 活动详情页 · 本地区可参与门店（距离 / 步行驾车 / 抵达时间）
     [13d] 活动索引越界时优雅退回雷达页

   运行：
     cd <项目根>
     NODE_PATH=<managed>/node/workspace/node_modules \
       node tests/web_smoke.js
   ========================================================================== */
'use strict';

const fs = require('fs');
const path = require('path');

let JSDOM;
try {
  ({ JSDOM } = require('jsdom'));
} catch (err) {
  console.error('缺少 jsdom，请先安装：npm install jsdom');
  process.exit(2);
}

const ROOT = path.resolve(__dirname, '..');
const WEB = path.join(ROOT, 'web');

let passed = 0;
let failed = 0;

function check(name, condition, detail) {
  if (condition) {
    passed += 1;
    console.log('  \u2713 ' + name);
  } else {
    failed += 1;
    console.log('  \u2717 ' + name + (detail ? ' \u2014 ' + detail : ''));
  }
}

function text(window, selector) {
  const node = window.document.querySelector(selector);
  return node ? node.innerHTML : '';
}

function section(title) {
  console.log('\n' + title);
}

/* ---- 构造一个不加载外部脚本的 DOM，然后手动注入全部脚本 ---- */
const rawHtml = fs.readFileSync(path.join(WEB, 'index.html'), 'utf8');
const html = rawHtml.replace(/<script[\s\S]*?<\/script>/g, '');

const dom = new JSDOM(html, {
  runScripts: 'outside-only',
  pretendToBeVisual: true,
  url: 'http://localhost/'
});
const { window } = dom;

// jsdom 未实现 scrollTo，路由切换时会调用它
window.scrollTo = function () {};

// 数据包用夹具，不用 web/data.js。
//
// web/data.js 是真实数据包，会被本地服务的 /api/city 重写；测试若直接读它，
// 结果就取决于「上次导出的是哪座城市」，换座城市断言就会莫名变红。
// 夹具是 `--demo` 快照，确定性。重新生成：python -m tests.make_fixture
const DATA_FIXTURE = path.join(ROOT, 'tests', 'fixtures', 'demo-data.js');
if (!fs.existsSync(DATA_FIXTURE)) {
  console.error('缺少 ' + DATA_FIXTURE + '，请先运行：python -m tests.make_fixture');
  process.exit(2);
}

[
  DATA_FIXTURE, 'core.js', 'api.js', 'auth.js',
  'map.js', 'view-radar.js', 'view-order.js', 'app.js'
].forEach(function (file) {
  window.eval(fs.readFileSync(path.isAbsolute(file) ? file : path.join(WEB, file), 'utf8'));
});

/** 等哈希路由的 hashchange 事件落地（jsdom 里是异步派发）。 */
function flush(ms) {
  return new Promise(function (resolve) { setTimeout(resolve, ms || 12); });
}

/** 派发一次冒泡点击。 */
function click(window, node) {
  node.dispatchEvent(new window.Event('click', { bubbles: true }));
}

function page(window) {
  return window.document.body.getAttribute('data-page');
}

function isVisible(window, selector) {
  const node = window.document.querySelector(selector);
  return !!node && node.hidden !== true;
}

function badge(window) {
  const node = window.document.querySelector('.cart-badge');
  return node ? Number(node.textContent.replace(/[^\d]/g, '') || 0) : -1;
}

async function run() {
  window.document.dispatchEvent(new window.Event('DOMContentLoaded'));
  await flush();

  /* ==================================================================== */
  section('[0] 首屏登录弹窗');
  const lgMask = window.document.querySelector('#login-mask');
  check('未登录时首屏自动弹出登录框', !!lgMask && lgMask.hidden === false);
  // 跳过只对「当次页面加载」生效，刷新会再弹 —— 所以不能落进 sessionStorage
  // （老版本写 sessionStorage，同一个标签页刷新永远不再弹，被误认为「弹窗不见了」）
  check('跳过状态没有落进 sessionStorage',
    window.sessionStorage.getItem('mcd.auth.skipped') === null,
    String(window.sessionStorage.getItem('mcd.auth.skipped')));
  check('提供手机号 / 微信两个 tab',
    !!lgMask.querySelector('[data-lg-tab="phone"]') &&
    !!lgMask.querySelector('[data-lg-tab="wechat"]'));
  check('明确标注为本地演示登录', lgMask.textContent.indexOf('本地演示登录') >= 0);
  check('顶栏用户区显示「未登录」',
    window.document.querySelector('#user-name').textContent === '未登录',
    window.document.querySelector('#user-name').textContent);
  check('未登录时顶栏显示 MCP 账户可用积分',
    window.document.querySelector('#user-sub').textContent
      .indexOf(String(window.MCD_DATA.account.available_points)) >= 0,
    window.document.querySelector('#user-sub').textContent);

  const phoneInput = lgMask.querySelector('#lg-phone');
  phoneInput.value = '123';
  click(window, lgMask.querySelector('#lg-submit'));
  check('手机号非法时拒绝登录', !window.MCD.auth.signedIn());
  check('给出手机号错误提示', lgMask.querySelector('#lg-msg').hidden === false);

  phoneInput.value = '13800138000';
  click(window, lgMask.querySelector('#lg-send'));
  check('「获取验证码」进入倒计时', lgMask.querySelector('#lg-send').disabled === true);
  check('提示这是演示环境（不真发短信）',
    lgMask.querySelector('#lg-msg').textContent.indexOf('演示') >= 0);

  lgMask.querySelector('#lg-code').value = '12';
  click(window, lgMask.querySelector('#lg-submit'));
  check('验证码位数不足时拒绝登录', !window.MCD.auth.signedIn());

  lgMask.querySelector('#lg-code').value = '123456';
  click(window, lgMask.querySelector('#lg-submit'));
  check('手机号 + 验证码登录成功', window.MCD.auth.signedIn());
  check('登录方式记为手机号', window.MCD.auth.current().type === 'phone');
  check('登录后弹窗自动关闭', window.document.querySelector('#login-mask').hidden === true);
  check('登录态写进 localStorage', !!window.localStorage.getItem('mcd.auth.v1'));
  check('手机号已脱敏', window.MCD.auth.label() === '138****8000', window.MCD.auth.label());
  check('顶栏显示登录身份',
    window.document.querySelector('#user-name').textContent === '手机用户',
    window.document.querySelector('#user-name').textContent);

  section('[0b] 用户下拉的「账号」区块与退出登录');
  click(window, window.document.querySelector('#user-trigger'));
  const acctDrop = text(window, '#user-drop');
  check('下拉里有「账号」区块', acctDrop.indexOf('账号') >= 0);
  check('下拉里有退出登录按钮', acctDrop.indexOf('data-logout') >= 0);
  check('下拉说明这是本地演示登录', acctDrop.indexOf('本地演示登录') >= 0);

  click(window, window.document.querySelector('#user-drop [data-logout]'));
  check('退出后回到未登录', !window.MCD.auth.signedIn());
  check('退出后登录态已清除', !window.localStorage.getItem('mcd.auth.v1'));
  check('退出后重新弹出登录框', window.document.querySelector('#login-mask').hidden === false);

  section('[0c] 微信快捷登录');
  click(window, window.document.querySelector('#login-mask [data-lg-tab="wechat"]'));
  const wxPanel = window.document.querySelector('#login-mask #lg-wechat');
  check('切到微信面板', !!wxPanel);
  check('微信面板含二维码图案',
    window.document.querySelector('#login-mask .lg-qr svg') !== null);
  check('写明未接入微信开放平台',
    window.document.querySelector('#login-mask .lg-wechat').textContent
      .indexOf('未接入微信开放平台') >= 0);
  click(window, wxPanel);
  check('微信登录成功',
    window.MCD.auth.signedIn() && window.MCD.auth.current().type === 'wechat');
  check('顶栏切换为微信身份',
    window.document.querySelector('#user-name').textContent === '微信用户');
  check('微信登录后弹窗关闭', window.document.querySelector('#login-mask').hidden === true);

  /* ==================================================================== */
  section('[1] 雷达首页 · 默认模式一（就近）');
  const data = window.MCD_DATA;
  check('数据包已加载', !!data);
  check('路由落在 radar 页', page(window) === 'radar', '实际 ' + page(window));
  check('购物车初始为空（不预选任何餐食）',
    Object.keys(window.MCD.state.cart).length === 0,
    JSON.stringify(window.MCD.state.cart));
  check('左侧置顶「一键点餐」区块', text(window, '#left-body').indexOf('quick-order') >= 0);
  check('置顶区块给出最近门店', text(window, '#left-body').indexOf('用这家店点餐') >= 0);
  check('左侧列出 5 家门店', (text(window, '#left-body').match(/store-card/g) || []).length >= 5);
  check('门店名正确渲染', text(window, '#left-body').indexOf('赛西科技大厦') >= 0);
  check('右侧显示门店详情', text(window, '#right-body').indexOf('门店编号') >= 0);
  check('降级雷达图已绘制（无 TMap 环境）', text(window, '#radar-svg').indexOf('<circle') >= 0);
  check('雷达图含推荐标记', text(window, '#radar-svg').indexOf('推荐') >= 0);
  check('悬浮「一键点餐」按钮存在', !!window.document.querySelector('#fab-order'));

  /* ==================================================================== */
  section('[1b] 顶栏用户信息下拉');
  const acc = data.account;
  const trigger = window.document.querySelector('#user-trigger');
  check('存在用户信息入口', !!trigger);
  check('入口显示当前登录身份',
    window.document.querySelector('#user-sub').textContent === window.MCD.auth.label(),
    window.document.querySelector('#user-sub').textContent);

  const drop = window.document.querySelector('#user-drop');
  check('下拉面板已构建', !!drop);
  const dropHtml = text(window, '#user-drop');
  check('含积分账户区块', dropHtml.indexOf('积分账户') >= 0);
  check('标注积分来源 query-my-account', dropHtml.indexOf('query-my-account') >= 0);
  check('展示累计积分', dropHtml.indexOf(String(acc.accumulated_points)) >= 0);
  check('展示已过期积分', dropHtml.indexOf(String(acc.expired_points)) >= 0);
  check('账户 ID 已脱敏（不含完整账号）',
    acc.account_id ? dropHtml.indexOf(acc.account_id) < 0 : true);
  check('含我的优惠券区块', dropHtml.indexOf('我的优惠券') >= 0);
  check('含历史订单区块', dropHtml.indexOf('历史订单') >= 0);
  check('历史订单含真实门店与实付',
    dropHtml.indexOf('马鞍山湖东路') >= 0 && dropHtml.indexOf('73') >= 0);
  check('含口味偏好（从历史订单推导）', dropHtml.indexOf('口味偏好') >= 0 && dropHtml.indexOf('巨无霸') >= 0);
  check('明确说明 MCP 未提供昵称 / 手机号', dropHtml.indexOf('没有昵称、手机号、头像') >= 0);

  click(window, trigger);
  check('点击后菜单展开', window.document.querySelector('#user-menu').classList.contains('is-open'));
  click(window, trigger);
  check('再次点击收起', !window.document.querySelector('#user-menu').classList.contains('is-open'));

  /* ==================================================================== */
  section('[1c] 一键点餐必须跟随 1.1 选中的门店');
  const rows = window.MCD.data.nearbyRows();
  const fabStore = function () {
    const n = window.document.querySelector('#fab-store');
    return n ? n.textContent.trim() : '';
  };
  const shortName = function (n) { return n.replace(/^麦当劳/, '').replace(/餐厅$/, ''); };

  // 未手动选门店时：用 1.1 当前排序的第一家
  check('默认落到 1.1 推荐门店', window.MCD.orderStoreCode() === rows[0].store_code,
    window.MCD.orderStoreCode() + ' vs ' + rows[0].store_code);
  check('悬浮球写明将要下单的门店', fabStore() === shortName(rows[0].name), fabStore());
  check('置顶区块标注为「推荐」来源',
    text(window, '#left-body').indexOf('qo-src is-auto') >= 0);

  // 手动点选第 3 家门店 → 一键点餐必须跟着换
  const thirdCard = window.document.querySelectorAll('#left-body .store-card[data-store]')[2];
  const thirdCode = thirdCard.getAttribute('data-store');
  click(window, thirdCard);
  check('点选门店生效', window.MCD.state.selectedStore === thirdCode, thirdCode);
  check('orderStoreCode 跟随选中门店', window.MCD.orderStoreCode() === thirdCode,
    window.MCD.orderStoreCode());
  check('置顶区块切到选中门店',
    text(window, '#left-body').indexOf(thirdCode) >= 0 &&
    text(window, '#left-body').indexOf('已选门店') >= 0);
  check('悬浮球同步到选中门店', fabStore() === shortName(rows[2].name), fabStore());

  // 切到 1.2 / 1.3 再回来，一键点餐不能悄悄漂到别的店
  click(window, window.document.querySelector('.mode-tab[data-mode="newest"]'));
  click(window, window.document.querySelector('.mode-tab[data-mode="nearby"]'));
  check('切模式后仍回到 1.1 的默认门店（选中已清空）',
    window.MCD.orderStoreCode() === rows[0].store_code, window.MCD.orderStoreCode());

  /* ==================================================================== */
  section('[1d] 城市下拉：自定义控件 + 真实的换城市反馈');
  const cityTrigger = window.document.querySelector('#city-trigger');
  check('存在自定义城市控件（原生 select 已移除）',
    !!cityTrigger && !window.document.querySelector('#city-input'));
  check('当前城市显示为快照城市',
    window.document.querySelector('#city-current').textContent.trim() === data.city,
    window.document.querySelector('#city-current').textContent);
  const cityOpts = window.document.querySelectorAll('#city-drop [data-city]');
  check('下拉列出多个城市', cityOpts.length >= 8, cityOpts.length + ' 个');
  const snapOpt = window.document.querySelector('#city-drop [data-city="' + data.city + '"]');
  check('快照城市有标识', !!snapOpt && text(window, '#city-drop').indexOf('快照') >= 0);
  check('非快照城市标注「需先导出」', text(window, '#city-drop').indexOf('需先导出') >= 0);
  check('默认关闭', window.document.querySelector('#city-drop').hidden === true);

  click(window, cityTrigger);
  check('点击后展开', window.document.querySelector('#city-drop').hidden === false);
  check('aria-expanded 同步', cityTrigger.getAttribute('aria-expanded') === 'true');

  // 选一个没有快照数据的城市。
  // 注意：快照城市会随上一次导出变化（切过城市就不是深圳了），
  // 所以这里必须动态挑，不能把城市名写死，否则切过城市后测试必挂。
  const otherCity = Array.prototype.map
    .call(window.document.querySelectorAll('#city-drop [data-city]'), function (b) {
      return b.getAttribute('data-city');
    })
    .filter(function (c) { return c !== data.city; })[0];
  const otherOpt = window.document.querySelector('#city-drop [data-city="' + otherCity + '"]');
  check('下拉里有非快照城市可选', !!otherOpt, otherCity);
  click(window, otherOpt);
  check('选完自动收起', window.document.querySelector('#city-drop').hidden === true);
  check('城市已切换', window.document.querySelector('#city-current').textContent.trim() === otherCity,
    window.document.querySelector('#city-current').textContent);

  const statusHtml = text(window, '#locator-status');
  check('状态条变为警示态',
    window.document.querySelector('#locator-status').classList.contains('is-warn'));
  check('状态条给出重新导出命令',
    statusHtml.indexOf('--city ' + otherCity) >= 0 && statusHtml.indexOf('复制命令') >= 0);
  check('左侧换成说明卡（不拿别城门店充数）',
    text(window, '#left-body').indexOf('city-mismatch') >= 0 &&
    text(window, '#left-body').indexOf('暂无快照数据') >= 0);
  check('右侧解释城市覆盖情况', text(window, '#right-body').indexOf('query-nearby-stores') >= 0);
  check('雷达图已清空（不留别城标记）',
    text(window, '#radar-svg').indexOf('暂无已导出数据') >= 0);

  click(window, window.document.querySelector('#right-body [data-city-reset]'));
  check('切回快照城市', window.document.querySelector('#city-current').textContent.trim() === data.city);
  check('状态条恢复为正常态',
    !window.document.querySelector('#locator-status').classList.contains('is-warn'));
  check('门店列表恢复', text(window, '#left-body').indexOf('用这家店点餐') >= 0);
  check('雷达图恢复绘制', text(window, '#radar-svg').indexOf('<circle') >= 0);

  /* ==================================================================== */
  section('[1e] 本地服务探测 · 没有服务时如实降级');
  const apiState = window.MCD.api.state;
  check('jsdom 里没有 fetch，探测结论为「离线」',
    apiState.probed === true && apiState.online === false,
    'probed=' + apiState.probed + ' online=' + apiState.online);
  check('城市下拉如实标注「需先导出」', text(window, '#city-drop').indexOf('需先导出') >= 0);
  check('状态条说明当前是纯静态模式', text(window, '#locator-status').indexOf('纯静态模式') >= 0);
  check('离线时不会出现「点一下切换」', text(window, '#city-drop').indexOf('点一下切换') < 0);

  section('[1f] 本地服务在线 → 城市可以「点一下就切」');
  const realFetch = window.fetch;
  let lastRequest = null;
  window.fetch = function (url, opts) {
    lastRequest = { url: url, opts: opts || {} };
    return Promise.resolve({
      status: 200,
      ok: true,
      text: function () {
        return Promise.resolve(JSON.stringify({
          ok: true, live: true, mode: 'live',
          city: data.city, keyword: '腾讯滨海大厦', store_count: 5, cities: []
        }));
      }
    });
  };
  await window.MCD.api.probe();
  check('探测到本地服务在线', window.MCD.api.state.online === true);
  check('服务声明具备实时切城市能力', window.MCD.api.live() === true);
  check('探测打的是 /api/status',
    !!lastRequest && lastRequest.url === '/api/status', lastRequest && lastRequest.url);
  check('城市角标变为「点一下切换」', text(window, '#city-drop').indexOf('点一下切换') >= 0);
  check('状态条提示本地服务已连接',
    text(window, '#locator-status').indexOf('本地服务已连接') >= 0);

  section('[1g] 切换失败时不伪装成功');
  // 同样不写死城市名：快照城市会随上一次导出变化，写死会在切过城市后失效。
  const failCity = Array.prototype.map
    .call(window.document.querySelectorAll('#city-drop [data-city]'), function (b) {
      return b.getAttribute('data-city');
    })
    .filter(function (c) { return c !== data.city; })[0];
  window.MCD.api.switchCity = function (city, keyword) {
    check('切城市带了城市与地标关键词', city === failCity && !!keyword, city + ' / ' + keyword);
    return Promise.resolve({
      ok: false,
      code: 'offline',
      message: '本地服务当前是离线快照模式，无法实时拉取「' + failCity + '」的数据。',
      hint: '请在 .env 里填好 MCD_MCP_TOKEN，然后重新双击启动脚本。'
    });
  };
  const cityBeforeFail = window.document.querySelector('#city-current').textContent.trim();
  click(window, window.document.querySelector('#city-trigger'));
  click(window, window.document.querySelector('#city-drop [data-city="' + failCity + '"]'));
  await flush(30);

  const swMask = window.document.querySelector('#city-switch-mask');
  check('出现切换遮罩', !!swMask && swMask.hidden === false);
  check('失败时显示错误卡', !!swMask && swMask.textContent.indexOf('没能切换到') >= 0);
  check('错误卡给出补救办法', !!swMask && swMask.textContent.indexOf('.env') >= 0);
  check('失败后城市没有被偷偷改掉',
    window.document.querySelector('#city-current').textContent.trim() === cityBeforeFail,
    window.document.querySelector('#city-current').textContent);
  click(window, swMask.querySelector('[data-sw-close]'));
  check('错误卡可以关掉', swMask.hidden === true);

  section('[1h] 本地服务在线但缺 Token → 下拉里能直接补填');
  window.fetch = function () {
    return Promise.resolve({
      status: 200,
      ok: true,
      text: function () {
        return Promise.resolve(JSON.stringify({
          ok: true, live: false, mode: 'demo',
          live_reason: '未在 .env 中配置 MCD_MCP_TOKEN',
          city: data.city, cities: []
        }));
      }
    });
  };
  await window.MCD.api.probe();
  check('缺少 Token 时不再声称可直切', window.MCD.api.live() === false);

  click(window, window.document.querySelector('#city-trigger'));
  check('角标回落到「需先导出」', text(window, '#city-drop').indexOf('需先导出') >= 0);
  check('状态条点明缺的是 MCD_MCP_TOKEN',
    text(window, '#locator-status').indexOf('MCD_MCP_TOKEN') >= 0);

  const tokenInput = window.document.querySelector('#token-input');
  check('下拉里出现 Token 输入框', !!tokenInput);
  check('说明 Token 只会写进 .env', text(window, '#city-drop').indexOf('.env') >= 0);

  tokenInput.value = 'abc';
  click(window, window.document.querySelector('#token-save'));
  check('过短的 Token 被前端拦下',
    window.document.querySelector('#token-msg').textContent.indexOf('不完整') >= 0);

  /* ==================================================================== */
  section('[1i] 全国城市表：300+ 座、可搜索、支持自由输入');
  const dropEl = window.document.querySelector('#city-drop');
  if (dropEl.hidden) click(window, window.document.querySelector('#city-trigger'));

  const allCityBtns = window.document.querySelectorAll('#city-drop [data-city]');
  check('下拉里列出全国城市（>= 300 座）', allCityBtns.length >= 300, allCityBtns.length + ' 座');
  check('提供城市搜索框', !!window.document.querySelector('#city-search'));
  check('下拉按省份分组',
    window.document.querySelectorAll('#city-drop .city-sec').length >= 25,
    window.document.querySelectorAll('#city-drop .city-sec').length + ' 组');
  check('下拉里不再逐条堆「点一下切换」角标',
    window.document.querySelectorAll('#city-drop .co-flag.is-live').length <= 1);

  const withCoord = (window.MCD_DATA.cities || []).filter(function (c) { return c.lat && c.lng; });
  check('城市表带经纬度（地图不依赖腾讯接口也能定位到城市）',
    withCoord.length >= 300, withCoord.length + ' 座');

  const citySearch = window.document.querySelector('#city-search');
  const typeCity = function (text) {
    citySearch.value = text;
    citySearch.dispatchEvent(new window.Event('input', { bubbles: true }));
  };
  const matches = function () {
    return Array.prototype.map.call(
      window.document.querySelectorAll('#city-scroll [data-city]'),
      function (b) { return b.getAttribute('data-city'); }
    );
  };

  typeCity('拉萨');
  check('搜索「拉萨」只剩命中项', matches().length === 1 && matches()[0] === '拉萨', matches().join(','));

  typeCity('广东');
  check('可以按省份搜索', matches().indexOf('深圳') >= 0, matches().slice(0, 4).join(','));

  typeCity('人民广场');
  check('可以按地标搜索', matches().indexOf('上海') >= 0, matches().slice(0, 4).join(','));

  typeCity('不存在的城市XYZ');
  check('搜不到时给出「直接查」入口',
    window.document.querySelector('#city-scroll [data-city="不存在的城市XYZ"]') !== null);

  // 中文输入法组字期间不能重建输入框（和点餐页搜索框同一个坑）
  const searchNodeBefore = window.document.querySelector('#city-search');
  citySearch.dispatchEvent(new window.Event('compositionstart', { bubbles: true }));
  citySearch.value = '呼和';
  citySearch.dispatchEvent(new window.Event('input', { bubbles: true }));
  check('组字期间不重建搜索框（IME 回归）',
    window.document.querySelector('#city-search') === searchNodeBefore);
  citySearch.dispatchEvent(new window.Event('compositionend', { bubbles: true }));
  check('组字结束后正常过滤',
    window.document.querySelector('#city-scroll [data-city="呼和浩特"]') !== null);

  typeCity('');
  check('清空搜索后恢复分组视图',
    window.document.querySelectorAll('#city-drop .city-sec').length >= 25);

  click(window, window.document.querySelector('#city-trigger'));

  /* ==================================================================== */
  section('[1j] 定位输入框 · 输入地点名 → 下拉 5 个候选 → 点一条即定位');
  const locInput = window.document.querySelector('#keyword-input');
  const locBox = window.document.querySelector('#loc-suggest');
  check('输入框下挂好了候选容器', !!locBox);
  check('输入框语义正确（aria-autocomplete=list）',
    locInput.getAttribute('aria-autocomplete') === 'list'
    && locInput.getAttribute('aria-controls') === 'loc-suggest');
  check('关掉浏览器自动填充（否则会盖住候选）',
    locInput.getAttribute('autocomplete') === 'off');
  check('对外暴露定位能力，测试可离线驱动',
    !!(window.MCD.locate && window.MCD.locate.pick && window.MCD.locate.render));

  const suggestItems = [
    { title: '人民广场[地铁站]', address: '上海市黄浦区南京西路', city: '上海市', district: '黄浦区', lat: 31.232572, lng: 121.475242 },
    { title: '人民广场(公交站)', address: '上海市黄浦区西藏中路', city: '上海市', district: '黄浦区', lat: 31.233100, lng: 121.474000 },
    { title: '人民广场·音乐喷泉', address: '上海市黄浦区人民大道', city: '上海市', district: '黄浦区', lat: 31.231000, lng: 121.476000 },
    { title: '人民公园', address: '上海市黄浦区南京西路231号', city: '上海市', district: '黄浦区', lat: 31.233900, lng: 121.472900 },
    { title: '人民广场地下停车场', address: '上海市黄浦区人民大道300号', city: '上海市', district: '黄浦区', lat: 31.230800, lng: 121.475600 }
  ];

  window.MCD.locate.render(suggestItems, '');
  check('下拉渲染出 5 条候选',
    locBox.querySelectorAll('.loc-item').length === 5,
    locBox.querySelectorAll('.loc-item').length + ' 条');
  check('下拉已展开', window.MCD.locate.open() === true && locBox.hidden === false);
  check('第一条默认高亮（回车即选）',
    locBox.querySelectorAll('.loc-item')[0].classList.contains('is-active')
    && locBox.querySelectorAll('.loc-item')[0].getAttribute('aria-selected') === 'true');
  check('候选带 POI 名与详细地址',
    locBox.textContent.indexOf('人民广场[地铁站]') >= 0
    && locBox.textContent.indexOf('南京西路') >= 0);
  check('候选标注所属城市 / 区', locBox.textContent.indexOf('上海') >= 0
    && locBox.textContent.indexOf('黄浦区') >= 0);
  check('每条候选都自带坐标（选中即可落点，不用再检索一次）',
    window.MCD.locate.items().every(function (i) { return i.lat && i.lng; }));
  check('底部如实标注数据来源为腾讯位置服务',
    locBox.textContent.indexOf('腾讯位置服务') >= 0);

  locInput.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
  check('方向键↓下移高亮',
    locBox.querySelectorAll('.loc-item')[1].classList.contains('is-active'));
  locInput.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'ArrowUp', bubbles: true }));
  check('方向键↑回退高亮',
    locBox.querySelectorAll('.loc-item')[0].classList.contains('is-active'));
  locInput.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  check('Esc 收起下拉', window.MCD.locate.open() === false && locBox.hidden === true);

  // 搜索链路：把 api.suggest 换成假的，验证「带什么参数去查 / 结果怎么画 / 查不到怎么说」
  const realSuggest = window.MCD.api.suggest;
  let suggestCall = null;
  window.MCD.api.suggest = function (kw, region, limit) {
    suggestCall = { kw: kw, region: region, limit: limit };
    return Promise.resolve({ ok: true, items: suggestItems });
  };
  locInput.value = '人民广场';
  window.MCD.locate.search('人民广场');
  await flush(60);
  check('检索带上了关键词',
    !!suggestCall && suggestCall.kw === '人民广场', suggestCall && suggestCall.kw);
  check('检索带上了当前地区作为 region 提示',
    !!suggestCall && suggestCall.region === (window.MCD.state.city || data.city),
    suggestCall && suggestCall.region);
  check('限定只取 5 条候选', !!suggestCall && suggestCall.limit === 5, suggestCall && suggestCall.limit);
  check('检索结果就地渲染成下拉',
    locBox.querySelectorAll('.loc-item').length === 5 && window.MCD.locate.open() === true);

  window.MCD.api.suggest = function () {
    return Promise.resolve({ ok: false, items: [], message: '没搜到这个地点，换个说法试试。' });
  };
  locInput.value = '不存在的地方XYZ';
  window.MCD.locate.search('不存在的地方XYZ');
  await flush(60);
  check('搜不到时如实说明，不假装搜到',
    locBox.textContent.indexOf('没搜到') >= 0
    && locBox.querySelectorAll('.loc-item').length === 0);

  window.MCD.api.suggest = realSuggest;

  window.MCD.locate.search('');
  check('空关键词收起下拉', window.MCD.locate.open() === false);

  // 点一条候选：回填输入框 + 城市跟着换 + 定位到位
  window.MCD.locate.render(suggestItems, '');
  const picked = window.MCD.locate.pick(window.MCD.locate.items()[0]);
  check('选中后下拉立刻收起', window.MCD.locate.open() === false && locBox.hidden === true);
  await picked;
  await flush(30);
  check('输入框回填所选地点', locInput.value === '人民广场[地铁站]', locInput.value);
  check('城市跟随候选切到「上海」',
    window.document.querySelector('#city-current').textContent.trim() === '上海',
    window.document.querySelector('#city-current').textContent);
  check('关键词用 POI 名（比城市名定位准）',
    window.MCD.state.keyword === '人民广场[地铁站]', window.MCD.state.keyword);
  check('定位完成信号可被等待（lastPick 已 resolve）',
    typeof window.MCD.locate.lastPick === 'function');

  // 复原，避免污染后续 section 的城市快照
  const resetBtn = window.document.querySelector('[data-city-reset]');
  if (resetBtn) click(window, resetBtn);
  await flush(30);
  check('可一键切回快照城市',
    window.document.querySelector('#city-current').textContent.trim() === data.city,
    window.document.querySelector('#city-current').textContent);

  /* -------------------------------------------------------------------- */
  section('[1k] 切城市不携带上一座城市的定位关键词（线上 bug 防回归）');
  //  血案：在深圳选了「深圳湾公园[地铁站]」，再从城市下拉切北京 —— 这串字被当成
  //  检索关键词发给北京，麦当劳 MCP 在北京查不到 → 返回 0 家门店 → 整座北京被
  //  误判成「没有门店」，弹「没能切换到北京」。
  //  规则：**候选自动填**的地名跨城市必须丢掉（它不是用户的意思）；
  //        用户**手打**的则照用（那是明确意图，例如填「海拉尔」再切呼伦贝尔）。
  const keepSuggest = window.MCD.api.suggest;
  const keepSwitch = window.MCD.api.switchCity;
  const keepOnline = window.MCD.api.state.online;
  const keepLive = window.MCD.api.state.live;
  window.MCD.api.suggest = function () { return Promise.resolve({ ok: true, items: [] }); };

  // ① 先在「纯静态」状态下点一条候选：这会把地名自动填进输入框，
  //    同时 applyCity() 会重渲染两侧面板（含段尾要用的「切回快照城市」按钮）。
  window.MCD.locate.render(suggestItems, '');
  await window.MCD.locate.pick(window.MCD.locate.items()[0]);
  await flush(30);
  check('前置：输入框里现在是候选自动填的地名',
    locInput.value === '人民广场[地铁站]', locInput.value);

  // ② 再把「城市可一键切换」打开，模拟真实在线环境。
  //    直接改标志位而不重新 probe，免得把 fetch 桩搅乱；段尾原样还原。
  window.MCD.api.state.online = true;
  window.MCD.api.state.live = true;
  check('前置：本地服务在线，城市可以「点一下就切」', window.MCD.api.live() === true);

  let swCall = null;
  window.MCD.api.switchCity = function (city, keyword) {
    swCall = { city: city, keyword: keyword };
    return Promise.resolve({ ok: false, code: 'offline', message: '测试桩：不真的切', hint: '' });
  };
  const dismissMask = function () {
    const mk = window.document.querySelector('#city-switch-mask');
    if (mk && mk.hidden === false && mk.querySelector('[data-sw-close]')) {
      click(window, mk.querySelector('[data-sw-close]'));
    }
  };
  const clickCity = function (city) {
    if (window.document.querySelector('#city-drop').hidden) {
      click(window, window.document.querySelector('#city-trigger'));
    }
    swCall = null;
    click(window, window.document.querySelector('#city-drop [data-city="' + city + '"]'));
  };

  // ③ 候选自动填的地名 → 切城市时必须丢掉
  clickCity(otherCity);
  await flush(30);
  check('切城市不再带上自动填的地名（否则目标城市会被误判成没有门店）',
    !!swCall && swCall.keyword === '', swCall && JSON.stringify(swCall));
  check('同时把输入框清空，界面与数据保持一致',
    locInput.value === '', locInput.value);
  dismissMask();

  // ④ 用户手打的关键词 → 照用，不替他改主意
  locInput.value = '海拉尔';
  locInput.dispatchEvent(new window.Event('input', { bubbles: true }));
  clickCity(otherCity);
  await flush(30);
  check('用户手打的关键词照用（例如填「海拉尔」再切呼伦贝尔）',
    !!swCall && swCall.keyword === '海拉尔', swCall && JSON.stringify(swCall));
  dismissMask();

  // 段尾复位：先把能力标志还原，再点「切回快照城市」——
  // 否则后面 [2]/[3]/[4] 会拿一个没有快照的城市去渲染，整片变红。
  locInput.value = '';
  window.MCD.api.suggest = keepSuggest;
  window.MCD.api.switchCity = keepSwitch;
  window.MCD.api.state.online = keepOnline;
  window.MCD.api.state.live = keepLive;

  const resetBtn1k = window.document.querySelector('[data-city-reset]');
  check('段尾能拿到「切回快照城市」按钮', !!resetBtn1k);
  if (resetBtn1k) click(window, resetBtn1k);
  await flush(30);
  check('段尾切回快照城市，不污染后续用例',
    window.document.querySelector('#city-current').textContent.trim() === data.city,
    window.document.querySelector('#city-current').textContent);
  locInput.value = '';
  window.MCD.api.suggest = keepSuggest;

  window.fetch = realFetch;

  /* ==================================================================== */
  section('[2] 模式一 · 切换到「最常去」');
  const segBtn = window.document.querySelector('#nearby-seg button[data-sort="frequent"]');
  check('排序切换按钮存在', !!segBtn);
  if (segBtn) {
    click(window, segBtn);
    const body = text(window, '#left-body');
    check('提示无附近订单记录', body.indexOf('还没有历史订单') >= 0);
    check('展示真实历史门店', body.indexOf('马鞍山湖东路') >= 0);
  }

  /* ==================================================================== */
  section('[3] 模式二 · 追新 / 粉丝');
  click(window, window.document.querySelector('.mode-tab[data-mode="newest"]'));
  const newLeft = text(window, '#left-body');
  const newRight = text(window, '#right-body');
  check('左侧渲染活动卡', (newLeft.match(/act-card/g) || []).length >= 3);
  check('含限时周边筛选按钮', newLeft.indexOf('限时周边') >= 0);
  check('右侧含「限时周边发售」', newRight.indexOf('限时周边发售') >= 0);
  check('右侧含「哪些店有售」', newRight.indexOf('哪些店有售') >= 0);
  check('关联到具体门店', newRight.indexOf('家店在售') >= 0);
  check('活动卡可点击进入详情', newLeft.indexOf('data-activity=') >= 0);

  /* ==================================================================== */
  section('[4] 模式三 · 极速（购物车为空）');
  click(window, window.document.querySelector('.mode-tab[data-mode="speed"]'));
  const spLeft = text(window, '#left-body');
  const spRight = text(window, '#right-body');
  check('左侧为选品器', (spLeft.match(/picker-item/g) || []).length >= 5);
  check('显示合计金额', spLeft.indexOf('合计') >= 0);
  check('空购物车时右侧提示先选商品', spRight.indexOf('先在左侧选择要买的商品') >= 0);
  check('右侧含极速套餐推荐', spRight.indexOf('极速套餐推荐') >= 0);
  check('右侧含历史订单置顶', spRight.indexOf('历史订单置顶') >= 0);
  check('历史订单显示实付金额', spRight.indexOf('实付') >= 0);
  check('右侧列出可用券', spRight.indexOf('coupon-chip') >= 0);

  section('[5] 模式三 · 勾选商品后重算');
  // 左侧「已选 N 项 / M 件」里的件数是可靠信号
  const pickedCount = function () {
    const m = text(window, '#left-body').match(/已选\s*\d+\s*项\s*\/\s*(\d+)\s*件/);
    return m ? Number(m[1]) : -1;
  };
  const countBefore = pickedCount();
  const addBtn = window.document.querySelector('.picker-item [data-act="add"]');
  check('存在「加入」按钮', !!addBtn);
  check('读到初始已选件数（应为 0）', countBefore === 0, '实际 ' + countBefore);
  if (addBtn) {
    click(window, addBtn);
    const countAfter = pickedCount();
    check('已选件数 +1', countAfter === countBefore + 1, countBefore + ' → ' + countAfter);
    check('选品后出现「最快取餐排行」', text(window, '#right-body').indexOf('最快取餐排行') >= 0);
    check('左侧列表已重绘', text(window, '#left-body') !== spLeft);
  }

  section('[5b] 极速模式搜索框：中文输入不被截断（IME 回归）');
  const picker = window.document.querySelector('#picker-search');
  check('选品搜索框存在', !!picker);
  if (picker) {
    const listBefore = text(window, '#picker-list');
    const itemsBefore = (listBefore.match(/picker-item/g) || []).length;

    // 模拟中文输入法：compositionstart → input（组字中）→ compositionend
    picker.dispatchEvent(new window.Event('compositionstart', { bubbles: true }));
    picker.value = '巨无霸';
    picker.dispatchEvent(new window.Event('input', { bubbles: true }));

    check('组字期间输入框节点没有被替换（能打出中文的前提）',
      window.document.querySelector('#picker-search') === picker);
    check('组字期间列表保持不动（候选词不会闪掉）',
      text(window, '#picker-list') === listBefore, itemsBefore + ' 项');
    check('组字期间已记下输入内容',
      window.MCD.state.pickerQuery === '巨无霸', window.MCD.state.pickerQuery);

    picker.dispatchEvent(new window.Event('compositionend', { bubbles: true }));
    const cnNames = Array.prototype.map.call(
      window.document.querySelectorAll('#picker-list .picker-name'),
      function (n) { return n.textContent; }
    );
    check('组字结束后按中文关键词过滤',
      cnNames.length >= 1 && cnNames.every(function (n) { return n.indexOf('巨无霸') >= 0; }),
      cnNames.join(' / '));

    // 非组字输入（英文 / 数字 / 粘贴）照旧即时刷新
    const box2 = window.document.querySelector('#picker-search');
    box2.value = '麦辣';
    box2.dispatchEvent(new window.Event('input', { bubbles: true }));
    const cnNames2 = Array.prototype.map.call(
      window.document.querySelectorAll('#picker-list .picker-name'),
      function (n) { return n.textContent; }
    );
    check('非组字输入即时刷新',
      cnNames2.length >= 1 && cnNames2.every(function (n) { return n.indexOf('麦辣') >= 0; }),
      cnNames2.join(' / '));
    check('输入框节点依旧未被替换',
      window.document.querySelector('#picker-search') === box2);

    // 复位，避免影响后续用例
    click(window, window.document.querySelector('#picker-chips [data-cat="推荐"]'));
    check('复位到推荐分类', window.MCD.state.pickerQuery === '');
  }

  /* ==================================================================== */
  section('[6] 未来 7 天日历');
  const days = window.document.querySelectorAll('#calendar-days .cal-day');
  check('渲染 7 天', days.length === 7, '实际 ' + days.length);
  const calHtml = text(window, '#calendar-days');
  check('今天有高亮', calHtml.indexOf('is-today') >= 0);
  check('含具体活动标题',
    calHtml.indexOf('龙焰') >= 0 || calHtml.indexOf('蓝莓') >= 0 ||
    calHtml.indexOf('联名') >= 0 || calHtml.indexOf('早餐') >= 0 || calHtml.indexOf('周边') >= 0);
  if (days.length) {
    const withAct = Array.prototype.find.call(days, function (d) {
      return d.getAttribute('data-day') === data.calendar[0].date;
    });
    click(window, withAct);
    check('点击某天展开详情', isVisible(window, '#calendar-detail'));
    check('详情内活动可进入详情页', text(window, '#calendar-detail').indexOf('data-activity=') >= 0);
  }

  /* ==================================================================== */
  section('[7] 一键点餐入口 → 跳转点餐页');
  // 清空极速模式留下的选品，单独验证「点餐页不预选任何餐食」
  window.MCD.state.cart = {};
  click(window, window.document.querySelector('#fab-order'));
  await flush();
  check('路由切到 order 页', page(window) === 'order', '实际 ' + page(window));
  check('点餐页容器可见', isVisible(window, '#page-order'));
  check('雷达页已隐藏', window.document.querySelector('#page-radar').hidden === true);
  check('顶部导航高亮「点餐」',
    window.document.querySelector('.appnav a[data-route="/order"]').classList.contains('is-active'));

  /* ==================================================================== */
  section('[8] 点餐页结构');
  const orderHtml = text(window, '#order-root');
  const store0 = data.stores[0];
  check('顶部标题为门店信息', orderHtml.indexOf(store0.name) >= 0);
  check('抬头含门店地址', orderHtml.indexOf(store0.address) >= 0);
  check('抬头含「临时换店」入口', !!window.document.querySelector('#switch-store'));
  check('左上角有堂食 / 打包切换', orderHtml.indexOf('dining-toggle') >= 0 && orderHtml.indexOf('打包') >= 0);
  check('左列分类导航', (orderHtml.match(/cat-item/g) || []).length >= 3);
  check('右列商品卡', (orderHtml.match(/meal-card/g) || []).length >= 5);
  check('商品卡带简介描述', orderHtml.indexOf('meal-desc') >= 0);
  check('商品卡带热量标注', orderHtml.indexOf('meal-kcal') >= 0 && orderHtml.indexOf('千卡') >= 0);
  check('商品卡标出「你常点」', orderHtml.indexOf('你常点') >= 0);
  check('底部悬浮购物车栏', !!window.document.querySelector('#cart-bar'));
  check('购物车角标显示件数', text(window, '#cart-bar').indexOf('cart-badge') >= 0);

  check('空购物车时按钮为禁用态「请选择餐品」', (function () {
    const btn = window.document.querySelector('#go-checkout');
    return !!btn && btn.disabled === true && btn.textContent.indexOf('请选择餐品') >= 0;
  })(), window.document.querySelector('#go-checkout') && window.document.querySelector('#go-checkout').textContent);
  check('空购物车时提示购物车是空的', text(window, '#cart-bar').indexOf('购物车是空的') >= 0);

  section('[8b] 堂食 → 打包 切换');
  const takeawayBtn = window.document.querySelector('[data-dining="takeaway"]');
  check('打包按钮存在', !!takeawayBtn);
  if (takeawayBtn) {
    click(window, takeawayBtn);
    const active = window.document.querySelector('[data-dining].is-active');
    check('打包变为选中态', active && active.getAttribute('data-dining') === 'takeaway');
  }

  section('[8c] 分类切换与搜索');
  const catBtn = window.document.querySelectorAll('.cat-item')[2];
  if (catBtn) {
    click(window, catBtn);
    const title = window.document.querySelector('.meal-area-head h3');
    check('切换分类后标题同步', !!title && title.textContent === catBtn.getAttribute('data-cat'));
  }
  const searchBox = window.document.querySelector('#order-search');
  check('搜索框存在', !!searchBox);
  if (searchBox) {
    const beforeCount = window.document.querySelectorAll('.meal-area .meal-card').length;

    // 点餐页搜索框同属「输入框不能被重绘」这一类，用中文输入法路径验一遍
    searchBox.dispatchEvent(new window.Event('compositionstart', { bubbles: true }));
    searchBox.value = '巨无霸';
    searchBox.dispatchEvent(new window.Event('input', { bubbles: true }));
    check('点餐页搜索框组字期间节点未被替换',
      window.document.querySelector('#order-search') === searchBox);
    check('点餐页搜索框组字期间列表不动',
      window.document.querySelectorAll('.meal-area .meal-card').length === beforeCount,
      beforeCount + ' 款');
    searchBox.dispatchEvent(new window.Event('compositionend', { bubbles: true }));

    // 只看餐品区里每张卡的「餐品名」，简介正文里出现关键词不算（如「巨无霸三件套」简介含薯条）
    const names = Array.prototype.map.call(
      window.document.querySelectorAll('.meal-area .meal-name'),
      function (n) { return n.textContent; }
    );
    check('搜索命中「巨无霸」', names.length >= 1 && names.some(function (n) { return n.indexOf('巨无霸') >= 0; }));
    check('搜索结果已收窄', names.length >= 1 && names.length < 5, '命中 ' + names.length + ' 款');
    check('未命中的餐品被过滤',
      names.every(function (n) { return n.indexOf('巨无霸') >= 0; }), names.join(' / '));
    check('过滤只重绘餐品区，工具栏仍在',
      !!window.document.querySelector('#order-search') &&
      !!window.document.querySelector('.order-topbar'));
    const clearBtn = window.document.querySelector('#order-root [data-clear-query]');
    check('出现「清除搜索」按钮', !!clearBtn);
    if (clearBtn) {
      click(window, clearBtn);
      check('清除搜索后恢复列表', (text(window, '#order-root').match(/meal-card/g) || []).length >= 5);
    }
  }

  /* ==================================================================== */
  section('[10] 加购（事件委托回归）');
  const plusBtn = window.document.querySelector('.meal-card [data-act="plus"][data-code]');
  check('商品卡上有加号', !!plusBtn);
  const code0 = plusBtn.getAttribute('data-code');
  const before = badge(window);
  click(window, plusBtn);
  const after = badge(window);
  check('加购后件数 +1', after === before + 1, before + ' → ' + after);

  // 关键回归：一次点击只能 +1（防止重复绑定监听器）
  click(window, window.document.querySelector('.meal-card [data-act="plus"][data-code="' + code0 + '"]'));
  const n2 = badge(window);
  check('连续点击不重复计数（事件委托回归）', n2 === after + 1, after + ' → ' + n2);

  click(window, window.document.querySelector('#cart-toggle'));
  check('购物车抽屉展开', isVisible(window, '#cart-drawer'));
  check('抽屉含商品小计', text(window, '#cart-drawer').indexOf('商品小计') >= 0);
  check('抽屉含预计实付', text(window, '#cart-drawer').indexOf('预计实付') >= 0);
  click(window, window.document.querySelector('#cart-close'));
  check('抽屉可收起', window.document.querySelector('#cart-drawer').hidden === true);

  /* ==================================================================== */
  section('[8d] 临时换店：保留购物车 + 本店无售剔除');
  const origStore = window.MCD.state.storeCode;
  const units = function () {
    return Object.keys(window.MCD.state.cart)
      .reduce(function (a, k) { return a + window.MCD.state.cart[k]; }, 0);
  };

  // 找一家「菜单与当前店存在差异」的门店，用于验证剔除逻辑
  // （前两家门店的菜单可能完全一致，必须遍历全部候选）
  const menuA = window.MCD.data.menuOf(origStore);
  let other = null;
  let onlyHere = null;
  data.stores.forEach(function (s) {
    if (other) return;
    if (s.store_code === origStore) return;
    const codes = window.MCD.data.menuOf(s.store_code).map(function (m) { return m.code; });
    if (!codes.length) return;
    const diff = menuA.find(function (m) { return codes.indexOf(m.code) < 0; });
    if (diff) { other = s; onlyHere = diff; }
  });
  check('存在跨店差异商品（用于验证剔除逻辑）', !!onlyHere && !!other,
    onlyHere ? (onlyHere.name + ' @ ' + other.name) : '未找到');

  if (onlyHere) {
    window.MCD.state.cart[onlyHere.code] = 1;
    const unitsBeforeSwitch = units();

    click(window, window.document.querySelector('#switch-store'));
    check('换店弹窗已打开', !!window.document.querySelector('#store-modal'));
    const picks = window.document.querySelectorAll('#store-modal [data-pick]');
    check('列出可选门店', picks.length >= 2, picks.length + ' 家');
    check('弹窗标出各店可买件数', text(window, '#store-modal').indexOf('可买') >= 0);

    const target = Array.prototype.find.call(picks, function (p) {
      return p.getAttribute('data-pick') === other.store_code;
    });
    check('目标门店在列表中', !!target);
    if (target) {
      click(window, target);
      check('选中态生效', target.classList.contains('is-on'));
      click(window, window.document.querySelector('#switch-confirm'));
      check('换店弹窗已关闭', window.document.querySelector('#modal-host').hidden === true);
      check('门店已切换', window.MCD.state.storeCode === other.store_code,
        window.MCD.state.storeCode);

      check('购物车内容一件不少', units() === unitsBeforeSwitch,
        unitsBeforeSwitch + ' → ' + units());
      check('商品没有被静默丢弃', !!window.MCD.state.cart[onlyHere.code]);

      const settle = window.MCD.calc.settle(other.store_code);
      check('新店不售的商品被剔除出金额',
        settle.unavailable.some(function (i) { return i.code === onlyHere.code; }));
      check('可售 + 无售 = 购物车总件数',
        settle.count + settle.unavailableCount === unitsBeforeSwitch,
        settle.count + ' + ' + settle.unavailableCount + ' vs ' + unitsBeforeSwitch);
      check('购物车抽屉标出「本店无售」', text(window, '#cart-drawer').indexOf('本店无售') >= 0);
      check('角标同时显示可售与无售', /\+/.test(text(window, '.cart-badge')));

      // 切回原店，应自动恢复可售
      click(window, window.document.querySelector('#switch-store'));
      const back = Array.prototype.find.call(
        window.document.querySelectorAll('#store-modal [data-pick]'),
        function (p) { return p.getAttribute('data-pick') === origStore; }
      );
      click(window, back);
      click(window, window.document.querySelector('#switch-confirm'));
      const backSettle = window.MCD.calc.settle(origStore);
      check('切回原店后商品恢复可售',
        backSettle.unavailable.length === 0 && backSettle.count === unitsBeforeSwitch,
        'count=' + backSettle.count);
      check('切回后购物车件数不变', units() === unitsBeforeSwitch);
    }
  }

  /* ==================================================================== */
  section('[9] 商品详情弹窗');
  const firstCard = window.document.querySelector('[data-meal-card]');
  check('商品卡存在', !!firstCard);
  click(window, firstCard);
  check('弹窗已打开', isVisible(window, '#modal-host') && !!window.document.querySelector('#meal-modal'));
  const modalHtml = text(window, '#meal-modal');
  check('弹窗含餐品名', modalHtml.indexOf('modal-name') >= 0);
  check('弹窗含价格', modalHtml.indexOf('modal-price') >= 0);
  check('弹窗含营养或未收录提示',
    modalHtml.indexOf('营养信息') >= 0 && (modalHtml.indexOf('nut-grid') >= 0 || modalHtml.indexOf('未收录') >= 0));
  check('弹窗含餐品码', modalHtml.indexOf('餐品码') >= 0);
  check('弹窗含「套餐组成 / 配料特调 / 未取到」三者之一',
    modalHtml.indexOf('套餐组成') >= 0 || modalHtml.indexOf('配料') >= 0 || modalHtml.indexOf('组成信息未从 MCP 取到') >= 0);

  section('[9c] 套餐详情：按真实组成渲染 rounds');
  window.MCD.views.orderApi.openDetail('9900005456');
  const comboHtml = text(window, '#meal-modal');
  check('套餐弹窗已打开', !!window.document.querySelector('#meal-modal'));
  check('渲染「套餐组成」区块', comboHtml.indexOf('套餐组成') >= 0);
  check('标注了来源 query-meal-detail', comboHtml.indexOf('query-meal-detail') >= 0);
  check('渲染任选轮次', comboHtml.indexOf('comp-round') >= 0 && comboHtml.indexOf('任选') >= 0);
  check('套餐热量来自按组成累加',
    comboHtml.indexOf('按官方组成累加') >= 0 && comboHtml.indexOf('nut-grid') >= 0);
  window.MCD.views.orderApi.openDetail('1100');

  section('[9b] 弹窗内加减后加入购物车');
  const modalPlus = window.document.querySelector('#meal-modal [data-modal="plus"]');
  click(window, modalPlus);
  check('弹窗数量可控', !!window.document.querySelector('#modal-qty'));
  click(window, window.document.querySelector('#modal-add'));
  check('加入后弹窗关闭', window.document.querySelector('#modal-host').hidden === true);

  /* ==================================================================== */
  section('[11] 结算页');
  // 补一件「常点 + 有对应积分换购券」的商品（麦辣鸡腿汉堡），用于验证积分区块
  window.MCD.state.cart['1440'] = 1;
  const preSettle = window.MCD.calc.settle(window.MCD.state.storeCode);
  check('积分换购按单份计价（省额为正）',
    preSettle.offers.length > 0 && preSettle.offers.every(function (o) { return o.saving > 0; }),
    '共 ' + preSettle.offers.length + ' 项');
  check('积分换购标注「你常点」（结合历史订单）',
    preSettle.offers.some(function (o) { return o.from_history; }));
  check('积分不足的换购项给出差额提示',
    preSettle.offers.some(function (o) { return !o.affordable && o.shortfall > 0; }));

  click(window, window.document.querySelector('#go-checkout'));
  await flush();
  check('路由切到 checkout 页', page(window) === 'checkout', '实际 ' + page(window));
  const coHtml = text(window, '#checkout-root');
  check('含两栏布局容器', !!window.document.querySelector('.co-layout'));
  check('含取餐门店卡', coHtml.indexOf('取餐门店') >= 0);
  check('含换一家入口', !!window.document.querySelector('#co-switch'));
  check('含预计到达时间', coHtml.indexOf('预计到达') >= 0);
  check('含预计可取时间', coHtml.indexOf('预计可取') >= 0);
  check('含商品清单卡', coHtml.indexOf('商品清单') >= 0);
  check('含优惠券区块', coHtml.indexOf('优惠券') >= 0 || coHtml.indexOf('暂无可用券') >= 0);
  check('含积分换购区块', coHtml.indexOf('积分换购') >= 0);
  check('积分区块说明「不是直接折现」', coHtml.indexOf('不是直接折现') >= 0);
  check('含金额明细卡', coHtml.indexOf('金额明细') >= 0);
  check('含用券开关', !!window.document.querySelector('#use-coupons'));
  check('底部提交订单按钮存在', !!window.document.querySelector('#submit-order'));

  section('[11b] 关闭用券开关 → 金额变化');
  const payBefore = text(window, '.checkout-bar');
  const sw = window.document.querySelector('#use-coupons');
  if (sw && sw.checked) {
    sw.checked = false;
    sw.dispatchEvent(new window.Event('change', { bubbles: true }));
    check('关闭用券后提示已关闭', text(window, '#checkout-root').indexOf('已关闭用券') >= 0);
    check('（实付区已重绘）', text(window, '.checkout-bar') !== '' && payBefore !== '');
    sw.checked = true;
    sw.dispatchEvent(new window.Event('change', { bubbles: true }));
  } else {
    check('用券开关可交互', !!sw);
  }

  section('[11c] 积分换购可选用');
  const offerBtn = window.document.querySelector('[data-offer]');
  check('存在可用积分换购项', !!offerBtn);
  if (offerBtn) {
    click(window, offerBtn);
    check('采用积分换购后金额明细出现积分行',
      text(window, '#checkout-root').indexOf('积分 +') >= 0);
  }

  /* ==================================================================== */
  section('[12] 提交订单 → 结果页');
  click(window, window.document.querySelector('#submit-order'));
  await flush();
  check('路由切到 result 页', page(window) === 'result', '实际 ' + page(window));
  const reHtml = text(window, '#result-root');
  check('显示取餐号徽标', reHtml.indexOf('取餐号') >= 0 && reHtml.indexOf('rh-number') >= 0);
  const pickupNo = window.document.querySelector('.rh-number');
  check('取餐号非空', !!pickupNo && pickupNo.textContent.trim().length > 0);
  check('显示预计到达', reHtml.indexOf('预计到达') >= 0);
  check('显示预计可取', reHtml.indexOf('预计可取') >= 0);
  check('显示订单号', reHtml.indexOf('订单号') >= 0);
  check('含前往餐厅路线区块', reHtml.indexOf('前往餐厅路线') >= 0 && !!window.document.querySelector('#route-map'));
  check('无地图时路线降级可见（jsdom 无 TMap）', isVisible(window, '#route-fallback'));
  check('含演示订单免责提示', reHtml.indexOf('演示订单') >= 0);
  check('提供「再来一单」', !!window.document.querySelector('#again-btn'));

  section('[12b] 订单状态时间轴与取消订单');
  check('渲染状态时间轴', !!window.document.querySelector('.order-status'));
  check('时间轴含三个阶段', window.document.querySelectorAll('.os-step').length === 3);
  check('当前状态为「已下单」', text(window, '.order-status').indexOf('已下单') >= 0);
  const cancelBtn = window.document.querySelector('#cancel-btn');
  check('存在取消订单按钮', !!cancelBtn);
  check('未出餐时可取消（按钮可用）', cancelBtn && cancelBtn.disabled !== true);

  section('[12c] 已出餐 → 不可取消');
  const readyBtn = window.document.querySelector('#demo-ready-btn');
  check('存在演示用「模拟已出餐」开关', !!readyBtn);
  if (readyBtn) {
    click(window, readyBtn);
    const st = text(window, '.order-status');
    check('状态推进到「已出餐」', st.indexOf('已出餐') >= 0);
    check('取消按钮变为不可用', window.document.querySelector('#cancel-btn').disabled === true);
    check('按钮文案提示不可取消',
      window.document.querySelector('#cancel-btn').textContent.indexOf('不可取消') >= 0);
    check('给出取餐提醒', text(window, '#result-root').indexOf('尽快到柜台') >= 0);

    click(window, window.document.querySelector('#cancel-btn'));
    check('强行点击被拦截并提示', text(window, '#toast').indexOf('无法取消') >= 0);
    check('未弹出取消确认框', !window.document.querySelector('#cancel-modal'));

    // 恢复为制作中，继续验证正常取消
    click(window, window.document.querySelector('#demo-ready-btn'));
    check('可恢复为制作中', text(window, '.order-status').indexOf('制作中') >= 0);
  }

  section('[12d] 未出餐 → 取消订单');
  click(window, window.document.querySelector('#cancel-btn'));
  check('弹出取消确认框', !!window.document.querySelector('#cancel-modal'));
  check('确认框说明不会调用 MCP 撤单',
    text(window, '#cancel-modal').indexOf('cancel-order') >= 0);
  click(window, window.document.querySelector('#cancel-yes'));
  check('取消后订单状态为已取消', text(window, '.order-status').indexOf('已取消') >= 0);
  check('取餐区切换为已取消样式', !!window.document.querySelector('.result-hero.is-cancelled'));
  check('取消后不再能取消', window.document.querySelector('#cancel-btn').disabled === true);

  /* ==================================================================== */
  section('[13] 活动详情页');
  window.MCD.router.go('/activity/0');
  await flush();
  check('路由切到 activity 页', page(window) === 'activity', '实际 ' + page(window));
  const acHtml = text(window, '#activity-root');
  check('含活动详情主体', acHtml.indexOf('activity-detail') >= 0);
  check('含活动标题', acHtml.indexOf('ad-title') >= 0);
  check('含活动日期来源说明', acHtml.indexOf('campaign-calendar') >= 0);
  check('含「现在就点」入口', acHtml.indexOf('data-order-cta') >= 0);
  check('有关联餐品或前后页导航', acHtml.indexOf('关联餐品') >= 0 || acHtml.indexOf('activity-nav') >= 0);

  section('[13e] 活动详情页 · 本地区可参与门店（距离 / 步行驾车 / 抵达时间）');
  const asCards = window.document.querySelectorAll('#activity-root .activity-stores .astore');
  check('列出本地区门店', asCards.length > 0, '门店卡 ' + asCards.length + ' 张');
  check('标注当前定位', acHtml.indexOf('当前定位') >= 0);
  if (asCards.length) {
    const first = asCards[0];
    check('门店卡含地址', !!first.querySelector('.as-addr'));
    check('门店卡含距离', !!first.querySelector('.as-dist'));
    const tv = first.querySelectorAll('.as-travel .tv');
    check('给出步行 / 驾车两种出行方式', tv.length >= 2, 'chips=' + tv.length);
    check('给出预计抵达时刻', /\d{2}:\d{2}/.test(first.textContent || ''));
    check('有「去这家点餐」入口', !!first.querySelector('[data-go-store]'));
    // 点「去这家点餐」应当带着门店跳过去
    const goBtn = first.querySelector('[data-go-store]');
    const wantStore = goBtn.getAttribute('data-go-store');
    click(window, goBtn);
    await flush();
    check('「去这家点餐」跳转点餐页', page(window) === 'order', '实际 ' + page(window));
    check('点餐页已换成该门店', window.MCD.state.storeCode === wantStore,
      'state=' + window.MCD.state.storeCode + ' 期望=' + wantStore);
    window.MCD.router.go('/activity/0');
    await flush();
  }

  section('[13b] 活动页「去点餐」带搜索词跳转');
  const actOrderBtn = window.document.querySelector('#activity-root [data-order-cta]');
  click(window, actOrderBtn);
  await flush();
  check('跳转回点餐页', page(window) === 'order', '实际 ' + page(window));
  check('点餐页已就绪', text(window, '#order-root').indexOf('order-topbar') >= 0);

  section('[13c] 返回地图');
  click(window, window.document.querySelector('[data-nav="/"]'));
  await flush();
  check('回到雷达页', page(window) === 'radar', '实际 ' + page(window));

  section('[13d] 活动索引越界时优雅退回雷达页（不白屏）');
  window.MCD.router.go('/activity/9999');
  // 这里是**两跳**：越界 → renderActivity 发现取不到活动 → 再 go('/')。
  // jsdom 的 hashchange 是异步派发的，所以要给足时间，别只 flush 一次。
  await flush(60);
  await flush(60);
  check('越界活动索引退回雷达页', page(window) === 'radar', '实际 ' + page(window));
  check('回到雷达页后内容仍完整', text(window, '#left-body').length > 0 &&
    text(window, '#radar-svg').length > 0);

  console.log('\n结果：' + passed + ' 通过 / ' + failed + ' 失败\n');
  process.exit(failed === 0 ? 0 : 1);
}

run().catch(function (err) {
  console.error('\n冒烟测试异常：', err && err.stack || err);
  process.exit(1);
});
