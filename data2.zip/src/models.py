"""领域模型。

分三组：
1. 活动 / 优惠券 —— 活动雷达（``radar`` 命令）使用；
2. 门店 / 餐品 / 订单 —— 雷达地图（``web`` 命令）使用；
3. 派生指标 —— 到达时长、繁忙度、库存信号等推算结果。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# --------------------------------------------------------------------------- #
# 活动 / 优惠券
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Activity:
    """一条麦当劳营销活动。"""

    date: str
    title: str
    body: str = ""
    image: str = ""
    status: str = "unknown"  # today / upcoming / past / unknown

    def summary(self, limit: int = 70) -> str:
        text = " ".join(self.body.split())
        if len(text) <= limit:
            return text
        return text[: max(0, limit - 1)] + "…"


@dataclass(frozen=True)
class Coupon:
    """一张优惠券（概要，来自 available-coupons）。"""

    title: str
    status: str = "unknown"
    image: str = ""


@dataclass(frozen=True)
class StoreCoupon:
    """指定门店可用的优惠券（来自 query-store-coupons，带券码）。"""

    coupon_id: str
    coupon_code: str
    title: str
    valid_from: str = ""
    valid_to: str = ""
    product_names: tuple[str, ...] = ()
    product_codes: tuple[str, ...] = ()

    def saving_label(self) -> str:
        return self.title


@dataclass
class RadarItem:
    """雷达条目：活动 + 关注度评分 + 推荐理由。"""

    activity: Activity
    score: float
    reasons: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------- #
# 门店 / 餐品 / 订单
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Store:
    """一家麦当劳门店。"""

    store_code: str
    name: str
    address: str
    distance: int  # 米，相对搜索位置
    be_type: int = 1  # 1-到店自取 2-麦乐送 5-得来速 6-团餐
    be_code: str = ""
    business_status: bool = True
    open_time: str = ""
    close_time: str = ""
    reservation: bool = False
    city: str = ""
    longitude: float = 0.0
    latitude: float = 0.0

    @property
    def has_coords(self) -> bool:
        """MCP 目前恒返回 0.0，需在前端做地理编码兜底。"""
        return bool(self.longitude) and bool(self.latitude)

    @property
    def be_type_label(self) -> str:
        return {
            1: "到店自取",
            2: "麦乐送",
            5: "得来速",
            6: "企业团餐",
        }.get(self.be_type, "未知")


@dataclass(frozen=True)
class Meal:
    """一个餐品。"""

    code: str
    name: str
    price: float  # 现价（元）
    original_price: float  # 划线价（元）
    image: str = ""
    discount_type: str = ""
    tags: tuple[str, ...] = ()

    @property
    def saving(self) -> float:
        return max(0.0, round(self.original_price - self.price, 2))

    @property
    def has_discount(self) -> bool:
        return self.original_price > self.price + 0.001


@dataclass(frozen=True)
class OrderRecord:
    """一条历史订单。"""

    order_id: str
    store_code: str
    store_name: str
    create_time: str
    amount: float
    products: tuple[dict[str, Any], ...] = ()
    combo_names: tuple[str, ...] = ()

    @property
    def summary(self) -> str:
        names = [str(p.get("productName", "")) for p in self.products]
        return "、".join(n for n in names if n) or "（无明细）"

    @property
    def preferred_names(self) -> tuple[str, ...]:
        """「常点商品」候选：套餐子项 + 顶层商品名，去重且保持顺序。

        套餐子项（comboItemList）比「堡堡随心拼」这种套餐名更能反映真实口味，
        所以优先并入，用于「你常点」这类个性化提示。
        """
        seen: dict[str, None] = {}
        for name in self.combo_names:
            if name:
                seen.setdefault(name, None)
        for product in self.products:
            name = str(product.get("productName", ""))
            if name:
                seen.setdefault(name, None)
        return tuple(seen)


@dataclass(frozen=True)
class Account:
    """会员积分账户。

    字段名严格对齐 ``query-my-account`` 的真实返回（camelCase 驼峰版），
    以便前端「用户信息下拉」能原样展示，不做任何推算填充。
    """

    available_points: float = 0.0
    accumulated_points: float = 0.0
    expired_points: float = 0.0
    unit: str = "积分"
    account_id: str = ""
    used_points: float = 0.0
    frozen_points: float = 0.0
    expiring_this_month: float = 0.0
    expiring_next_month: float = 0.0
    expired_last_month: float = 0.0


# --------------------------------------------------------------------------- #
# 派生指标
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class TravelEstimate:
    """到店耗时推算。"""

    minutes: int
    mode: str  # walk / ride / drive
    mode_label: str

    @property
    def is_walkable(self) -> bool:
        return self.mode == "walk"


@dataclass(frozen=True)
class BusyEstimate:
    """门店繁忙度推算（**模型估值，非实时排队数据**）。"""

    score: int  # 0-100，越高越忙
    label: str  # 空闲 / 正常 / 偏忙 / 极度繁忙
    queue_minutes: int
    factors: tuple[str, ...] = ()
    is_estimate: bool = True


@dataclass(frozen=True)
class StoreStatus:
    """门店综合状态：距离 + 耗时 + 繁忙度 + 营业状态。"""

    store: Store
    travel: TravelEstimate
    busy: BusyEstimate
    pickup_minutes: int  # 到店后取餐等待

    @property
    def total_minutes(self) -> int:
        """从出发到拿到餐的总耗时。"""
        return self.travel.minutes + self.pickup_minutes

    @property
    def orderable(self) -> bool:
        return self.store.business_status
