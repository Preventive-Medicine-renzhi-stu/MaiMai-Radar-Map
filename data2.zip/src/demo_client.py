"""离线演示客户端。

用真实抓取的 MCP 快照（见 :mod:`src.demo_data`）模拟麦当劳 MCP 的返回，
便于在没有 MCP Token 的情况下（评审查看、CI 冒烟测试、Web 预览）完整跑通。

真实运行时用 :class:`src.mcp_client.HttpMCPClient`，两者接口完全一致。
"""

from __future__ import annotations

from typing import Any

from . import demo_data

NOW_TIME = {
    "success": True,
    "code": 200,
    "datetime": "2026-10-09T19:34:43.000",
    "data": {
        "formatted": "2026-10-09 19:34:43",
        "date": "2026-10-09",
        "dayOfWeek": "FRIDAY",
        "timezone": "GMT+08:00",
    },
}

_TEXT_RESPONSES: dict[str, str] = {
    "available-coupons": demo_data.AVAILABLE_COUPONS_TEXT,
    "query-my-coupons": demo_data.AVAILABLE_COUPONS_TEXT,
    "auto-bind-coupons": demo_data.BIND_TEXT,
}


class DemoMCPClient:
    """无网络、无 Token 的演示客户端，接口与 HttpMCPClient 一致。"""

    def __init__(self, city: str = "深圳", keyword: str = "腾讯滨海大厦") -> None:
        self.calls: list[str] = []
        self.city = city
        self.keyword = keyword

    async def __aenter__(self) -> "DemoMCPClient":
        return self

    async def __aexit__(self, *exc: object) -> None:
        return None

    async def call(self, tool: str, arguments: dict[str, Any] | None = None) -> Any:
        self.calls.append(tool)
        args = arguments or {}
        return self._dispatch(tool, args)

    def _dispatch(self, tool: str, args: dict[str, Any]) -> Any:
        if tool == "campaign-calendar":
            return demo_data.calendar_text()
        if tool in _TEXT_RESPONSES:
            return _TEXT_RESPONSES[tool]
        if tool == "now-time-info":
            return NOW_TIME
        if tool in ("query-nearby-stores", "delivery-query-stores"):
            return demo_data.nearby_stores_payload(int(args.get("beType", 1) or 1))
        if tool == "query-meals":
            return demo_data.menu_payload(str(args.get("storeCode", "")))
        if tool == "order-list":
            return demo_data.ORDERS
        if tool == "query-store-coupons":
            return demo_data.STORE_COUPONS
        if tool == "query-my-account":
            return demo_data.ACCOUNT
        if tool == "list-nutrition-foods":
            return demo_data.nutrition_payload()
        if tool == "query-meal-detail":
            return demo_data.meal_detail_payload(
                str(args.get("code", "")), str(args.get("storeCode", ""))
            )
        if tool == "mall-points-products":
            return demo_data.points_mall_payload()
        if tool == "delivery-query-addresses":
            return {"success": True, "code": 200, "data": {"addresses": []}}
        return f"[demo] 工具 {tool} 暂无内置样例数据"

    async def aclose(self) -> None:
        return None
