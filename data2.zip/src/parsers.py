"""把麦当劳 MCP 返回的文本结果解析为结构化数据。

MCP 的 campaign-calendar / available-coupons 返回的是 Markdown 文本，
query-my-account 之类返回的是「说明 + 原始 JSON」。本模块统一做兼容解析。
"""

from __future__ import annotations

import re
from datetime import date
from typing import Any, Iterable

from .models import Activity, Coupon

_SECTION_RE = re.compile(r"^#{3,4}\s*(.+?)\s*$")
_DATE_RE = re.compile(r"(\d{4})年(\d{1,2})月(\d{1,2})日")
_TITLE_RE = re.compile(r"\*\*活动标题\*\*\s*[:：]\s*(.+?)\s*$")
_BODY_RE = re.compile(r"\*\*活动内容介绍\*\*\s*[:：]\s*(.+?)\s*$")
_IMG_RE = re.compile(r"<img[^>]*\bsrc=\"([^\"]+)\"")
_COUPON_TITLE_RE = re.compile(r"-\s*优惠券标题\s*[:：]\s*(.+?)\s*\\?$")
_STATUS_RE = re.compile(r"状态\s*[:：]\s*(.+?)\s*\\?$")

_LIST_KEYS = ("data", "list", "items", "records", "result", "content")
_TITLE_KEYS = ("title", "name", "activityName", "couponName", "couponTitle")
_BODY_KEYS = ("content", "desc", "description", "introduction", "activityContent")
_DATE_KEYS = ("date", "day", "activityDate", "beginTime", "startTime")
_STATUS_KEYS = ("status", "statusText", "state")


# --------------------------------------------------------------------------- #
# 活动日历
# --------------------------------------------------------------------------- #
def parse_activities(payload: Any, today: date | None = None) -> list[Activity]:
    """兼容 MCP 返回的三种形态。

    麦当劳 MCP 的 ``campaign-calendar`` 前后换过两次壳，三种都要认：

    1. **结构化日历**（当前线上形态）——
       ``{"data": {"dailyList": [{"date", "dateText", "events": [{"articleDto": {...}}]}]}}``。
       注意活动正文在 ``articleDto`` 里，且 ``dailyList`` / ``articleDto`` 都**不在**
       老的 ``_LIST_KEYS`` / ``_TITLE_KEYS`` 里 —— 只按老键名找会得到「0 条活动」，
       页面就成了空的（这正是 2026-10-10 用户看到的「深圳活动没了」）。
    2. 通用键名结构 —— ``data`` / ``list`` / ``items`` 等。
    3. Markdown 文本 —— 最早期形态，保留兼容。
    """
    daily = _daily_calendar(payload)
    if daily is not None:
        return _parse_activities_daily(daily, today)
    if isinstance(payload, str) and payload.strip():
        return _parse_activities_text(payload, today)
    return _parse_activities_structured(payload, today)


def _daily_calendar(payload: Any) -> list[dict[str, Any]] | None:
    """认出「每日日历」形态并返回 dailyList，否则 None。"""
    if not isinstance(payload, dict):
        return None
    data = payload.get("data")
    if isinstance(data, dict) and isinstance(data.get("dailyList"), list):
        return [d for d in data["dailyList"] if isinstance(d, dict)]
    # 容忍直接把 dailyList 放在顶层，或者把 data 直接当列表传进来
    if isinstance(payload.get("dailyList"), list):
        return [d for d in payload["dailyList"] if isinstance(d, dict)]
    if isinstance(data, dict) and isinstance(data.get("events"), list):
        return [data]
    return None


def _parse_activities_daily(daily: list[dict[str, Any]], today: date | None) -> list[Activity]:
    """解析 ``dailyList[].events[].articleDto`` 形态。"""
    out: list[Activity] = []
    for day in daily:
        date_str = _pick_date(day.get("date")) or _pick_date(day.get("dateText"))
        # 状态：先认 dateText 里的「往期回顾 / 今日」；认不出（upcoming）就交给
        # 日期自己算 —— 否则一个「没有关键词的过去日期」会被误判成未来活动。
        hint = _status_from_heading(str(day.get("dateText") or ""))
        status = _normalize_status(hint if hint != "upcoming" else "unknown", date_str, today)

        events = day.get("events") if isinstance(day.get("events"), list) else []
        for event in events:
            if not isinstance(event, dict):
                continue
            article = event.get("articleDto")
            if not isinstance(article, dict):
                article = event.get("article") if isinstance(event.get("article"), dict) else {}
            title = _first_str(article, _TITLE_KEYS) or _first_str(
                event, ("activityTitle", "title")
            )
            if not title:
                continue
            out.append(
                Activity(
                    date=date_str,
                    title=title,
                    body=_first_str(article, _BODY_KEYS),
                    image=_first_image(article) or _first_str(
                        event, ("image", "imageUrl", "img")
                    ),
                    status=status,
                )
            )
    return out


def _first_image(record: dict[str, Any]) -> str:
    """取列表形态的图片字段（``imgList`` / ``images`` 等）里的第一张。"""
    for key in ("imgList", "images", "imageList", "pics"):
        value = record.get(key)
        if isinstance(value, list):
            for item in value:
                if isinstance(item, str) and item.strip():
                    return item.strip()
                if isinstance(item, dict):
                    url = item.get("url") or item.get("src") or item.get("image")
                    if isinstance(url, str) and url.strip():
                        return url.strip()
    return _first_str(record, ("image", "imageUrl", "img"))


def _parse_activities_text(text: str, today: date | None) -> list[Activity]:
    activities: list[Activity] = []
    cur_date = ""
    cur_status = "unknown"
    title: str | None = None
    body: list[str] = []
    image = ""

    def flush() -> None:
        nonlocal title, body, image
        if title:
            activities.append(
                Activity(
                    date=cur_date,
                    title=title.strip(),
                    body="\n".join(body).strip(),
                    image=image,
                    status=_normalize_status(cur_status, cur_date, today),
                )
            )
        title, body, image = None, [], ""

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue

        section = _SECTION_RE.match(line)
        if section:
            heading = section.group(1)
            match = _DATE_RE.search(heading)
            if match:
                flush()
                cur_date = (
                    f"{int(match.group(1)):04d}-{int(match.group(2)):02d}-"
                    f"{int(match.group(3)):02d}"
                )
                cur_status = _status_from_heading(heading)
            continue

        found_title = _TITLE_RE.search(line)
        if found_title:
            flush()
            title = found_title.group(1)
            continue

        if title is None:
            continue

        found_body = _BODY_RE.search(line)
        if found_body:
            body.append(found_body.group(1))
            continue

        found_img = _IMG_RE.search(line)
        if found_img:
            image = found_img.group(1)
            continue

        if line.startswith("**") and line.rstrip().endswith(("**：", "**:")):
            continue  # 其它字段标题（如图片介绍），跳过

        body.append(line)

    flush()
    return activities


def _status_from_heading(heading: str) -> str:
    if "今日" in heading or "今天" in heading:
        return "today"
    if "往期" in heading or "回顾" in heading:
        return "past"
    return "upcoming"


def _normalize_status(status: str, date_str: str, today: date | None) -> str:
    if status != "unknown":
        return status
    if today is None or not date_str:
        return status
    parsed = _safe_date(date_str)
    if parsed is None:
        return status
    if parsed < today:
        return "past"
    if parsed == today:
        return "today"
    return "upcoming"


def _parse_activities_structured(payload: Any, today: date | None) -> list[Activity]:
    out: list[Activity] = []
    for record in _iter_records(payload):
        title = _first_str(record, _TITLE_KEYS)
        if not title:
            continue
        date_str = _pick_date(_first_value(record, _DATE_KEYS))
        status = _normalize_status(
            _first_str(record, _STATUS_KEYS).lower() or "unknown", date_str, today
        )
        out.append(
            Activity(
                date=date_str,
                title=title,
                body=_first_str(record, _BODY_KEYS),
                image=_first_str(record, ("image", "imageUrl", "img")),
                status=status,
            )
        )
    return out


# --------------------------------------------------------------------------- #
# 优惠券
# --------------------------------------------------------------------------- #
def parse_coupons(payload: Any) -> list[Coupon]:
    if isinstance(payload, str) and payload.strip():
        return _parse_coupons_text(payload)
    return _parse_coupons_structured(payload)


def _parse_coupons_text(text: str) -> list[Coupon]:
    coupons: list[Coupon] = []
    title: str | None = None
    status = "unknown"
    image = ""

    def flush() -> None:
        nonlocal title, status, image
        if title:
            coupons.append(Coupon(title=title.strip(), status=status.strip(), image=image))
        title, status, image = None, "unknown", ""

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue

        found_title = _COUPON_TITLE_RE.match(line)
        if found_title:
            flush()
            title = found_title.group(1)
            continue

        if title is None:
            continue

        found_status = _STATUS_RE.match(line)
        if found_status:
            status = found_status.group(1)
            continue

        found_img = _IMG_RE.search(line)
        if found_img:
            image = found_img.group(1)

    flush()
    return coupons


def _parse_coupons_structured(payload: Any) -> list[Coupon]:
    out: list[Coupon] = []
    for record in _iter_records(payload):
        title = _first_str(record, tuple(_TITLE_KEYS) + ("couponName",))
        if not title:
            continue
        out.append(
            Coupon(
                title=title,
                status=_first_str(record, _STATUS_KEYS) or "unknown",
                image=_first_str(record, ("image", "imageUrl", "img")),
            )
        )
    return out


# --------------------------------------------------------------------------- #
# 通用辅助
# --------------------------------------------------------------------------- #
def _iter_records(payload: Any) -> Iterable[dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if isinstance(payload, dict):
        for key in _LIST_KEYS:
            value = payload.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
        return [payload]
    return []


def _first_value(record: dict[str, Any], keys: Iterable[str]) -> Any:
    for key in keys:
        if key in record and record[key] not in (None, ""):
            return record[key]
    return None


def _first_str(record: dict[str, Any], keys: Iterable[str]) -> str:
    value = _first_value(record, keys)
    if value is None:
        return ""
    return value if isinstance(value, str) else str(value)


def _pick_date(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    match = _DATE_RE.search(value)
    if match:
        return (
            f"{int(match.group(1)):04d}-{int(match.group(2)):02d}-{int(match.group(3)):02d}"
        )
    head = value.strip()[:10]
    return head if _safe_date(head) else ""


def _safe_date(value: str) -> date | None:
    try:
        return date.fromisoformat(value)
    except (ValueError, TypeError):
        return None
