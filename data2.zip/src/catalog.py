"""把 MCP 的门店 / 菜单 / 订单 / 账户 / 门店券返回解析为结构化模型。

麦当劳 MCP 的返回有两种形态：
1. **结构化 JSON**（``data`` / ``data.list`` / ``data.categories`` 等）；
2. **「说明文字 + 原始 JSON」** 的纯文本（``query-nearby-stores`` 等）。
   ``mcp_client.extract_payload`` 已尽量还原成 dict，此处再做一次兜底。
"""

from __future__ import annotations

import json
import re
from typing import Any, Iterable

from .models import Account, Meal, OrderRecord, Store, StoreCoupon

_JSON_BLOB_RE = re.compile(r"\{.*\}", re.DOTALL)


# --------------------------------------------------------------------------- #
# 通用辅助
# --------------------------------------------------------------------------- #
def ensure_mapping(payload: Any) -> dict[str, Any]:
    """把可能的「文本里夹 JSON」还原成 dict。"""
    if isinstance(payload, dict):
        return payload
    if isinstance(payload, str):
        match = _JSON_BLOB_RE.search(payload)
        if match:
            try:
                parsed = json.loads(match.group(0))
                if isinstance(parsed, dict):
                    return parsed
            except json.JSONDecodeError:
                pass
    return {}


def _dig(payload: Any, *path: str) -> Any:
    node = ensure_mapping(payload)
    if node is payload and not isinstance(payload, dict):
        return None
    for key in path:
        if not isinstance(node, dict):
            return None
        node = node.get(key)
    return node


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _as_str(value: Any, default: str = "") -> str:
    if value in (None, ""):
        return default
    return value if isinstance(value, str) else str(value)


def _as_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1", "yes"}
    if isinstance(value, (int, float)):
        return bool(value)
    return default


# --------------------------------------------------------------------------- #
# 门店
# --------------------------------------------------------------------------- #
def parse_stores(payload: Any, be_type: int = 1, city: str = "") -> list[Store]:
    """解析 query-nearby-stores / delivery-query-stores 的返回。"""
    data = _dig(payload, "data")
    records: Iterable[Any] = data if isinstance(data, list) else []

    stores: list[Store] = []
    for record in records:
        if not isinstance(record, dict):
            continue
        store_code = _as_str(record.get("storeCode"))
        if not store_code:
            continue
        stores.append(
            Store(
                store_code=store_code,
                name=_as_str(record.get("storeName"), f"门店 {store_code}"),
                address=_as_str(record.get("address")),
                distance=_as_int(record.get("distance")),
                be_type=be_type,
                be_code=_as_str(record.get("beCode")),
                business_status=_as_bool(record.get("businessStatus"), True),
                open_time=_as_str(record.get("businessStartTime")),
                close_time=_as_str(record.get("businessEndTime")),
                reservation=_as_bool(record.get("reservation")),
                city=city,
                longitude=_as_float(record.get("longitude")),
                latitude=_as_float(record.get("latitude")),
            )
        )
    return stores


# --------------------------------------------------------------------------- #
# 菜单
# --------------------------------------------------------------------------- #
def parse_meals(payload: Any) -> list[Meal]:
    """解析 query-meals 的返回（``data.categories`` + ``data.meals`` 映射表）。"""
    data = ensure_mapping(_dig(payload, "data"))
    meals_map = data.get("meals")
    if not isinstance(meals_map, dict):
        return []

    # code -> tags（同一餐品可能出现在多个分类里，合并标签）
    tags_by_code: dict[str, list[str]] = {}
    categories = data.get("categories")
    if isinstance(categories, list):
        for category in categories:
            if not isinstance(category, dict):
                continue
            for entry in category.get("meals") or []:
                if not isinstance(entry, dict):
                    continue
                code = _as_str(entry.get("code"))
                if not code:
                    continue
                bucket = tags_by_code.setdefault(code, [])
                for tag in entry.get("tags") or []:
                    tag_str = _as_str(tag)
                    if tag_str and tag_str not in bucket:
                        bucket.append(tag_str)

    meals: list[Meal] = []
    for code, detail in meals_map.items():
        if not isinstance(detail, dict):
            continue
        price = _as_float(detail.get("currentPrice"))
        original = _as_float(detail.get("originalPrice")) or price
        meals.append(
            Meal(
                code=_as_str(code),
                name=_as_str(detail.get("name"), _as_str(code)),
                price=round(price, 2),
                original_price=round(original, 2),
                image=_as_str(detail.get("image")),
                discount_type=_as_str(detail.get("discountType")),
                tags=tuple(tags_by_code.get(_as_str(code), ())),
            )
        )
    return meals


# --------------------------------------------------------------------------- #
# 历史订单
# --------------------------------------------------------------------------- #
def parse_orders(payload: Any) -> list[OrderRecord]:
    """解析 order-list 的返回。"""
    records = _dig(payload, "data", "list")
    if not isinstance(records, list):
        return []

    orders: list[OrderRecord] = []
    for record in records:
        if not isinstance(record, dict):
            continue
        order_id = _as_str(record.get("orderId"))
        if not order_id:
            continue
        products = tuple(
            {
                "productCode": _as_str(item.get("productCode")),
                "productName": _as_str(item.get("productName")),
                "quantity": _as_int(item.get("quantity"), 1),
            }
            for item in (record.get("orderProductList") or [])
            if isinstance(item, dict)
        )
        combo_names: tuple[str, ...] = ()
        for product in record.get("orderProductList") or []:
            if not isinstance(product, dict):
                continue
            for item in product.get("comboItemList") or []:
                if not isinstance(item, dict):
                    continue
                name = _as_str(item.get("name") or item.get("productName"))
                if name:
                    combo_names = combo_names + (name,)

        orders.append(
            OrderRecord(
                order_id=order_id,
                store_code=_as_str(record.get("storeCode")),
                store_name=_as_str(record.get("storeName")),
                create_time=_as_str(record.get("createTime")),
                amount=_as_float(record.get("realTotalAmount")),
                products=products,
                combo_names=combo_names,
            )
        )
    return orders


# --------------------------------------------------------------------------- #
# 门店可用券
# --------------------------------------------------------------------------- #
def parse_store_coupons(payload: Any) -> list[StoreCoupon]:
    """解析 query-store-coupons 的返回（带券码，可用于算价/核销）。"""
    data = _dig(payload, "data")
    if not isinstance(data, list):
        return []

    coupons: list[StoreCoupon] = []
    for record in data:
        if not isinstance(record, dict):
            continue
        title = _as_str(record.get("title"))
        coupon_id = _as_str(record.get("couponId"))
        if not title and not coupon_id:
            continue
        valid_from, valid_to = _split_validity(_as_str(record.get("tradeDateTime")))
        product_names: list[str] = []
        product_codes: list[str] = []
        for product in record.get("products") or []:
            if not isinstance(product, dict):
                continue
            name = _as_str(product.get("productName"))
            code = _as_str(product.get("productCode"))
            if name:
                product_names.append(name)
            if code:
                product_codes.append(code)
        coupons.append(
            StoreCoupon(
                coupon_id=coupon_id,
                coupon_code=_as_str(record.get("couponCode")),
                title=title,
                valid_from=valid_from,
                valid_to=valid_to,
                product_names=tuple(product_names),
                product_codes=tuple(product_codes),
            )
        )
    return coupons


def _split_validity(raw: str) -> tuple[str, str]:
    """``2026-10-05 10:30:00-2026-10-09 23:59:59`` -> (start, end)。"""
    if not raw:
        return "", ""
    if "-" not in raw:
        return raw, raw
    parts = raw.split("-")
    if len(parts) < 7:  # 日期本身带 '-'，至少 6 段 + 1
        return raw, raw
    return "-".join(parts[:3]).strip(), "-".join(parts[4:]).strip()


# --------------------------------------------------------------------------- #
# 会员账户
# --------------------------------------------------------------------------- #
_POINT_KEYS = {
    "available": ("availablePoints", "availablePoint", "usablePoints", "points", "balance"),
    "accumulated": (
        "accumulatedPoints", "accumulativePoint", "totalPoints",
        "historyPoints", "accumulatePoints",
    ),
    "expired": ("expiredPoints", "expiredPoint", "expirePoints", "expirePoint"),
    "used": ("usedPoints", "usedPoint"),
    "frozen": ("frozenPoints", "frozenPoint"),
    "expiring_this_month": ("currentMouthExpirePoint", "currentMonthExpirePoint"),
    "expiring_next_month": ("nextMouthExpirePoint", "nextMonthExpirePoint"),
    "expired_last_month": ("lastMouthExpirePoint", "lastMonthExpirePoint"),
}


def parse_account(payload: Any) -> Account:
    """解析 query-my-account。字段名在各版本间不稳定，做启发式提取。"""
    node = ensure_mapping(payload)
    flat: dict[str, Any] = {}

    def walk(value: Any, depth: int = 0) -> None:
        if depth > 4:
            return
        if isinstance(value, dict):
            for key, item in value.items():
                flat.setdefault(key, item)
                walk(item, depth + 1)
        elif isinstance(value, list):
            for item in value[:5]:
                walk(item, depth + 1)

    walk(node)

    def pick(group: str) -> float:
        for key in _POINT_KEYS[group]:
            if key in flat:
                number = _as_float(flat[key], -1.0)
                if number >= 0:
                    return round(number, 1)
        return 0.0

    unit = "积分"
    for key in ("unit", "pointsUnit", "currency", "currencyName", "pointName"):
        if flat.get(key):
            unit = _as_str(flat[key])
            break

    account_id = ""
    for key in ("accountId", "accountID", "memberId", "userId"):
        if flat.get(key):
            account_id = _as_str(flat[key])
            break

    return Account(
        available_points=pick("available"),
        accumulated_points=pick("accumulated"),
        expired_points=pick("expired"),
        unit=unit,
        account_id=account_id,
        used_points=pick("used"),
        frozen_points=pick("frozen"),
        expiring_this_month=pick("expiring_this_month"),
        expiring_next_month=pick("expiring_next_month"),
        expired_last_month=pick("expired_last_month"),
    )


# --------------------------------------------------------------------------- #
# 营养成分
# --------------------------------------------------------------------------- #
_NUTRITION_FIELDS = ("kj", "kcal", "protein", "fat", "carb", "sodium", "calcium")

# 菜单简称 -> 营养表全名（营养表按规格逐条目，菜单只给统称）
NUTRITION_ALIASES: dict[str, str] = {
    "薯条": "中薯条",
    "麦乐鸡": "麦乐鸡5块",
    "麦辣鸡翅": "麦辣鸡翅-2块",
    "麦辣鸡翅2块": "麦辣鸡翅-2块",
    "可乐": "可乐中杯",
    "雪碧": "雪碧中杯",
    "怡泉+C": "中杯怡泉+C",
    "经典麦旋风": "奥利奥麦旋风",
    "麦咖啡™美式": "冰美式中杯",
    "麦咖啡™奶铁": "冰奶铁中杯",
    "鲜萃咖啡": "小杯鲜萃咖啡",
    "浓浓黑巧（冰/热）": "冰浓浓黑巧中杯",
    "蘸酱麦麦脆汁鸡": "麦麦脆汁鸡-琵琶腿",
    "蘸酱炸鸡": "麦麦脆汁鸡-琵琶腿",
    "蘸酱韩式甜辣酱鸡块": "麦乐鸡5块",
    "韩式甜辣酱鸡块8块": "麦乐鸡5块",
    "麦麦脆汁鸡": "麦麦脆汁鸡-琵琶腿",
    "心形薯饼5块": "脆薯饼",
    "灰焰圆筒": "圆筒冰淇淋",
    "蓝莓爆爆珠麦旋风": "奥利奥麦旋风",
    "姜汁撞奶风味派": "香芋派",
    "马苏里拉拉丝芝士条": "脆脆薯条",
}


def parse_nutrition(payload: Any) -> dict[str, dict[str, Any]]:
    """解析 ``list-nutrition-foods``。

    原始 ``data`` 是一段形如::

        [160]{productName,nutritionDescription,energyKj,...}:
          巨无霸,null,2146,513,27,26,42,961,171

    的文本；同时也兼容结构化 JSON 数组。

    返回：``{餐品名: {kcal, kj, protein, fat, carb, sodium, calcium, note}}``。
    """
    data = payload.get("data") if isinstance(payload, dict) else payload

    rows: list[Any]
    if isinstance(data, str):
        rows = _split_nutrition_text(data)
    elif isinstance(data, list):
        rows = data
    else:
        return {}

    table: dict[str, dict[str, Any]] = {}
    for row in rows:
        if isinstance(row, dict):
            name = _as_str(row.get("productName"))
            if not name:
                continue
            entry = {
                "kcal": _as_float(row.get("energyKcal")),
                "kj": _as_float(row.get("energyKj")),
                "protein": _as_float(row.get("protein")),
                "fat": _as_float(row.get("fat")),
                "carb": _as_float(row.get("carbohydrate")),
                "sodium": _as_float(row.get("sodium")),
                "calcium": _as_float(row.get("calcium")),
            }
            note = _as_str(row.get("nutritionDescription"))
        else:
            name, note, entry = row
        note = "" if note in ("null", "None") else note
        entry["note"] = note
        table[name] = entry
    return table


def _split_nutrition_text(text: str) -> list[tuple[str, str, dict[str, Any]]]:
    """把营养成分的文本表拆成 ``(名称, 说明, 数值)`` 三元组。"""
    out: list[tuple[str, str, dict[str, Any]]] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("["):
            continue
        parts = [part.strip() for part in line.split(",")]
        if len(parts) < 9:
            continue
        numbers = parts[-7:]
        if not all(_is_number(value) for value in numbers):
            continue
        name = parts[0]
        note = ",".join(parts[1:-7]).strip()
        entry = {
            field: _as_float(value)
            for field, value in zip(_NUTRITION_FIELDS, numbers)
        }
        out.append((name, note, entry))
    return out


def _is_number(value: str) -> bool:
    try:
        float(value)
        return True
    except (TypeError, ValueError):
        return False


def lookup_nutrition(
    name: str,
    table: dict[str, dict[str, Any]],
    allow_approx: bool = True,
) -> dict[str, Any] | None:
    """按餐品名在营养表里找最贴近的一条。

    菜单名常是简称（「薯条」），营养表里是规格全名（「中薯条」）；套餐类
    在营养表里**没有**独立条目。因此匹配分三档，并在结果里标明来源，
    便于前端如实区分「官方原值」与「同类参考值」：

    * ``exact``  —— 名称完全一致，官方原值；
    * ``alias``  —— 通过别名表映射（如「薯条」→「中薯条」），**参考值**；
    * ``approx`` —— 互相包含且长度最接近，**参考值**。

    ``allow_approx=False`` 时只做精确与别名匹配——套餐名不能当成单品，
    否则「麦辣鸡腿汉堡三件套」会错误地取到单个汉堡的热量。
    """
    if not name or not table:
        return None

    if name in table:
        return {**table[name], "match": "exact"}

    alias = NUTRITION_ALIASES.get(name)
    if alias and alias in table:
        return {**table[alias], "match": "alias", "source_name": alias}

    # 去掉规格/修饰词后再试一次
    trimmed = name
    for word in ("（冰/热）", "(冰/热)", "™", "麦咖啡"):
        trimmed = trimmed.replace(word, "")
    trimmed = trimmed.strip()
    if trimmed and trimmed in table:
        return {**table[trimmed], "match": "exact"}

    if not allow_approx:
        return None

    best_key = ""
    for key in table:
        if name in key or key in name or (trimmed and (trimmed in key or key in trimmed)):
            if not best_key or abs(len(key) - len(name)) < abs(len(best_key) - len(name)):
                best_key = key
    return {**table[best_key], "match": "approx", "source_name": best_key} if best_key else None


# 套餐类名称标记：这些名字在营养表里没有独立条目
COMBO_MARKERS: tuple[str, ...] = (
    "套餐",
    "三件套",
    "四件套",
    "两件套",
    "随心配",
    "随心拼",
    "双人餐",
    "单人餐",
)


def is_combo_name(name: str) -> bool:
    """判断餐品名是否为套餐类（影响营养匹配策略）。"""
    return any(marker in (name or "") for marker in COMBO_MARKERS)


def resolve_nutrition(
    code: str,
    name: str,
    table: dict[str, dict[str, Any]],
    compositions: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any] | None:
    """综合解析一个餐品的营养信息。

    优先级：
    1. 精确 / 别名匹配（单品走「包含」近似，套餐不走）；
    2. 套餐有**真实组成**时，按官方组成逐项累加得到 ``computed`` 结果；
    3. 都没有 → 返回 ``None``（前端如实显示「官方营养表未收录」）。
    """
    entry = lookup_nutrition(name, table, allow_approx=not is_combo_name(name))
    if entry:
        return entry

    composition = (compositions or {}).get(str(code))
    if not composition:
        return None
    return nutrition_from_composition(composition, table)


def nutrition_from_composition(
    composition: dict[str, Any],
    table: dict[str, dict[str, Any]],
) -> dict[str, Any] | None:
    """按套餐的默认组成累加营养值。

    只使用 ``is_default`` 的选项；任一组成项在营养表里查不到就放弃，
    避免给出「只累加了一半」的误导性数字。
    """
    rounds = composition.get("rounds") or []
    if not rounds:
        return None

    totals = {field: 0.0 for field in _NUTRITION_FIELDS}
    parts: list[str] = []
    for rnd in rounds:
        selected = [
            choice
            for choice in (rnd.get("choices") or [])
            if int(choice.get("is_default") or 0) == 1
        ]
        if not selected:
            return None
        multiplier = sum(int(choice.get("quantity") or 0) for choice in selected)
        if multiplier <= 0:
            multiplier = int(rnd.get("quantity") or 1) or 1
        for choice in selected:
            item = lookup_nutrition(str(choice.get("name") or ""), table, allow_approx=True)
            if not item:
                return None
            for field in _NUTRITION_FIELDS:
                totals[field] += float(item.get(field) or 0) * multiplier
            parts.append(f"{choice.get('name')}×{multiplier}")

    return {
        **{field: round(value, 1) for field, value in totals.items()},
        "note": "",
        "match": "computed",
        "components": parts,
    }


# --------------------------------------------------------------------------- #
# 餐品组成（query-meal-detail）
# --------------------------------------------------------------------------- #
def parse_meal_detail(payload: Any) -> dict[str, Any] | None:
    """解析 ``query-meal-detail`` 的返回为前端可用的组成结构。"""
    data = ensure_mapping(_dig(payload, "data"))
    if not data:
        return None
    code = _as_str(data.get("code"))
    if not code:
        return None

    rounds: list[dict[str, Any]] = []
    for item in data.get("rounds") or []:
        if not isinstance(item, dict):
            continue
        choices = [
            {
                "name": _as_str(choice.get("name")),
                "code": _as_str(choice.get("code")),
                "is_default": _as_int(choice.get("isDefault")),
                "quantity": _as_int(choice.get("quantity")),
                "diff": _as_str(choice.get("diffPrice")),
            }
            for choice in (item.get("choices") or [])
            if isinstance(choice, dict) and _as_str(choice.get("name"))
        ]
        rounds.append(
            {
                "name": _as_str(item.get("name")),
                "quantity": _as_int(item.get("quantity")),
                "min_quantity": _as_int(item.get("minQuantity")),
                "max_quantity": _as_int(item.get("maxQuantity")),
                "choices": choices,
            }
        )

    modifiers: list[dict[str, Any]] = []
    modification = data.get("modification")
    if isinstance(modification, dict):
        for group in modification.get("items") or []:
            if not isinstance(group, dict):
                continue
            names = [
                _as_str(value.get("name"))
                for value in (group.get("values") or [])
                if isinstance(value, dict) and _as_str(value.get("name"))
            ]
            if names:
                modifiers.append(
                    {
                        "max_values": _as_int(group.get("maxValues")),
                        "min_values": _as_int(group.get("minValues")),
                        "values": names,
                    }
                )

    return {
        "code": code,
        "name": _as_str(data.get("name")),
        "image": _as_str(data.get("image")),
        "support_modify": _as_bool(data.get("supportModify")),
        "rounds": rounds,
        "modifiers": modifiers,
    }


# --------------------------------------------------------------------------- #
# 积分商城（mall-points-products）
# --------------------------------------------------------------------------- #
_POINT_PRICE_RE = re.compile(r"(?<![\d.])(\d+(?:\.\d+)?)\s*元")


def parse_points_mall(payload: Any) -> list[dict[str, Any]]:
    """解析 ``mall-points-products``：积分换购项（积分 + 指定金额）。"""
    data = _dig(payload, "data")
    if not isinstance(data, list):
        return []

    out: list[dict[str, Any]] = []
    for record in data:
        if not isinstance(record, dict):
            continue
        name = _as_str(record.get("spuName"))
        if not name:
            continue
        match = _POINT_PRICE_RE.search(name)
        out.append(
            {
                "spu_id": _as_int(record.get("spuId")),
                "name": name,
                "point": _as_float(record.get("point")),
                "cash": round(float(match.group(1)), 2) if match else None,
                "selling": _as_str(record.get("selling")),
                "image": _as_str(record.get("spuImage")),
                "category": _as_str(record.get("catName")),
                "status": _as_int(record.get("status")),
                "up_time": _as_str(record.get("upTime")),
                "down_time": _as_str(record.get("downTime")),
            }
        )
    return out
