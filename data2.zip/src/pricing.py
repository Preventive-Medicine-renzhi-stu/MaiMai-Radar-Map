"""优惠券的面值解析与匹配词提取。

在导出数据包时运行，把每张券的**可计算信息**前置好，前端只需做纯匹配：

* ``face_price``  券面上写明的固定价（如「9.9元中杯冰美式」→ 9.9）；
* ``kind``        ``fixed`` / ``free`` / ``bogo`` / ``unknown``；
* ``terms``       用于和购物车餐品名做匹配的关键词（含别名展开）。

**原则**：只从券标题里提取**已写明**的信息，不做任何金额猜测。
标题里没写价（如「麦旋风任选」）的一律归为 ``unknown``，前端只展示不预估。
"""

from __future__ import annotations

import re

# 「9.9元」「39.9 元」——前置负向断言避免把「卡路里199元」这类数字误判
_FACE_PRICE_RE = re.compile(r"(?<![\d.])(\d+(?:\.\d+)?)\s*元")

# 从标题里剔除的修饰词（剔除后剩下的才是餐品核心词）
_NOISE_WORDS: tuple[str, ...] = (
    "优惠券",
    "专享",
    "限定",
    "人气",
    "指定",
    "任选",
    "买一送一",
    "买1送1",
    "免费",
    "1份",
    "2份",
    "一份",
    "两份",
)

# 券标题常见别名 -> 菜单里可能出现的餐品关键词
ALIASES: dict[str, tuple[str, ...]] = {
    "薯薯": ("薯条", "薯饼", "薯"),
    "麦旋风": ("麦旋风",),
    "脆薯饼": ("薯饼",),
    "冰美式": ("美式",),
    "可乐": ("可乐",),
    "雪碧": ("雪碧",),
    "鸡块": ("鸡块", "麦乐鸡"),
    "鸡翅": ("鸡翅",),
    "派": ("派",),
    "冰淇淋": ("冰淇淋", "圆筒", "新地"),
}

# 规格词：餐品名里常带，匹配时应当忽略
_SIZE_WORDS: tuple[str, ...] = ("中杯", "大杯", "小杯", "迷你", "大", "中", "小")


def coupon_face_price(title: str) -> float | None:
    """从券标题里提取**明确写出的**价格；未写明则返回 None。"""
    if not title:
        return None
    if "买一送一" in title or "买1送1" in title:
        return None  # 一送一没有单一价，交给 kind=bogo 处理
    match = _FACE_PRICE_RE.search(title)
    if not match:
        return None
    try:
        return round(float(match.group(1)), 2)
    except ValueError:  # pragma: no cover - 正则已保证可转
        return None


def coupon_kind(title: str) -> str:
    """券的优惠形态。"""
    if not title:
        return "unknown"
    if "免费" in title or "0元" in title:
        return "free"
    if "买一送一" in title or "买1送1" in title:
        return "bogo"
    if coupon_face_price(title) is not None:
        return "fixed"
    return "unknown"


def coupon_terms(title: str) -> list[str]:
    """提取用于匹配购物车餐品的关键词（含别名与去规格词变体）。"""
    if not title:
        return []
    text = _FACE_PRICE_RE.sub("", title)
    for word in _NOISE_WORDS:
        text = text.replace(word, "")
    text = re.sub(r"[\s（）()·,，、/]+", "", text).strip()
    if not text:
        return []

    terms: list[str] = [text]

    # 去规格词（「中杯冰美式」→「冰美式」）
    stripped = text
    for size in _SIZE_WORDS:
        if stripped.startswith(size) and len(stripped) > len(size) + 1:
            stripped = stripped[len(size):]
            break
    if stripped and stripped not in terms:
        terms.append(stripped)

    # 别名展开
    for alias, expansions in ALIASES.items():
        if alias in text:
            for item in expansions:
                if item not in terms:
                    terms.append(item)
    return [t for t in terms if len(t) >= 2]


def coupon_applies_to(title: str, meal_name: str) -> bool:
    """券是否适用于某个餐品（纯名称匹配，不涉及金额）。"""
    if not title or not meal_name:
        return False
    for term in coupon_terms(title):
        if term in meal_name or meal_name in term:
            return True
    return False


def enrich_coupon(title: str) -> dict[str, object]:
    """导出给前端的券附加信息。"""
    return {
        "face_price": coupon_face_price(title),
        "kind": coupon_kind(title),
        "terms": coupon_terms(title),
    }
