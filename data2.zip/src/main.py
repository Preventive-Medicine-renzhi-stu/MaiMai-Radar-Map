"""麦麦雷达地图 —— 命令行入口。

    python -m src.main radar              # 生成今日/本周值得关注的活动
    python -m src.main calendar           # 打印完整活动日历
    python -m src.main coupons            # 盘点我的优惠券
    python -m src.main bind               # 一键领取可领优惠券
    python -m src.main web                # 导出前端数据包（Radar Map）
    python -m src.main web --serve        # 导出并启动本地预览服务
    python -m src.main web --demo         # 离线样例，无需 Token
"""

from __future__ import annotations

import argparse
import asyncio
import sys
import webbrowser
from datetime import date, datetime
from typing import Any

from . import __version__
from .config import ConfigError, Settings
from .demo_client import DemoMCPClient
from .mcp_client import HttpMCPClient, MCPToolError, ToolClient
from .parsers import parse_activities, parse_coupons
from .radar import build_radar
from .render import (
    render_calendar_markdown,
    render_coupons_markdown,
    render_radar_markdown,
    to_json,
)
from .serve import RadarApp, resolve_now, run_server
from .webexport import (
    DEFAULT_CITY,
    DEFAULT_KEYWORD,
    WEB_DIR,
    collect,
    write_assets,
)

COMMANDS = ("radar", "calendar", "coupons", "bind", "web")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mcd-radar",
        description="麦麦雷达地图：追踪麦当劳活动、优惠与门店，挑出值得关注的。",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument(
        "--demo",
        action="store_true",
        help="使用内置的真实快照数据，无需 MCP Token",
    )
    parser.add_argument("--json", action="store_true", help="以 JSON 输出（便于二次处理）")
    parser.add_argument("--top", type=int, default=8, help="雷达最多展示条数，默认 8")
    parser.add_argument("--city", default=DEFAULT_CITY, help=f"城市，默认 {DEFAULT_CITY}")
    parser.add_argument(
        "--keyword", default=DEFAULT_KEYWORD, help=f"位置关键词，默认 {DEFAULT_KEYWORD}"
    )
    parser.add_argument("--serve", action="store_true", help="web 命令：导出后启动本地预览服务")
    parser.add_argument("--port", type=int, default=8770, help="web 命令：预览端口，默认 8770")
    parser.add_argument("--open", action="store_true", help="web 命令：导出后自动打开浏览器")
    parser.add_argument(
        "--at",
        default="",
        help="把「当前时刻」固定为 HH:MM（用于演示高峰时段，如 --at 12:15）",
    )
    parser.add_argument(
        "command",
        nargs="?",
        default="radar",
        choices=COMMANDS,
        help="要执行的命令，默认 radar",
    )
    return parser


def _build_client(args: argparse.Namespace, city: str, keyword: str) -> ToolClient:
    if args.demo:
        return DemoMCPClient(city=city, keyword=keyword)
    return HttpMCPClient(Settings.load())


def _resolve_now(raw: str) -> datetime:
    """兼容旧调用：实现已统一到 :func:`src.serve.resolve_now`。"""
    return resolve_now(raw)


async def _run(args: argparse.Namespace) -> int:
    city = args.city
    keyword = args.keyword
    now = _resolve_now(args.at)
    client = _build_client(args, city, keyword)

    if args.command == "web":
        async with client:  # type: ignore[attr-defined]
            bundle = await collect(
                client, city=city, keyword=keyword, demo=args.demo, now=now
            )
        if args.at:
            bundle["scenario"] = f"{args.at} 时段场景"
        js_path, json_path = write_assets(bundle)
        stores = bundle["stores"]
        print(f"✅ 数据包已生成：{js_path.name} / {json_path.name}")
        print(f"   门店 {len(stores)} 家 ｜ 活动 {len(bundle['calendar'])} 天日历"
              f" ｜ 菜单覆盖 {len(bundle['menus'])} 店")
        print(f"   数据源：{'离线真实快照 (--demo)' if args.demo else '麦当劳 MCP 实时接口'}")
        print(f"   打开方式：{WEB_DIR / 'index.html'}")

        if args.serve:
            # 本地服务统一由 src.serve 提供（静态 + 城市实时切换 API），
            # 这里只负责把 CLI 参数翻译成它的配置。
            app = RadarApp(demo=args.demo, city=city, keyword=keyword, at=args.at)
            return run_server(app, port=args.port, open_browser=args.open)
        elif args.open:
            webbrowser.open((WEB_DIR / "index.html").as_uri())
        return 0

    async with client:  # type: ignore[attr-defined]
        if args.command == "bind":
            result = await client.call("auto-bind-coupons", {})
            text = result if isinstance(result, str) else to_json(result)
            _emit(args, f"# 一键领券\n\n{text}\n", {"result": result})
            return 0

        coupons = parse_coupons(await client.call("available-coupons", {}))

        if args.command == "coupons":
            _emit(
                args,
                render_coupons_markdown(coupons),
                {"count": len(coupons), "coupons": [_coupon_dict(c) for c in coupons]},
            )
            return 0

        raw_activities = await client.call("campaign-calendar", {})
        activities = parse_activities(raw_activities, today=date.today())

        if args.command == "calendar":
            _emit(
                args,
                render_calendar_markdown(activities),
                {"count": len(activities), "activities": [_activity_dict(a) for a in activities]},
            )
            return 0

        items = build_radar(activities, coupons, today=date.today(), top=args.top)
        payload: dict[str, Any] = {
            "date": date.today().isoformat(),
            "demo": args.demo,
            "items": [
                {
                    "rank": rank,
                    "score": item.score,
                    "reasons": item.reasons,
                    **_activity_dict(item.activity),
                }
                for rank, item in enumerate(items, start=1)
            ],
        }
        _emit(args, render_radar_markdown(items, date.today(), demo=args.demo), payload)
        return 0


def _emit(args: argparse.Namespace, markdown: str, payload: Any) -> None:
    print(to_json(payload) if args.json else markdown)


def _activity_dict(activity: Any) -> dict[str, Any]:
    return {
        "date": activity.date,
        "title": activity.title,
        "body": activity.body,
        "image": activity.image,
        "status": activity.status,
    }


def _coupon_dict(coupon: Any) -> dict[str, Any]:
    return {"title": coupon.title, "status": coupon.status, "image": coupon.image}


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return asyncio.run(_run(args))
    except ConfigError as exc:
        print(f"配置错误：{exc}", file=sys.stderr)
        return 2
    except MCPToolError as exc:
        print(f"MCP 工具错误：{exc}", file=sys.stderr)
        return 3
    except KeyboardInterrupt:
        print("已取消。", file=sys.stderr)
        return 130
    except Exception as exc:  # noqa: BLE001 - 顶层兜底，避免向用户抛裸栈
        print(f"运行失败：{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
