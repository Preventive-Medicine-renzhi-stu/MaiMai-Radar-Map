"""配置加载：从环境变量 / .env 读取麦当劳 MCP 凭据。"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

try:  # dotenv 为可选依赖，缺失时仅依赖真实环境变量
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    load_dotenv = None  # type: ignore[assignment]

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MCP_URL = "https://mcp.mcd.cn"
DEFAULT_TIMEOUT = 30.0


class ConfigError(RuntimeError):
    """配置缺失或非法。"""


def _load_env() -> None:
    """载入 .env（若存在）。override=False 保证不覆盖真实环境变量。"""
    if load_dotenv is not None:
        load_dotenv(PROJECT_ROOT / ".env", override=False)


def load_tmap_key() -> str:
    """读取**可选**的腾讯位置服务 Key（Web 端）。

    缺失时返回空串——此时前端会自动回退到 WorkBuddy 预览代理模式，
    因此这里不抛异常，保证「没有地图 Key 也能跑通」。
    """
    _load_env()
    return os.environ.get("TMAP_KEY", "").strip()


@dataclass(frozen=True)
class Settings:
    """运行期配置。"""

    mcp_url: str
    mcp_token: str
    timeout: float

    @classmethod
    def load(cls) -> "Settings":
        _load_env()

        token = os.environ.get("MCD_MCP_TOKEN", "").strip()
        if not token:
            raise ConfigError(
                "缺少环境变量 MCD_MCP_TOKEN。"
                "请复制 .env.example 为 .env 并填入 Token，或加 --demo 用离线样例运行。"
            )

        url = os.environ.get("MCD_MCP_URL", "").strip() or DEFAULT_MCP_URL
        raw_timeout = os.environ.get("MCD_MCP_TIMEOUT", "").strip()
        try:
            timeout = float(raw_timeout) if raw_timeout else DEFAULT_TIMEOUT
        except ValueError as exc:
            raise ConfigError(f"MCD_MCP_TIMEOUT 必须是数字，当前值：{raw_timeout!r}") from exc

        return cls(mcp_url=url, mcp_token=token, timeout=timeout)

    def auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.mcp_token}"}
