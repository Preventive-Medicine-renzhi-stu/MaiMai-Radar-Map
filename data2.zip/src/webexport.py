"""把 MCP 数据导出为前端可用的数据包。

产出两个文件（内容一致，用途不同）：

* ``web/data.js``  —— ``window.MCD_DATA = {...}``，用 ``<script>`` 加载，
  **双击直接打开 index.html 也能读到数据**（绕开 file:// 的 fetch 限制）；
* ``web/data.json`` —— 给需二次处理 / 静态托管用的标准 JSON。

用法::

    python -m src.main web --demo          # 离线样例
    python -m src.main web --city 深圳 --keyword 腾讯滨海大厦
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from .catalog import (
    parse_account,
    parse_meal_detail,
    parse_meals,
    parse_nutrition,
    parse_orders,
    parse_points_mall,
    parse_store_coupons,
    parse_stores,
)
from .config import PROJECT_ROOT, load_tmap_key
from .mcp_client import ToolClient
from .parsers import parse_activities, parse_coupons
from .store_radar import build_bundle

WEB_DIR = PROJECT_ROOT / "web"
DEFAULT_CITY = "深圳"
DEFAULT_KEYWORD = "腾讯滨海大厦"
MAX_STORES = 8
MAX_COMPOSITIONS = 8
TMAP_KEY_FILE = "tmap-key.local.js"

# 优先抓取「组成」的餐品：套餐类信息量最大，先抓它们
_COMBO_HINTS = ("套餐", "三件套", "四件套", "两件套", "随心配", "随心拼", "堡堡")


async def collect(
    client: ToolClient,
    city: str = DEFAULT_CITY,
    keyword: str = DEFAULT_KEYWORD,
    be_type: int = 1,
    now: datetime | None = None,
    demo: bool = False,
    max_stores: int = MAX_STORES,
) -> dict[str, Any]:
    """拉取全部所需数据并组装成前端数据包。"""
    now = now or datetime.now()

    raw_stores = await client.call(
        "query-nearby-stores",
        {"searchType": 2, "city": city, "keyword": keyword, "beType": be_type},
    )
    stores = parse_stores(raw_stores, be_type=be_type, city=city)[:max_stores]

    menus_by_store: dict[str, list[Any]] = {}
    for store in stores:
        arguments: dict[str, Any] = {
            "storeCode": store.store_code,
            "orderType": 1,
            "beType": store.be_type,
        }
        if store.be_type != 1 and store.be_code:
            arguments["beCode"] = store.be_code
        try:
            raw_menu = await client.call("query-meals", arguments)
        except Exception:  # noqa: BLE001 - 单店菜单失败不应拖垮整体
            menus_by_store[store.store_code] = []
            continue
        menus_by_store[store.store_code] = parse_meals(raw_menu)

    raw_activities = await client.call("campaign-calendar", {})
    activities = parse_activities(raw_activities, today=now.date())

    coupons = parse_coupons(await client.call("available-coupons", {}))
    orders = parse_orders(await client.call("order-list", {}))
    account = parse_account(await client.call("query-my-account", {}))

    store_coupons = []
    if stores:
        try:
            raw_coupons = await client.call(
                "query-store-coupons",
                {"storeCode": stores[0].store_code, "orderType": 1, "beType": stores[0].be_type},
            )
            store_coupons = parse_store_coupons(raw_coupons)
        except Exception:  # noqa: BLE001 - 券接口失败不影响主流程
            store_coupons = []

    # 营养成分：一次拉全量，导出时按名称就近匹配
    try:
        nutrition = parse_nutrition(await client.call("list-nutrition-foods", {}))
    except Exception:  # noqa: BLE001
        nutrition = {}

    # 积分换购：用于结算页推荐「积分 + 金额」的最优花法
    try:
        points_mall = parse_points_mall(
            await client.call("mall-points-products", {"catRuleIds": "1>4"})
        )
    except Exception:  # noqa: BLE001
        points_mall = []

    compositions = await _collect_compositions(client, stores, menus_by_store)

    return build_bundle(
        city=city,
        keyword=keyword,
        stores=stores,
        menus_by_store=menus_by_store,
        activities=activities,
        coupons=coupons,
        store_coupons=store_coupons,
        orders=orders,
        account=account,
        now=now,
        demo=demo,
        location={"city": city, "keyword": keyword},
        nutrition=nutrition,
        compositions=compositions,
        points_mall=points_mall,
    )


async def _collect_compositions(
    client: ToolClient,
    stores: list[Any],
    menus_by_store: dict[str, list[Any]],
    limit: int = MAX_COMPOSITIONS,
) -> dict[str, dict[str, Any]]:
    """抓取部分餐品的「组成」（query-meal-detail）。

    只在**首店**抓取、且**限量**——组成本身是门店无关的静态结构，
    全量抓取既慢又无必要；优先抓套餐，信息量最大。
    """
    if not stores:
        return {}
    menu = menus_by_store.get(stores[0].store_code) or []
    if not menu:
        return {}

    ranked = sorted(
        menu,
        key=lambda meal: (
            0 if any(hint in meal.name for hint in _COMBO_HINTS) else 1,
            -len(meal.name),
        ),
    )

    out: dict[str, dict[str, Any]] = {}
    for meal in ranked:
        if len(out) >= limit:
            break
        try:
            raw = await client.call(
                "query-meal-detail",
                {
                    "storeCode": stores[0].store_code,
                    "orderType": 1,
                    "beType": stores[0].be_type,
                    "code": meal.code,
                },
            )
        except Exception:  # noqa: BLE001 - 单个餐品失败不影响整体
            continue
        detail = parse_meal_detail(raw)
        if detail and (detail["rounds"] or detail["modifiers"]):
            out[detail["code"]] = detail
    return out


def write_assets(bundle: dict[str, Any], web_dir: Path | None = None) -> tuple[Path, Path]:
    """写出 data.js / data.json，并按需写出本土地图 Key 文件，返回前两者路径。

    地图 Key **不写进 data.js**——因为 data.js 是要提交进仓库的（评审无需 Token
    即可打开页面看效果），写进去等于直接泄露 Key。因此单独落到
    ``web/tmap-key.local.js``，该文件已被 .gitignore 排除。
    """
    web_dir = web_dir or WEB_DIR
    web_dir.mkdir(parents=True, exist_ok=True)

    payload = json.dumps(bundle, ensure_ascii=False, separators=(",", ":"))
    js_path = web_dir / "data.js"
    json_path = web_dir / "data.json"

    js_path.write_text(
        "// 由 `python -m src.main web` 自动生成，请勿手工编辑。\n"
        f"// 生成时间：{bundle.get('generated_at', '')}\n"
        f"window.MCD_DATA = {payload};\n",
        encoding="utf-8",
    )
    json_path.write_text(payload, encoding="utf-8")
    _write_tmap_key(web_dir)
    return js_path, json_path


def _write_tmap_key(web_dir: Path) -> Path | None:
    """把 TMAP_KEY 落到本地独立文件；未配置时清除旧文件，避免误用过期 Key。"""
    key_path = web_dir / TMAP_KEY_FILE
    key = load_tmap_key()
    if not key:
        if key_path.exists():
            key_path.unlink()
        return None
    key_path.write_text(
        "// 由 `python -m src.main web` 依据 .env 的 TMAP_KEY 自动生成，请勿提交。\n"
        f"window.__TMAP_KEY__ = {json.dumps(key)};\n",
        encoding="utf-8",
    )
    return key_path
