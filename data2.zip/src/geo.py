"""地理与运营指标推算。

⚠️ 重要说明（诚实性设计）
------------------------
麦当劳 MCP **不提供**以下数据：门店实时排队长度、门店经纬度（恒返回 0.0）、
单店库存水位。因此本模块中：

* **真实数据**：门店距离、营业状态、营业时间、菜单（含限时商品是否有售）；
* **模型推算**：到店耗时（距离 ÷ 交通方式速度）、门店繁忙度 / 取餐等待
  （时段客流模型 + 门店因子）。

所有推算结果都会带上 ``is_estimate=True`` 标记，前端以「预估」角标呈现，
不冒充实时数据。真实部署时把 :func:`estimate_busy` 换成真实的排队/叫号接口即可。
"""

from __future__ import annotations

import hashlib
from datetime import date, datetime, time, timedelta

from .models import BusyEstimate, Store, StoreStatus, TravelEstimate

# --------------------------------------------------------------------------- #
# 到店耗时
# --------------------------------------------------------------------------- #
# 速度（米 / 分钟）
SPEED_WALK = 80.0  # ≈ 4.8 km/h
SPEED_RIDE = 260.0  # ≈ 15.6 km/h（共享单车 / 电动车）
SPEED_DRIVE = 500.0  # ≈ 30 km/h（城市道路含红灯）

MODE_LABELS = {"walk": "步行", "ride": "骑行", "drive": "驾车/打车"}

# 超过该距离就不建议步行
WALK_LIMIT_M = 1200


def pick_mode(distance_m: int) -> str:
    """按距离挑一个默认交通方式。"""
    if distance_m <= WALK_LIMIT_M:
        return "walk"
    if distance_m <= 4000:
        return "ride"
    return "drive"


def estimate_travel(distance_m: int, mode: str | None = None) -> TravelEstimate:
    """推算到店耗时。"""
    distance_m = max(0, int(distance_m))
    mode = mode or pick_mode(distance_m)
    speed = {"walk": SPEED_WALK, "ride": SPEED_RIDE, "drive": SPEED_DRIVE}.get(mode, SPEED_RIDE)
    minutes = max(1, round(distance_m / speed))
    return TravelEstimate(minutes=minutes, mode=mode, mode_label=MODE_LABELS.get(mode, mode))


def distance_label(distance_m: int) -> str:
    if distance_m < 1000:
        return f"{distance_m}m"
    return f"{distance_m / 1000:.1f}km"


# --------------------------------------------------------------------------- #
# 门店繁忙度（模型推算）
# --------------------------------------------------------------------------- #
# (起始时: 分, 结束时: 分, 权重 0~1, 名称)
_PEAK_WINDOWS: tuple[tuple[int, int, float, str], ...] = (
    (7 * 60, 9 * 60 + 30, 0.70, "早餐高峰"),
    (11 * 60 + 30, 13 * 60 + 30, 1.00, "午市高峰"),
    (14 * 60, 16 * 60 + 30, 0.45, "下午茶"),
    (17 * 60 + 30, 19 * 60 + 30, 0.90, "晚市高峰"),
    (21 * 60 + 30, 23 * 60 + 59, 0.50, "宵夜时段"),
)

BASE_QUEUE_MINUTES = 2.0


def _store_factor(store_code: str) -> float:
    """门店因子：0.80 ~ 1.35。

    用门店编号哈希出稳定值 —— 同一门店在任何时间推算结果一致，
    不同门店之间有差异（模拟商圈/门店规模差异）。真实部署应替换为
    门店历史订单量 / 出餐能力等真实指标。
    """
    digest = hashlib.sha256(store_code.encode("utf-8")).digest()
    ratio = int.from_bytes(digest[:4], "big") / 0xFFFFFFFF
    return round(0.80 + ratio * 0.55, 3)


def current_peak(now: datetime) -> tuple[float, str]:
    """当前时段客流权重。"""
    minutes = now.hour * 60 + now.minute
    for start, end, weight, name in _PEAK_WINDOWS:
        if start <= minutes <= end:
            return weight, name
    return 0.20, "非高峰"


def estimate_busy(store: Store, now: datetime | None = None) -> BusyEstimate:
    """推算门店繁忙度与取餐等待（模型估值）。"""
    now = now or datetime.now()
    if not store.business_status:
        return BusyEstimate(
            score=0,
            label="未营业",
            queue_minutes=0,
            factors=("门店当前处于休息状态",),
        )

    weight, window = current_peak(now)
    factor = _store_factor(store.store_code)

    score = int(min(100.0, round(weight * 70.0 * factor + 8.0)))
    queue = round((BASE_QUEUE_MINUTES + weight * 7.0 * factor) * 10) / 10

    if score >= 72:
        label = "极度繁忙"
    elif score >= 52:
        label = "偏忙"
    elif score >= 28:
        label = "正常"
    else:
        label = "空闲"

    factors = [f"{window}（权重 {weight:.2f}）", f"门店客流因子 ×{factor:.2f}"]
    if store.reservation:
        factors.append("支持预约取餐")
    return BusyEstimate(
        score=score,
        label=label,
        queue_minutes=int(round(queue)),
        factors=tuple(factors),
    )


def store_status(store: Store, now: datetime | None = None, mode: str | None = None) -> StoreStatus:
    """门店综合状态。"""
    travel = estimate_travel(store.distance, mode)
    busy = estimate_busy(store, now)
    total = travel.minutes + busy.queue_minutes
    return StoreStatus(
        store=store,
        travel=travel,
        busy=busy,
        pickup_minutes=busy.queue_minutes,
    )


def is_open_at(store: Store, moment: datetime) -> bool:
    """按营业时间判断门店此刻是否在营业（处理跨天营业，如 06:00-02:00）。"""
    if not store.open_time or not store.close_time:
        return store.business_status
    try:
        oh, om = (int(x) for x in store.open_time.split(":"))
        ch, cm = (int(x) for x in store.close_time.split(":"))
    except (ValueError, AttributeError):
        return store.business_status

    open_at = time(oh, om)
    close_at = time(ch, cm)
    now = moment.time()
    if open_at <= close_at:
        return open_at <= now <= close_at
    # 跨天：例如 06:00 - 02:00
    return now >= open_at or now <= close_at


# --------------------------------------------------------------------------- #
# 雷达图布局（无经纬度时的相对定位）
# --------------------------------------------------------------------------- #
def radial_layout(count: int) -> list[tuple[float, float]]:
    """把 count 个点均匀撒在一个圆上，返回 (角度°, 归一化半径 0~1)。

    第 0 个点固定在正上方（-90°），顺时针排布，符合「雷达」直觉。
    """
    if count <= 0:
        return []
    if count == 1:
        return [(0.0, 0.6)]
    out: list[tuple[float, float]] = []
    for index in range(count):
        angle = -90.0 + 360.0 * index / count
        out.append((angle, 1.0))
    return out


# --------------------------------------------------------------------------- #
# 未来 N 天活动日历
# --------------------------------------------------------------------------- #
def build_calendar_days(
    activities: list[object],
    days: int = 7,
    today: date | None = None,
) -> list[dict[str, object]]:
    """把活动按「未来 N 天」归拢成日历条。

    返回每天一条：``{date, weekday, label, is_today, is_weekend, count, activities}``。
    没有活动的日期也会保留（``count=0``），方便前端把时间轴画满。
    """
    today = today or date.today()
    by_date: dict[str, list[dict[str, object]]] = {}
    for activity in activities:
        date_str = getattr(activity, "date", "") or ""
        if not date_str:
            continue
        by_date.setdefault(date_str, []).append(
            {
                "date": date_str,
                "title": getattr(activity, "title", ""),
                "body": getattr(activity, "body", ""),
                "image": getattr(activity, "image", ""),
                "status": getattr(activity, "status", "unknown"),
            }
        )

    weekdays = ("周一", "周二", "周三", "周四", "周五", "周六", "周日")
    out: list[dict[str, object]] = []
    for offset in range(days):
        day = today + timedelta(days=offset)
        key = day.isoformat()
        items = by_date.get(key, [])
        out.append(
            {
                "date": key,
                "month_day": f"{day.month}/{day.day}",
                "weekday": weekdays[day.weekday()],
                "label": "今天" if offset == 0 else ("明天" if offset == 1 else weekdays[day.weekday()]),
                "is_today": offset == 0,
                "is_weekend": day.weekday() >= 5,
                "count": len(items),
                "activities": items,
            }
        )
    return out
