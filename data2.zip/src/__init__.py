"""麦麦活动雷达（McDonald's Campaign Radar）。

基于麦当劳 MCP 能力，把官方活动日历与个人优惠券对齐，
挑出当下真正值得关注的活动。
"""

__version__ = "0.1.0"
