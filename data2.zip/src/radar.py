"""活动雷达核心逻辑。

把「官方活动日历」与「我的优惠券」对齐，按关注度打分，挑出值得看的活动。
关注度 = 时间新鲜度 + 亮点关键词 + 是否能用上我手上的券。
"""

from __future__ import annotations

import re
from datetime import date

from .models import Activity, Coupon, RadarItem

# 亮点关键词 -> 加分
HIGHLIGHTS: dict[str, float] = {
    "新品": 12,
    "上新": 12,
    "联名": 10,
    "限量": 10,
    "开售": 8,
    "买一送一": 10,
    "免费": 10,
    "抽奖": 8,
    "半价": 10,
    "5折": 10,
    "6折": 10,
    "9.9元": 8,
    "会员": 5,
    "专享": 5,
    "回归": 6,
}

STATUS_BASE: dict[str, float] = {
    "today": 40.0,
    "upcoming": 25.0,
    "past": 0.0,
    "unknown": 15.0,
}

_NORM_RE = re.compile(r"[^0-9A-Za-z\u4e00-\u9fff]+")


def build_radar(
    activities: list[Activity],
    coupons: list[Coupon],
    today: date | None = None,
    top: int | None = None,
    include_past: bool = False,
) -> list[RadarItem]:
    """对活动打分并排序，返回雷达条目。"""
    today = today or date.today()
    coupon_titles = [coupon.title for coupon in coupons if coupon.title]

    items: list[RadarItem] = []
    for activity in activities:
        if activity.status == "past" and not include_past:
            continue
        score, reasons = _score(activity, today, coupon_titles)
        items.append(RadarItem(activity=activity, score=score, reasons=reasons))

    items.sort(key=lambda item: (-item.score, item.activity.date or "9999"))
    return items[:top] if top else items


def _score(
    activity: Activity, today: date, coupon_titles: list[str]
) -> tuple[float, list[str]]:
    score = STATUS_BASE.get(activity.status, 15.0)
    reasons: list[str] = []

    if activity.status == "today":
        reasons.append("今日进行中")
    elif activity.status == "upcoming":
        days = _days_until(activity.date, today)
        if days is None:
            reasons.append("即将开始")
        else:
            reasons.append(f"{days} 天后开始")
            score += max(0.0, 10.0 - days)

    text = f"{activity.title} {activity.body}"
    hits = _match_highlights(text)
    if hits:
        score += min(30.0, sum(weight for _, weight in hits))
        reasons.append("亮点：" + "、".join(keyword for keyword, _ in hits[:3]))

    matched = _matched_coupons(activity, coupon_titles)
    if matched:
        score += 8.0
        reasons.append("可用券：" + "、".join(matched[:2]))

    return round(score, 1), reasons


def _match_highlights(text: str) -> list[tuple[str, float]]:
    """匹配亮点关键词。

    以数字开头的关键词（如 9.9元 / 5折）加负向后顾，避免被 29.9元、15折 之类误命中。
    """
    hits: list[tuple[str, float]] = []
    for keyword, weight in HIGHLIGHTS.items():
        pattern = re.escape(keyword)
        if keyword[:1].isdigit():
            pattern = r"(?<![\d.])" + pattern
        if re.search(pattern, text):
            hits.append((keyword, weight))
    hits.sort(key=lambda pair: -pair[1])
    return hits


def _matched_coupons(activity: Activity, coupon_titles: list[str]) -> list[str]:
    haystack = _bigrams(_norm(f"{activity.title}{activity.body}"))
    if not haystack:
        return []
    matched: list[str] = []
    for title in coupon_titles:
        grams = _bigrams(_norm(title))
        if grams and len(grams & haystack) / len(grams) >= 0.5:
            matched.append(title)
    return matched


def _days_until(date_str: str, today: date) -> int | None:
    try:
        target = date.fromisoformat(date_str)
    except (ValueError, TypeError):
        return None
    return (target - today).days


def _norm(text: str) -> str:
    return _NORM_RE.sub("", text).lower()


def _bigrams(text: str) -> set[str]:
    if len(text) < 2:
        return set()
    return {text[index : index + 2] for index in range(len(text) - 1)}
