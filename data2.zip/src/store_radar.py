"""麦麦雷达地图 —— 三种模式的业务逻辑。

* **模式一 · 就近 / 常客**：按距离或「我点过最多餐的门店」排序，服务普通就餐顾客。
* **模式二 · 追新 / 粉丝**：把限时活动与**各门店菜单**对齐，回答「哪些店有售这个新品 /
  周边什么时候发售」，服务想抢限时周边的麦麦粉丝。
* **模式三 · 极速**：先填要买的商品 → 推算各门店「到达 + 取餐」总耗时 → 推荐最快取餐
  的门店，并在库存/排队不利时提示；同时给出极速套餐与历史订单（原价 vs 到手价）。
"""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Any, Iterable, Sequence

from .geo import (
    build_calendar_days,
    distance_label,
    estimate_busy,
    estimate_travel,
    pick_mode,
    store_status,
)
from . import cities, descriptions, pricing
from .catalog import resolve_nutrition
from .models import Activity, Coupon, Meal, OrderRecord, Store, StoreCoupon

# --------------------------------------------------------------------------- #
# 关键词
# --------------------------------------------------------------------------- #
# 周边 / 联名类活动关键词 —— 判定「限时周边」
GIFT_KEYWORDS: tuple[str, ...] = (
    "周边",
    "联名",
    "限量",
    "徽章",
    "丝巾",
    "棒球帽",
    "搪胶",
    "玩具",
    "礼盒",
    "加39.9元",
    "加 39.9 元",
)

# 活动里暗示「上新 / 限时」的词
LAUNCH_KEYWORDS: tuple[str, ...] = ("上新", "新品", "开售", "首发", "回归", "限定", "限时", "即将")

# 套餐类后缀 —— 单个商品码即可出餐，通常更快
_COMBO_SUFFIXES: tuple[str, ...] = (
    "三件套",
    "四件套",
    "两件套",
    "双人餐",
    "单人餐",
    "套餐",
    "随心选",
    "随心配",
    "早餐两件套",
)

_DELIVERY_WORDS: tuple[str, ...] = ("外送", "麦乐送", "配送")


def travel_options(distance_m: int) -> list[dict[str, Any]]:
    """同一段距离下，步行 / 骑行 / 驾车各自的预计耗时。

    为什么要一次给三种：用户问的是「步行或者开车距离与抵达时间」——
    只给一个「默认推荐方式」会让人以为自己看错了（明明想开车，界面却写步行）。
    前端可以并排画出来，由用户自己选。
    """
    out: list[dict[str, Any]] = []
    for mode in ("walk", "ride", "drive"):
        est = estimate_travel(distance_m, mode)
        out.append(
            {
                "mode": est.mode,
                "label": est.mode_label,
                "minutes": est.minutes,
                "recommended": est.mode == pick_mode(distance_m),
            }
        )
    return out


# --------------------------------------------------------------------------- #
# 模式一 · 就近 / 常客
# --------------------------------------------------------------------------- #
def build_nearby_mode(
    stores: Sequence[Store],
    orders: Sequence[OrderRecord] = (),
    now: datetime | None = None,
    sort: str = "distance",
) -> dict[str, Any]:
    """模式一：列出门店，按距离或历史消费频次排序。"""
    frequency: dict[str, int] = {}
    last_order: dict[str, str] = {}
    for order in orders:
        if not order.store_code:
            continue
        frequency[order.store_code] = frequency.get(order.store_code, 0) + 1
        stamp = order.create_time
        if stamp and stamp > last_order.get(order.store_code, ""):
            last_order[order.store_code] = stamp

    rows: list[dict[str, Any]] = []
    for store in stores:
        status = store_status(store, now)
        count = frequency.get(store.store_code, 0)
        badges: list[str] = []
        if count:
            badges.append(f"你在这里点过 {count} 次")
        if count >= 2:
            badges.append("常去门店")
        if store.reservation:
            badges.append("支持预约")
        if status.travel.is_walkable:
            badges.append("步行可达")
        rows.append(
            {
                **_store_payload(store),
                "distance_label": distance_label(store.distance),
                "travel_minutes": status.travel.minutes,
                "travel_mode": status.travel.mode,
                "travel_label": status.travel.mode_label,
                "travel_options": travel_options(store.distance),
                "busy_score": status.busy.score,
                "busy_label": status.busy.label,
                "queue_minutes": status.busy.queue_minutes,
                "total_minutes": status.total_minutes,
                "order_count": count,
                "last_order_time": last_order.get(store.store_code, ""),
                "badges": badges,
                "orderable": status.orderable,
            }
        )

    if sort == "frequent":
        rows.sort(key=lambda r: (-r["order_count"], r["distance"]))
        if not any(row["order_count"] for row in rows):
            # 附近门店没有历史消费记录 —— 如实告知，并回落到距离排序
            sort = "frequent_fallback"
            rows.sort(key=lambda r: r["distance"])
    else:
        rows.sort(key=lambda r: r["distance"])
        sort = "distance"

    for rank, row in enumerate(rows, start=1):
        row["rank"] = rank
    return {"sort": sort, "stores": rows}


# --------------------------------------------------------------------------- #
# 模式二 · 追新 / 粉丝
# --------------------------------------------------------------------------- #
def build_newest_mode(
    activities: Sequence[Activity],
    stores: Sequence[Store],
    menus_by_store: dict[str, Sequence[Meal]],
    today: date | None = None,
    days: int = 7,
) -> dict[str, Any]:
    """模式二：限时活动 × 门店菜单，回答「哪家店有货 / 周边何时开售」。"""
    today = today or date.today()

    # 全量餐品池（按 code 去重，保留最新看到的价格）
    all_meals: dict[str, Meal] = {}
    for meals in menus_by_store.values():
        for meal in meals:
            all_meals.setdefault(meal.code, meal)

    active: list[Activity] = [a for a in activities if a.status in ("today", "upcoming")]
    active.sort(key=lambda a: (a.date or "9999", a.title))

    cards: list[dict[str, Any]] = []
    gifts: list[dict[str, Any]] = []
    for activity in active:
        text = f"{activity.title} {activity.body}"
        days_until = _days_until(activity.date, today)
        # 只关注未来 N 天内
        if days_until is not None and days_until > days:
            continue

        matched = _match_meals(text, all_meals.values())
        availability = _availability(matched, menus_by_store)
        is_gift = any(keyword in text for keyword in GIFT_KEYWORDS)
        launch = [keyword for keyword in LAUNCH_KEYWORDS if keyword in text]

        card = {
            "date": activity.date,
            "date_label": activity.date.replace("-", "/")[5:] if activity.date else "",
            "days_until": days_until,
            "title": activity.title,
            "body": activity.body,
            "image": activity.image,
            "status": activity.status,
            "is_gift": is_gift,
            "launch_tags": launch,
            "products": availability,
            "store_count": len({s for item in availability for s in item["stores"]}),
        }
        cards.append(card)

        if is_gift:
            gifts.append(
                {
                    "date": activity.date,
                    "days_until": days_until,
                    "title": activity.title,
                    "image": activity.image,
                    "tags": launch or ["限时周边"],
                }
            )

    cards.sort(key=lambda c: (c["days_until"] if c["days_until"] is not None else 999, c["title"]))
    gifts.sort(key=lambda g: (g["days_until"] if g["days_until"] is not None else 999))

    return {
        "activities": cards,
        "gifts": gifts,
        "store_count": len(stores),
        "product_count": len(all_meals),
        "days": days,
    }


def _availability(
    matched: Sequence[Meal],
    menus_by_store: dict[str, Sequence[Meal]],
) -> list[dict[str, Any]]:
    """某个活动关联的餐品，在哪些门店有售。"""
    out: list[dict[str, Any]] = []
    for meal in matched[:6]:
        stores = [
            code
            for code, meals in menus_by_store.items()
            if any(item.code == meal.code for item in meals)
        ]
        out.append(
            {
                "code": meal.code,
                "name": meal.name,
                "price": meal.price,
                "original_price": meal.original_price,
                "image": meal.image,
                "stores": stores,
                "store_count": len(stores),
                "partial": len(stores) < len(menus_by_store),
            }
        )
    return out


def _match_meals(text: str, meals: Iterable[Meal]) -> list[Meal]:
    """从活动文案里找出提到的餐品。"""
    hits: list[Meal] = []
    for meal in meals:
        if any(core in text for core in _meal_cores(meal.name)):
            hits.append(meal)
    # 名称越长越具体，优先展示
    hits.sort(key=lambda m: -len(m.name))
    return hits


def _meal_cores(name: str) -> set[str]:
    """生成餐品的「核心词」，用于在活动文案里做匹配。

    例：「龙焰鸡腿堡三件套」→ {龙焰鸡腿堡三件套, 龙焰鸡腿堡}
    """
    cores: set[str] = set()
    base = re.sub(r"[（(].*?[)）]", "", name).strip()
    cores.add(base)

    for suffix in _COMBO_SUFFIXES:
        if base.endswith(suffix):
            trimmed = base[: -len(suffix)].strip()
            if len(trimmed) >= 4:
                cores.add(trimmed)
            break
    return {core for core in cores if len(core) >= 4}


# --------------------------------------------------------------------------- #
# 模式三 · 极速
# --------------------------------------------------------------------------- #
def build_speed_mode(
    stores: Sequence[Store],
    menus_by_store: dict[str, Sequence[Meal]],
    orders: Sequence[OrderRecord] = (),
    store_coupons: Sequence[StoreCoupon] = (),
    selected: Sequence[dict[str, Any]] = (),
    now: datetime | None = None,
) -> dict[str, Any]:
    """模式三：先选商品，再算「哪家店最快能拿到」。"""
    now = now or datetime.now()
    selected = list(selected)

    rows: list[dict[str, Any]] = []
    for store in stores:
        status = store_status(store, now)
        menu = {meal.code: meal for meal in menus_by_store.get(store.store_code, ())}
        missing = [code for code in (item["code"] for item in selected) if code not in menu]
        notes: list[str] = []

        if not store.business_status:
            notes.append("门店当前未营业")
        if status.busy.label == "极度繁忙":
            notes.append(f"该店当前预估{status.busy.label}，排队约 {status.busy.queue_minutes} 分钟")
        if status.store.reservation:
            notes.append("支持预约，可提前锁定取餐时间")
        for code in missing:
            name = _selected_name(selected, code)
            notes.append(f"「{name}」该店菜单中暂无售")

        rows.append(
            {
                **_store_payload(store),
                "distance_label": distance_label(store.distance),
                "travel_minutes": status.travel.minutes,
                "travel_label": status.travel.mode_label,
                "travel_mode": status.travel.mode,
                "travel_options": travel_options(store.distance),
                "busy_score": status.busy.score,
                "busy_label": status.busy.label,
                "queue_minutes": status.busy.queue_minutes,
                "total_minutes": status.total_minutes,
                "missing_count": len(missing),
                "notes": notes,
                "orderable": status.orderable and not missing,
            }
        )
    # 排序：可下单优先 → 总耗时短优先
    rows.sort(key=lambda r: (not r["orderable"], r["total_minutes"], r["distance"]))

    best = rows[0] if rows else None
    reference = next((r for r in rows if r["distance"] == min(x["distance"] for x in rows)), None)

    warnings: list[str] = []
    if reference and best and reference["store_code"] != best["store_code"]:
        gap = reference["total_minutes"] - best["total_minutes"]
        if gap > 0:
            warnings.append(
                f"最近的门店是「{reference['name']}」，但它在 {reference['busy_label']} 状态下"
                f"预计要多等约 {gap} 分钟；「{best['name']}」综合更快。"
            )
    if best and best["busy_label"] == "极度繁忙":
        warnings.append(f"综合最优的「{best['name']}」当前也处于极度繁忙，建议预约取餐。")
    if best and best["missing_count"]:
        warnings.append(f"「{best['name']}」有 {best['missing_count']} 件所选商品不可售，已排到后面。")

    any_store = next(iter(menus_by_store.values()), [])
    return {
        "stores": rows,
        "best_store_code": best["store_code"] if best else "",
        "selected": selected,
        "warnings": warnings,
        "fast_combo": _fast_combo(any_store),
        "history": _history_pin(orders, any_store),
        "coupons": [
            {
                "title": coupon.title,
                "coupon_code": coupon.coupon_code,
                "valid_to": coupon.valid_to,
                "products": list(coupon.product_names),
            }
            for coupon in store_coupons
        ],
    }


def _selected_name(selected: Sequence[dict[str, Any]], code: str) -> str:
    for item in selected:
        if item.get("code") == code:
            return str(item.get("name") or code)
    return code


def _history_stores(orders: Sequence[OrderRecord]) -> list[dict[str, Any]]:
    """按门店汇总历史消费，用于「常去门店」板块。"""
    counter: dict[str, dict[str, Any]] = {}
    for order in orders:
        entry = counter.setdefault(
            order.store_code,
            {
                "store_code": order.store_code,
                "store_name": order.store_name,
                "order_count": 0,
                "total_amount": 0.0,
                "last_order_time": "",
                "products": [],
            },
        )
        entry["order_count"] += 1
        entry["total_amount"] = round(entry["total_amount"] + order.amount, 2)
        if order.create_time > entry["last_order_time"]:
            entry["last_order_time"] = order.create_time
        for product in order.products:
            name = str(product.get("productName") or "")
            if name and name not in entry["products"]:
                entry["products"].append(name)
    rows = sorted(counter.values(), key=lambda e: (-e["order_count"], e["store_name"]))
    return rows


def _fast_combo(menu: Sequence[Meal]) -> dict[str, Any] | None:
    """推荐一个「出餐快 + 省钱」的套餐。

    优先单个商品码的套餐（三件套/四件套/套餐），再按省下的金额排序。
    """
    candidates = [
        meal
        for meal in menu
        if any(suffix in meal.name for suffix in _COMBO_SUFFIXES) and meal.has_discount
    ]
    if not candidates:
        return None
    candidates.sort(key=lambda m: (-m.saving, m.price))
    pick = candidates[0]
    return {
        "code": pick.code,
        "name": pick.name,
        "price": pick.price,
        "original_price": pick.original_price,
        "saving": pick.saving,
        "image": pick.image,
        "reason": "单个套餐码出餐，配件少、等待短",
    }


def _history_pin(
    orders: Sequence[OrderRecord],
    menu: Sequence[Meal],
) -> dict[str, Any] | None:
    """置顶历史订单：取最常点的一道，附原价 / 到手价。"""
    if not orders:
        return None
    counter: dict[str, dict[str, Any]] = {}
    for order in orders:
        for product in order.products:
            code = str(product.get("productCode") or "")
            if not code:
                continue
            entry = counter.setdefault(
                code,
                {
                    "code": code,
                    "name": str(product.get("productName") or code),
                    "times": 0,
                    "last_time": "",
                    "store_name": order.store_name,
                },
            )
            entry["times"] += int(product.get("quantity") or 1)
            if order.create_time > entry["last_time"]:
                entry["last_time"] = order.create_time
                entry["store_name"] = order.store_name
                entry["order_amount"] = order.amount

    if not counter:
        return None
    top = max(counter.values(), key=lambda e: (e["times"], e["last_time"]))
    meal = next((m for m in menu if m.code == top["code"]), None)
    if meal is not None:
        top["price"] = meal.price
        top["original_price"] = meal.original_price
        top["saving"] = meal.saving
        top["image"] = meal.image
    else:
        # 历史商品已下架 / 不在当前门店菜单
        top["price"] = None
        top["original_price"] = None
        top["saving"] = 0.0
        top["image"] = ""
        top["offline"] = True
    return top


# --------------------------------------------------------------------------- #
# 组装完整载荷
# --------------------------------------------------------------------------- #
def build_bundle(
    *,
    city: str,
    keyword: str,
    stores: Sequence[Store],
    menus_by_store: dict[str, Sequence[Meal]],
    activities: Sequence[Activity],
    coupons: Sequence[Coupon] = (),
    store_coupons: Sequence[StoreCoupon] = (),
    orders: Sequence[OrderRecord] = (),
    account: Any = None,
    now: datetime | None = None,
    demo: bool = False,
    location: dict[str, Any] | None = None,
    nutrition: dict[str, dict[str, Any]] | None = None,
    compositions: dict[str, dict[str, Any]] | None = None,
    points_mall: Sequence[dict[str, Any]] = (),
) -> dict[str, Any]:
    """生成前端需要的完整数据包。"""
    now = now or datetime.now()
    today = now.date()
    nutrition = nutrition or {}
    compositions = compositions or {}

    calendar = build_calendar_days(list(activities), days=7, today=today)
    nearby_distance = build_nearby_mode(stores, orders, now=now, sort="distance")
    nearby_frequent = build_nearby_mode(stores, orders, now=now, sort="frequent")
    newest = build_newest_mode(activities, stores, menus_by_store, today=today, days=7)

    default_selection = _default_selection(menus_by_store)
    speed = build_speed_mode(
        stores,
        menus_by_store,
        orders=orders,
        store_coupons=store_coupons,
        selected=default_selection,
        now=now,
    )

    return {
        "generated_at": now.strftime("%Y-%m-%d %H:%M:%S"),
        "demo": demo,
        "city": city,
        "keyword": keyword,
        "location": location or {},
        # 城市表随数据包下发，前端不再维护第二份硬编码
        "cities": cities.as_payload(),
        "account": {
            "available_points": getattr(account, "available_points", 0.0),
            "accumulated_points": getattr(account, "accumulated_points", 0.0),
            "expired_points": getattr(account, "expired_points", 0.0),
            "unit": getattr(account, "unit", "积分"),
            "account_id": getattr(account, "account_id", ""),
            "used_points": getattr(account, "used_points", 0.0),
            "frozen_points": getattr(account, "frozen_points", 0.0),
            "expiring_this_month": getattr(account, "expiring_this_month", 0.0),
            "expiring_next_month": getattr(account, "expiring_next_month", 0.0),
            "expired_last_month": getattr(account, "expired_last_month", 0.0),
        },
        "stores": [_store_payload(store) for store in stores],
        "menus": {
            code: [_meal_payload(meal, nutrition, compositions) for meal in meals]
            for code, meals in menus_by_store.items()
        },
        "coupons": [
            {
                "title": c.title,
                "status": c.status,
                "image": c.image,
                **pricing.enrich_coupon(c.title),
            }
            for c in coupons
        ],
        "store_coupons": [
            {
                "title": c.title,
                "coupon_code": c.coupon_code,
                "coupon_id": c.coupon_id,
                "valid_from": c.valid_from,
                "valid_to": c.valid_to,
                "products": list(c.product_names),
                **pricing.enrich_coupon(c.title),
            }
            for c in store_coupons
        ],
        "orders": [
            {
                "order_id": o.order_id,
                "store_code": o.store_code,
                "store_name": o.store_name,
                "create_time": o.create_time,
                "amount": o.amount,
                "summary": o.summary,
                "products": [
                    {
                        "code": p.get("productCode", ""),
                        "name": p.get("productName", ""),
                        "quantity": p.get("quantity", 1),
                    }
                    for p in (o.products or ())
                ],
                "preferred_names": list(o.preferred_names),
            }
            for o in orders
        ],
        "history_stores": _history_stores(list(orders)),
        "calendar": calendar,
        "nutrition": nutrition,
        "compositions": compositions,
        "points_mall": list(points_mall),
        "modes": {
            "nearby_distance": nearby_distance,
            "nearby_frequent": nearby_frequent,
            "newest": newest,
            "speed": speed,
        },
    }


def _default_selection(menus_by_store: dict[str, Sequence[Meal]]) -> list[dict[str, Any]]:
    """模式三默认填入的商品：菜单里的招牌单品，保证开箱即看得到效果。"""
    first_menu = next(iter(menus_by_store.values()), [])
    preferred = ("巨无霸", "麦辣鸡腿汉堡", "薯条", "可乐")
    picked: list[dict[str, Any]] = []
    for name in preferred:
        meal = next((m for m in first_menu if m.name == name), None)
        if meal is None:
            meal = next((m for m in first_menu if name in m.name), None)
        if meal is not None:
            picked.append({"code": meal.code, "name": meal.name, "quantity": 1})
    if not picked and first_menu:
        head = first_menu[0]
        picked.append({"code": head.code, "name": head.name, "quantity": 1})
    return picked


def _store_payload(store: Store) -> dict[str, Any]:
    return {
        "store_code": store.store_code,
        "be_code": store.be_code,
        "be_type": store.be_type,
        "be_type_label": store.be_type_label,
        "name": store.name,
        "address": store.address,
        "distance": store.distance,
        "business_status": store.business_status,
        "open_time": store.open_time,
        "close_time": store.close_time,
        "reservation": store.reservation,
        "city": store.city,
        "longitude": store.longitude,
        "latitude": store.latitude,
        "has_coords": store.has_coords,
    }


def _meal_payload(
    meal: Meal,
    nutrition: dict[str, dict[str, Any]] | None = None,
    compositions: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """单个餐品的前端载荷：菜单字段 + 自写简介 + 真实营养成分。"""
    payload: dict[str, Any] = {
        "code": meal.code,
        "name": meal.name,
        "price": meal.price,
        "original_price": meal.original_price,
        "saving": meal.saving,
        "image": meal.image,
        "discount_type": meal.discount_type,
        "tags": list(meal.tags),
        "desc": descriptions.describe(
            meal.code,
            meal.name,
            tags=meal.tags,
            price=meal.price,
            original_price=meal.original_price,
            discount_type=meal.discount_type,
        ),
    }
    nut = resolve_nutrition(meal.code, meal.name, nutrition or {}, compositions)
    if nut:
        payload["nutrition"] = nut
        payload["kcal"] = nut.get("kcal")
    return payload


def _days_until(date_str: str, today: date) -> int | None:
    try:
        return (date.fromisoformat(date_str) - today).days
    except (ValueError, TypeError):
        return None
