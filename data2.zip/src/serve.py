"""麦麦雷达地图 —— 本地一键启动服务。

为什么需要它：纯静态页面拿不到麦当劳 MCP 的 Token（也不该拿），
所以「换城市」原本只能去命令行重跑一次导出。本模块把这件事搬到浏览器里：

* **静态服务** —— 托管 ``web/``，并给未配置地图 Key 的场景返回空脚本兜底；
* ``GET  /api/status`` —— 告诉前端：本地服务是否在线、能不能实时切城市、
  当前数据包属于哪个城市、以及城市清单；
* ``POST /api/city``  —— 用 ``.env`` 里的 Token **真的**去麦当劳 MCP 拉一次
  该城市的门店 / 菜单 / 活动，重新导出 ``data.js`` + ``data.json``，
  前端刷新即可看到。

安全与诚实边界：

* 服务只监听 ``127.0.0.1``，Token 只留在服务端（``.env``），永不下发到浏览器；
* **导出失败绝不覆盖**已有数据包 —— 特别是「返回 0 家门店」这种静默失败；
* 没有 Token 时不会假装能切城市，而是明确返回 ``offline`` 并说明原因。

用法::

    python -m src.serve                 # 起服务并自动打开浏览器
    python -m src.serve --no-open       # 只起服务
    python -m src.serve --port 8888
    python -m src.serve --demo          # 强制离线快照（城市下拉不提供直切）
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from datetime import datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from . import __version__, cities
from .config import PROJECT_ROOT, ConfigError, Settings, load_tmap_key
from .demo_client import DemoMCPClient
from .mcp_client import HttpMCPClient
from .webexport import (
    DEFAULT_CITY,
    DEFAULT_KEYWORD,
    TMAP_KEY_FILE,
    WEB_DIR,
    collect,
    write_assets,
)

#: 一份数据包导出最多等多久（秒）。真实 MCP 要逐店拉菜单，慢是正常的。
EXPORT_BUDGET = 180.0


class EmptyResult(RuntimeError):
    """某个关键词没查到任何门店。

    单独定义成一种异常，是为了把它和「网络断了 / Token 失效」区分开：
    只有这种失败才值得**换下一个候选关键词重试**（见 ``cities.keyword_candidates``）。
    """


def resolve_now(raw: str) -> datetime:
    """把 ``--at HH:MM`` 解析成「今天 + 该时刻」，留空则取真实当前时间。"""
    if not raw:
        return datetime.now()
    try:
        hour, minute = (int(part) for part in raw.split(":", 1))
        return datetime.now().replace(hour=hour, minute=minute, second=0, microsecond=0)
    except (ValueError, TypeError):
        print(f"警告：--at 格式应为 HH:MM，已忽略 {raw!r}", file=sys.stderr)
        return datetime.now()


# --------------------------------------------------------------------------- #
# 腾讯「关键词输入提示」（定位输入框的下拉候选）
# --------------------------------------------------------------------------- #
#: 官方文档：https://lbs.qq.com/service/webService/webServiceGuide/webServiceSuggestion
SUGGEST_URL = "https://apis.map.qq.com/ws/place/v1/suggestion"

#: 输入框下拉固定给 5 条 —— 再多反而挑花眼
SUGGEST_LIMIT = 5

#: 候选缓存条数与存活秒数。逐字敲键盘会连着打十几次接口，
#: 不缓存既慢又白白烧配额（腾讯该 Key 按日限次）。
_SUGGEST_CACHE: dict[tuple[str, str], tuple[float, list[dict[str, Any]]]] = {}
_SUGGEST_CACHE_MAX = 128
_SUGGEST_CACHE_TTL = 180.0

#: 腾讯返回码 → 给人看的一句话。110/112 都是白名单没配对，
#: 121 是日限（实测多为瞬时抖动，重试即过）。
_SUGGEST_ERRORS = {
    110: "腾讯地图 Key 的「WebServiceAPI 域名白名单」没包含当前地址（含端口）。",
    111: "腾讯地图 Key 开启了 SN 校验，本地服务未带签名。",
    112: "腾讯地图 Key 配置了「授权 IP」白名单，本机出口 IP 不在其中。",
    113: "腾讯地图 Key 未开通「关键词输入提示」的配额。",
    120: "腾讯地图返回 120：该服务被拒绝访问。",
    121: "腾讯地图日调用量已达上限（多为瞬时抖动，稍后重试即可）。",
    190: "腾讯地图 Key 无效。",
    199: "腾讯地图 Key 未开启 WebServiceAPI 功能。",
}


def _suggest_cache_get(key: tuple[str, str]) -> list[dict[str, Any]] | None:
    hit = _SUGGEST_CACHE.get(key)
    if not hit:
        return None
    stamp, items = hit
    if time.time() - stamp > _SUGGEST_CACHE_TTL:
        _SUGGEST_CACHE.pop(key, None)
        return None
    return items


def _suggest_cache_put(key: tuple[str, str], items: list[dict[str, Any]]) -> None:
    if len(_SUGGEST_CACHE) >= _SUGGEST_CACHE_MAX:
        _SUGGEST_CACHE.clear()
    _SUGGEST_CACHE[key] = (time.time(), items)


def fetch_suggestions(
    keyword: str,
    region: str = "",
    *,
    key: str | None = None,
    referer: str = "",
    limit: int = SUGGEST_LIMIT,
    timeout: float = 6.0,
) -> tuple[dict[str, Any], int]:
    """用腾讯「关键词输入提示」把一段关键词变成坐标候选。

    返回 ``(payload, http_status)``；``payload["items"]`` 每条形如::

        {"title": "人民广场[地铁站]", "address": "...", "city": "上海市",
         "district": "黄浦区", "lat": 31.232572, "lng": 121.475242}

    **为什么放在服务端而不是浏览器直接调**：

    * Key 只留在服务端（``.env``），不下发到浏览器；
    * 腾讯白名单是「host:port 字面串」比较 —— 由服务端把浏览器带上来的
      ``Referer`` 原样转发，天然命中用户已配置的白名单，不必再让用户去加一条。
    """
    text = (keyword or "").strip()
    if not text:
        return {"ok": False, "code": "bad_request", "message": "请先输入地点名称。"}, 400

    token = key if key is not None else load_tmap_key()
    if not token:
        return {
            "ok": False,
            "code": "no_key",
            "message": "未配置 TMAP_KEY，无法使用腾讯地图定位。请把 Key 填进项目根目录的 .env 后重启服务。",
        }, 409

    limit = max(1, min(int(limit or SUGGEST_LIMIT), 10))
    cache_key = (text, region or "")
    cached = _suggest_cache_get(cache_key)
    if cached is not None:
        return {"ok": True, "cached": True, "items": cached[:limit], "count": len(cached)}, 200

    params = {
        "keyword": text,
        "page_size": str(limit),
        "key": token,
        "output": "json",
    }
    if region:
        params["region"] = region
    url = SUGGEST_URL + "?" + urllib.parse.urlencode(params)

    headers = {"User-Agent": "MCDRadar/1.0 (+local)"}
    if referer:
        headers["Referer"] = referer

    request = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:  # 网络层错误
        return {
            "ok": False,
            "code": "network",
            "message": f"连不上腾讯地图服务（HTTP {exc.code}）。",
        }, 502
    except Exception as exc:  # noqa: BLE001 - 统一转成可读错误
        return {
            "ok": False,
            "code": "network",
            "message": f"连不上腾讯地图服务：{type(exc).__name__}: {exc}",
        }, 502

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {"ok": False, "code": "bad_response", "message": "腾讯地图返回了无法解析的内容。"}, 502

    status = int(data.get("status") or 0)
    if status != 0:
        return {
            "ok": False,
            "code": f"tmap_{status}",
            "status": status,
            "message": _SUGGEST_ERRORS.get(status, f"腾讯地图返回 status={status}：{data.get('message', '')}"),
        }, 200

    items: list[dict[str, Any]] = []
    for record in data.get("data") or []:
        if not isinstance(record, dict):
            continue
        loc = record.get("location") or {}
        try:
            lat = float(loc.get("lat"))
            lng = float(loc.get("lng"))
        except (TypeError, ValueError):
            continue
        city = str(record.get("city") or "")
        items.append(
            {
                "title": str(record.get("title") or "").strip(),
                "address": str(record.get("address") or "").strip(),
                "city": city,
                "district": str(record.get("district") or "").strip(),
                "province": str(record.get("province") or "").strip(),
                "lat": lat,
                "lng": lng,
            }
        )
    _suggest_cache_put(cache_key, items)
    return {"ok": True, "items": items[:limit], "count": len(items)}, 200


class RadarApp:
    """服务端状态与业务逻辑（与 HTTP 层解耦，便于单测）。"""

    def __init__(
        self,
        web_dir: Path | str = WEB_DIR,
        *,
        demo: bool = False,
        city: str = DEFAULT_CITY,
        keyword: str = DEFAULT_KEYWORD,
        at: str = "",
    ) -> None:
        self.web_dir = Path(web_dir)
        self.forced_demo = bool(demo)
        self.city = city
        self.keyword = keyword
        self.at = at
        self._lock = threading.Lock()
        self._busy = False
        self._busy_city = ""
        self._last_error = ""

    # ------------------------------------------------------------ 能力判定
    @staticmethod
    def settings() -> Settings | None:
        """能读到 Token 就返回配置，否则 None（不是错误，离线快照是正常姿势）。"""
        try:
            return Settings.load()
        except ConfigError:
            return None

    @property
    def live(self) -> bool:
        """是否具备「在浏览器里真的切城市」的能力。"""
        return not self.forced_demo and self.settings() is not None

    def offline_reason(self) -> str:
        if self.forced_demo:
            return "已用 --demo 强制离线快照模式"
        return "未在 .env 中配置 MCD_MCP_TOKEN"

    # ------------------------------------------------------------ 快照读取
    def snapshot(self) -> dict[str, Any]:
        path = self.web_dir / "data.json"
        if not path.exists():
            return {}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return data if isinstance(data, dict) else {}

    def status(self) -> dict[str, Any]:
        snap = self.snapshot()
        live = self.live
        return {
            "ok": True,
            "service": "mcd-radar-local",
            "version": __version__,
            "mode": "live" if live else "demo",
            "live": live,
            "live_reason": "" if live else self.offline_reason(),
            "busy": self._busy,
            "busy_city": self._busy_city,
            "city": snap.get("city") or self.city,
            "keyword": snap.get("keyword") or self.keyword,
            "generated_at": snap.get("generated_at", ""),
            "store_count": len(snap.get("stores") or []),
            "calendar_days": len(snap.get("calendar") or []),
            "tmap": bool(load_tmap_key()),
            "cities": cities.as_payload(),
            "last_error": self._last_error,
        }

    # ------------------------------------------------------------ 配置 Token
    def save_token(self, token: str, env_path: Path | None = None) -> tuple[dict[str, Any], int]:
        """把 MCD_MCP_TOKEN 写进项目根目录的 .env。

        为什么值得开这个口子：没有 Token 就切不了城市，而让用户为了填一行配置去
        敲命令行，恰恰违背了「一键启动」的初衷。

        安全边界（都写进代码里，不靠自觉）：
          * 服务只监听 127.0.0.1，Token 不会被下发到浏览器，也不会回显；
          * Token 只落 ``.env``（已被 .gitignore 排除），不写进 data.js；
          * 只替换 ``MCD_MCP_TOKEN`` 那一行，其余配置原样保留。
        """
        value = (token or "").strip()
        if len(value) < 10 or any(ch in value for ch in "\r\n"):
            return {
                "ok": False,
                "code": "bad_token",
                "message": "Token 看起来不完整（太短或含换行）。请从麦当劳 MCP 申请页复制完整值。",
            }, 400

        path = env_path or (PROJECT_ROOT / ".env")
        try:
            lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
        except OSError as exc:
            return {"ok": False, "code": "io", "message": f"读不到 {path}：{exc}"}, 500

        out: list[str] = []
        replaced = False
        for line in lines:
            if line.strip().startswith("MCD_MCP_TOKEN"):
                out.append(f"MCD_MCP_TOKEN={value}")
                replaced = True
            else:
                out.append(line)
        if not replaced:
            if out and out[-1].strip():
                out.append("")
            out.append("# ── 麦当劳 MCP Token（由本地服务写入）──")
            out.append(f"MCD_MCP_TOKEN={value}")

        try:
            path.write_text("\n".join(out) + "\n", encoding="utf-8")
        except OSError as exc:
            return {"ok": False, "code": "io", "message": f"写不进 {path}：{exc}"}, 500

        # .env 里原本是空值时，dotenv 已经把空串塞进了 os.environ，
        # 而 load_dotenv(override=False) 不会覆盖它 —— 所以这里必须显式覆盖一次，
        # 否则「填完 Token 还是要重启服务」。
        os.environ["MCD_MCP_TOKEN"] = value

        return {
            "ok": True,
            "live": self.live,
            "message": "Token 已保存，现在可以直接切换城市了。",
            "env_file": str(path),
        }, 200

    # ------------------------------------------------------------ 切城市
    def switch_city(self, raw_city: str, raw_keyword: str = "") -> tuple[dict[str, Any], int]:
        """切换（或刷新）某城市的数据。返回 ``(payload, http_status)``。

        关键词策略（这是「所有城市都能一键切」的关键）：

        * 用户**显式填了**关键词 → 只用那一个，不替他改主意；
        * 否则走 ``cities.keyword_candidates()`` 的候选链 —— 依次尝试
          「人工地标 → 城市名 → 市中心 → 麦当劳 → …」，用**第一个查到门店**的词。

        为什么要链：``query-nearby-stores`` 没有坐标检索，只有 city + keyword，
        而店名不一定含城市名（呼伦贝尔的店写「海拉尔」）。实测候选链能把这类
        城市救回来；全试完仍为空，说明该城市确实没开店，如实告知。
        """
        city = cities.normalize_city(raw_city)
        if not city:
            return {"ok": False, "code": "bad_request", "message": "请先选择城市"}, 400

        explicit = (raw_keyword or "").strip()
        candidates = cities.keyword_candidates(city)
        if explicit:
            # 显式关键词优先，但**绝不能只试它一个**：一个地点名往往只在一座城市里
            # 有意义。实测血案 —— 在深圳选了「深圳湾公园[地铁站]」再去切北京，
            # MCP 在北京查不到这个名字 → 返回 0 家门店 → 整座北京被误判成
            # 「没有门店」。所以显式关键词取不到时，退回城市候选链兜底，
            # 别让一个失效关键词把整座城市堵死。
            chain = [explicit] + [k for k in candidates if k != explicit]
        else:
            chain = candidates
        guessed = not explicit

        snap = self.snapshot()
        current = snap.get("city") or self.city

        if not self.live:
            if city == current:
                return {
                    "ok": True,
                    "unchanged": True,
                    "city": city,
                    "keyword": snap.get("keyword") or chain[0],
                    "message": f"当前就是「{city}」的快照，无需切换。",
                }, 200
            return {
                "ok": False,
                "code": "offline",
                "message": f"本地服务当前是离线快照模式（{self.offline_reason()}），"
                           f"无法实时拉取「{city}」的数据。",
                "hint": "请在项目根目录的 .env 里填好 MCD_MCP_TOKEN，然后重新双击启动脚本。",
            }, 409

        if self._busy:
            return {
                "ok": False,
                "code": "busy",
                "message": f"正在导出「{self._busy_city}」，请等它完成再切换。",
            }, 429

        with self._lock:
            if self._busy:  # 双检，避免并发穿透
                return {"ok": False, "code": "busy", "message": "已有导出任务在进行中。"}, 429
            self._busy = True
            self._busy_city = city
            started = time.time()
            result: dict[str, Any] | None = None
            tried: list[str] = []
            try:
                for keyword in chain:
                    try:
                        result = self._export(city, keyword)
                        result["matched_keyword"] = keyword
                        # 命中链里第一条（用户显式给的那个）才算「用户的」，
                        # 否则都是系统按城市候选链猜的 —— 前端据此如实标注。
                        result["keyword_guessed"] = guessed or keyword != chain[0]
                        result["explicit_keyword_dropped"] = bool(explicit) and keyword != explicit
                        break
                    except EmptyResult:
                        tried.append(keyword)   # 只对这种失败换词重试
                if result is None:
                    raise EmptyResult(
                        f"「{city}」没有返回任何门店，已保留原有数据不做覆盖。"
                        f"（已依次试过：{'、'.join(tried)}）"
                    )
            except ConfigError as exc:
                self._last_error = str(exc)
                return {"ok": False, "code": "config", "message": str(exc)}, 400
            except EmptyResult as exc:
                self._last_error = str(exc)
                return {
                    "ok": False,
                    "code": "empty",
                    "message": str(exc),
                    "hint": "该城市常见的地点名已依次试过一轮，仍无返回 —— 麦当劳 MCP 覆盖范围"
                            "以实际返回为准，该城市可能确实还没有门店。可以试试相邻城市，"
                            "或在关键词框里填一个该城市内确定存在的地点名再试。",
                    "tried": tried,
                }, 404
            except Exception as exc:  # noqa: BLE001 - 统一转成可读错误给前端
                self._last_error = f"{type(exc).__name__}: {exc}"
                return {
                    "ok": False,
                    "code": "export_failed",
                    "message": f"拉取「{city}」失败：{self._last_error}",
                    "hint": "原有数据包未被改动，你可以继续浏览当前快照。",
                }, 502
            finally:
                self._busy = False
                self._busy_city = ""

        result["elapsed"] = round(time.time() - started, 1)
        self._last_error = ""
        return result, 200

    def _export(self, city: str, keyword: str) -> dict[str, Any]:
        """真实拉一次并写出数据包。失败/空结果一律抛异常，避免覆盖旧快照。"""
        now = resolve_now(self.at)
        settings = self.settings()

        if settings is None or self.forced_demo:
            async def run_demo() -> dict[str, Any]:
                client = DemoMCPClient(city=city, keyword=keyword)
                async with client:
                    return await collect(client, city=city, keyword=keyword, demo=True, now=now)

            bundle = asyncio.run(run_demo())
        else:
            async def run_live() -> dict[str, Any]:
                client = HttpMCPClient(settings)
                async with client:
                    return await collect(client, city=city, keyword=keyword, demo=False, now=now)

            bundle = asyncio.run(run_live())

        stores = bundle.get("stores") or []
        if not stores:
            raise EmptyResult(
                f"「{city} · {keyword}」没有返回任何门店，已保留原有数据不做覆盖。"
            )

        if self.at:
            bundle["scenario"] = f"{self.at} 时段场景"

        js_path, json_path = write_assets(bundle, self.web_dir)
        return {
            "ok": True,
            "city": bundle.get("city", city),
            "keyword": bundle.get("keyword", keyword),
            "generated_at": bundle.get("generated_at", ""),
            "store_count": len(stores),
            "menu_stores": len(bundle.get("menus") or {}),
            "calendar_days": len(bundle.get("calendar") or []),
            "source": "离线真实快照 (--demo)" if bundle.get("demo") else "麦当劳 MCP 实时接口",
            "files": [js_path.name, json_path.name],
            "message": f"已切换到「{city} · {keyword}」：{len(stores)} 家门店。",
        }


# --------------------------------------------------------------------------- #
# HTTP 层
# --------------------------------------------------------------------------- #
def make_handler(app: RadarApp) -> type[SimpleHTTPRequestHandler]:
    web_dir = app.web_dir
    key_file = web_dir / TMAP_KEY_FILE

    class Handler(SimpleHTTPRequestHandler):
        server_version = f"MCDRadar/{__version__}"

        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, directory=str(web_dir), **kwargs)

        def end_headers(self) -> None:
            """本地开发用：静态资源一律不走缓存。

            SimpleHTTPRequestHandler 只发 Last-Modified，不发 Cache-Control，
            浏览器会按启发式规则自己决定新鲜度。改了 styles.css 之后刷新看不到效果，
            很容易被误判成「改了没用」—— 所以这里统一 no-cache（仍会带 ETag 校验）。
            """
            if "/api/" not in (self.path or ""):
                self.send_header("Cache-Control", "no-cache, must-revalidate")
            super().end_headers()

        # 静态资源访问不刷屏，只保留 API 的一行日志
        def log_message(self, fmt: str, *args: Any) -> None:  # noqa: A003
            if "/api/" not in (self.path or ""):
                return
            try:
                print(f"   [api] {fmt % args}")
            except Exception:  # pragma: no cover - 日志本身不该影响请求
                pass

        # ---------------------------------------------------- 响应工具
        def _json(self, payload: dict[str, Any], status: int = 200) -> None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

        def _suggest(self, query: str) -> tuple[dict[str, Any], int]:
            """GET /api/suggest?keyword=..&region=..&limit=..

            把浏览器的 Referer 原样转发给腾讯 —— 用户已在白名单里配了
            ``127.0.0.1:8770`` 这类「host:port」，浏览器请求本服务时带的
            Referer 正好就是它，于是不必再让用户额外加一条。
            """
            qs = urllib.parse.parse_qs(query or "")
            keyword = (qs.get("keyword") or [""])[0]
            region = cities.normalize_city((qs.get("region") or [""])[0])
            raw_limit = (qs.get("limit") or [""])[0]
            limit = int(raw_limit) if raw_limit.isdigit() else SUGGEST_LIMIT
            referer = self.headers.get("Referer") or f"http://{self.headers.get('Host') or '127.0.0.1'}/"
            return fetch_suggestions(keyword, region, referer=referer, limit=limit)

        def _read_json(self) -> dict[str, Any]:
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                length = 0
            if length <= 0:
                return {}
            raw = self.rfile.read(length)
            try:
                data = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                return {}
            return data if isinstance(data, dict) else {}

        # ---------------------------------------------------- 路由
        def do_GET(self) -> None:  # noqa: N802 - 覆写父类命名
            parsed = urlparse(self.path)
            path = parsed.path
            if path == "/api/status":
                self._json(app.status())
                return
            if path == "/api/suggest":
                self._json(*self._suggest(parsed.query))
                return
            if path.endswith(TMAP_KEY_FILE) and not key_file.exists():
                body = (
                    "/* 未配置 TMAP_KEY：前端将回退代理模式或距离雷达图 */\n"
                ).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/javascript; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            super().do_GET()

        def do_POST(self) -> None:  # noqa: N802 - 覆写父类命名
            path = urlparse(self.path).path
            body = self._read_json()

            if path == "/api/city":
                payload, status = app.switch_city(
                    str(body.get("city", "")), str(body.get("keyword", ""))
                )
                self._json(payload, status)
                return

            if path == "/api/token":
                payload, status = app.save_token(str(body.get("token", "")))
                self._json(payload, status)
                return

            self._json({"ok": False, "code": "not_found", "message": "未知接口"}, 404)

        def do_OPTIONS(self) -> None:  # noqa: N802 - 覆写父类命名
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()

    return Handler


def create_server(
    app: RadarApp, port: int, host: str = "127.0.0.1", tries: int = 12
) -> tuple[ThreadingHTTPServer, int]:
    """起服务；端口被占用时自动向后顺延，避免「端口已被占用」把用户挡在门外。"""
    handler = make_handler(app)
    last_error: OSError | None = None
    for offset in range(tries):
        candidate = port + offset
        try:
            return ThreadingHTTPServer((host, candidate), handler), candidate
        except OSError as exc:  # 端口占用 / 权限
            last_error = exc
    raise OSError(f"{port}~{port + tries - 1} 均无法监听：{last_error}")


def probe_existing_service(port: int, host: str = "127.0.0.1", timeout: float = 1.2) -> bool:
    """该端口上是不是已经跑着麦麦雷达地图的本地服务。

    Windows 的 ``allow_reuse_address`` 允许**两个进程同时 bind 同一个端口**，
    于是「再双击一次 start.bat」会悄悄多起一个实例，两个实例抢同一条连接 ——
    用户看到的是「一会儿正常一会儿不正常」，极难排查。
    所以在真正监听之前先问一句：这个端口上是不是已经有我们的服务在跑？
    （显式清空 ProxyHandler：本机回环请求绝不能被 http_proxy 带走。）
    """
    url = f"http://{host}:{port}/api/status"
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(url, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8", "replace") or "{}")
    except Exception:  # 端口空着、或上面跑的是别的程序
        return False
    return bool(payload.get("ok")) and payload.get("service") == "mcd-radar-local"


def run_server(app: RadarApp, port: int = 8770, open_browser: bool = True) -> int:
    # 已经有一个实例在跑 → 直接复用它，不要再起第二个（否则两个实例抢端口）
    if probe_existing_service(port):
        url = f"http://127.0.0.1:{port}/index.html"
        print("")
        print("  🍔 麦麦雷达地图 · 本地服务已经在运行了")
        print(f"     ➜ {url}")
        print("     ➜ 不会再启动第二个实例（两个实例抢同一个端口会让页面时好时坏）")
        print("")
        if open_browser:
            webbrowser.open(url)
        return 0

    httpd, bound_port = create_server(app, port)
    url = f"http://127.0.0.1:{bound_port}/index.html"

    snap_city = app.snapshot().get("city") or app.city
    if app.live:
        mode_line = "麦当劳 MCP 实时 —— 城市下拉里可一键切换城市"
    else:
        mode_line = f"离线真实快照（{app.offline_reason()}）—— 城市下拉会给出导出命令"
    map_line = "腾讯 Key 模式" if load_tmap_key() else "WorkBuddy 预览代理 / 距离雷达图"

    print("")
    print("  🍔 麦麦雷达地图 · 本地服务已启动")
    print(f"     ➜ {url}")
    print(f"     ➜ 数据：{mode_line}")
    print(f"     ➜ 快照城市：{snap_city}")
    print(f"     ➜ 地图：{map_line}")
    if bound_port != port:
        # 端口一变，腾讯域名白名单就对不上了（白名单按 host:端口 精确匹配）：
        # 表现是「地图出得来、但门店/驾车路线/定位候选全取不到」。
        print("")
        print(f"     ⚠️  {port} 已被占用，本次改用 {bound_port}。")
        print("     ⚠️  腾讯地图白名单是按「host:端口」精确匹配的 ——")
        print(f"        请在控制台白名单里补上 127.0.0.1:{bound_port}，")
        print("        否则「地点搜索 / 驾车路线 / 定位候选」会被腾讯拒绝。")
    print("     ➜ 按 Ctrl+C 停止")
    print("")

    if open_browser:
        threading.Timer(0.7, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  已停止本地服务。")
    finally:
        httpd.server_close()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="mcd-serve", description="麦麦雷达地图 · 本地一键启动服务（静态预览 + 城市实时切换）"
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--port", type=int, default=8770, help="端口，默认 8770（占用时自动顺延）")
    parser.add_argument("--city", default=DEFAULT_CITY, help=f"默认城市，仅用于无从读取快照时")
    parser.add_argument("--keyword", default=DEFAULT_KEYWORD, help="默认位置关键词")
    parser.add_argument("--at", default="", help="把「当前时刻」固定为 HH:MM（演示高峰时段）")
    parser.add_argument(
        "--demo", action="store_true", help="强制离线快照模式（城市下拉不提供直切）"
    )
    parser.add_argument("--no-open", action="store_true", help="不自动打开浏览器")
    args = parser.parse_args(argv)

    app = RadarApp(demo=args.demo, city=args.city, keyword=args.keyword, at=args.at)
    try:
        return run_server(app, port=args.port, open_browser=not args.no_open)
    except OSError as exc:
        print(f"无法启动本地服务：{exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
