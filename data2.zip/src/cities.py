"""城市表与检索关键词 —— 全项目**唯一**的一份。

为什么单独抽出来：

* ``query-nearby-stores`` 在 ``searchType=2`` 时**必须**同时给 ``city`` 和 ``keyword``，
  而且没有坐标检索入口。所以「能不能查到门店」几乎完全取决于 keyword 选得对不对；
* 城市下拉、一键启动的本地服务、地图定位，三处都要用同一套表，
  否则前端点的城市和服务端查的城市会悄悄对不上。

数据来源与实测结论（2026-10，用真实 Token 打过一遍）
----------------------------------------------------

* **覆盖面**：麦当劳 MCP 覆盖中国大陆全部有门店的城市，连拉萨、乌鲁木齐、
  呼伦贝尔、伊犁、阿坝都能查到；港澳台不在服务范围（官方说明「不含港澳台」），故未收录。
* **keyword 用城市名本身**在 40 座抽样城市上 **40/40 命中** —— 所以城市名是一条
  可靠的兜底词，不必为 367 座城市逐一手写地标。
* 但城市名容易命中**火车站 / 机场店**（店名里带城市名），而人工地标（如「人民广场」）
  给的是市中心店。所以对大城市保留一份人工地标。
* 有些城市店名用的是下辖地名（呼伦贝尔 → 店名写「海拉尔」），城市名查不到；
  这类靠候选链里的「市中心」「麦当劳」救回来（实测 4/4 有效）。
* 剩下的（喀什、海西、果洛、漠河…）是麦当劳确实没开店，如实告知即可，不编造。

坐标来自 DataV 行政区划 GeoJSON，用于**把地图视角定位到该城市**。
有了它，即使腾讯地图 WebServiceAPI 不可用（白名单 / 配额问题），
地图也能落到正确的城市，而不是永远停在内置的默认点上。
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

_DATA_FILE = Path(__file__).resolve().parent / "data" / "china_cities.json"

#: 候选链的尾部。城市名之后依次尝试这些通用词 —— 城市名救不回来的靠它们。
#: 顺序有讲究："市中心" 覆盖面最广，其次 "麦当劳"（直接匹配品牌名，对
#: 「店名不含城市名」的城市特别有效，如阿坝、伊犁、博尔塔拉）。
CHAIN_TAIL: tuple[str, ...] = ("市中心", "麦当劳", "万达广场", "步行街")

#: 完全找不到时的兜底词
FALLBACK_KEYWORD = "市中心"


@lru_cache(maxsize=1)
def _table() -> dict[str, dict[str, Any]]:
    """读入城市表，并建立「多种写法 → 同一条记录」的索引。"""
    raw = json.loads(_DATA_FILE.read_text(encoding="utf-8"))
    index: dict[str, dict[str, Any]] = {}
    for item in raw.get("cities", []):
        record = {
            "name": item["name"],
            "full": item.get("full") or item["name"],
            "province": item.get("province") or "",
            "lat": item.get("lat"),
            "lng": item.get("lng"),
            "keyword": item.get("keyword") or "",
        }
        for alias in {record["name"], record["full"]}:
            index.setdefault(alias, record)
    return index


def all_cities() -> list[dict[str, Any]]:
    """按表内顺序返回全部城市（数据文件里的顺序 = 省份顺序）。"""
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for record in _table().values():
        if record["name"] in seen:
            continue
        seen.add(record["name"])
        out.append(record)
    return out


def lookup(city: str) -> dict[str, Any] | None:
    """查一座城市；容忍「深圳市」「阿坝藏族羌族自治州」这类写法。"""
    return _table().get(normalize_city(city))


def normalize_city(city: str) -> str:
    """把用户输入规整到表内的标准写法。表里没有的**原样返回**（允许自由输入）。"""
    text = (city or "").strip()
    if not text:
        return text
    table = _table()
    if text in table:
        return table[text]["name"]

    # 「深圳市」→「深圳」；「阿坝藏族羌族自治州」→「阿坝藏族羌族自治州」（表里就是全名）
    for suffix in ("市", "地区", "特别行政区"):
        if text.endswith(suffix) and text[: -len(suffix)] in table:
            return table[text[: -len(suffix)]]["name"]

    # 「延边」→「延边朝鲜族自治州」这类简称：表里有以它开头的全名就用它
    for alias, record in table.items():
        if len(alias) > len(text) and alias.startswith(text):
            return record["name"]

    return text


def is_known(city: str) -> bool:
    return normalize_city(city) in _table()


def coordinates(city: str) -> tuple[float, float] | None:
    """该城市的 (纬度, 经度)；表里没有则 None。地图定位用。"""
    record = lookup(city)
    if not record or record["lat"] is None or record["lng"] is None:
        return None
    return float(record["lat"]), float(record["lng"])


def keyword_candidates(city: str) -> list[str]:
    """按优先级返回候选关键词。

    服务端会按顺序尝试，用**第一个能查到门店**的词。这样既拿到了大城市的
    市中心地标，又不用为 367 座城市逐一手写。
    """
    name = normalize_city(city)
    if not name:
        return [FALLBACK_KEYWORD]

    out: list[str] = []

    def add(word: str) -> None:
        word = (word or "").strip()
        if word and word not in out:
            out.append(word)

    record = lookup(name)
    if record:
        add(record["keyword"])   # 人工地标（只有部分大城市有）
    add(name)                    # 城市名本身：实测 40/40 可命中
    for word in CHAIN_TAIL:
        add(word)
    return out


def default_keyword(city: str) -> str:
    """链上的首选词。未知城市也会返回**城市名本身**（这是最可能命中的词）。"""
    return keyword_candidates(city)[0]


def province_of(city: str) -> str:
    record = lookup(city)
    return record["province"] if record else ""


def as_payload() -> list[dict[str, Any]]:
    """给前端数据包 / ``/api/status`` 用的序列化形式。

    带上 ``province`` / ``lat`` / ``lng``：前者用于下拉分组与搜索，
    后者让前端**不依赖腾讯地图接口**就能把视角定位到城市。
    """
    return [
        {
            "city": r["name"],
            "keyword": r["keyword"] or r["name"],
            "province": r["province"],
            "lat": r["lat"],
            "lng": r["lng"],
        }
        for r in all_cities()
    ]


def provinces() -> list[list[str]]:
    """按省份分组的城市名，供下拉做分组展示。"""
    order: list[str] = []
    bucket: dict[str, list[str]] = {}
    for record in all_cities():
        prov = record["province"] or "其他"
        if prov not in bucket:
            bucket[prov] = []
            order.append(prov)
        bucket[prov].append(record["name"])
    return [[prov, bucket[prov]] for prov in order]  # type: ignore[return-value]


#: 兼容旧调用：城市总数（测试与文档会引用）
CITY_ORDER: tuple[str, ...] = tuple(r["name"] for r in all_cities())

#: 兼容旧调用：有人工地标的城市 → 地标
CITY_LANDMARKS: dict[str, str] = {
    r["name"]: r["keyword"] for r in all_cities() if r["keyword"]
}
