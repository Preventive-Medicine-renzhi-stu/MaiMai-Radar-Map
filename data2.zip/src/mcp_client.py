"""麦当劳 MCP 客户端（streamable HTTP）。

真实实现基于官方 mcp SDK；对外暴露统一的 ``call`` 门面，返回已还原的载荷
（dict / list，或无法解析时的原始文本）。
"""

from __future__ import annotations

import json
from contextlib import AsyncExitStack
from typing import Any, Protocol, runtime_checkable

from .config import Settings


class MCPToolError(RuntimeError):
    """MCP 工具调用返回错误。"""


@runtime_checkable
class ToolClient(Protocol):
    """工具客户端协议，真实客户端与演示客户端共用。"""

    async def call(self, tool: str, arguments: dict[str, Any] | None = None) -> Any:
        ...

    async def aclose(self) -> None:
        ...


def extract_payload(result: Any) -> Any:
    """从 CallToolResult 中还原有效载荷。

    麦当劳 MCP 的返回可能是结构化字段，也可能是「说明文字 + 原始 JSON」的纯文本，
    这里统一还原：优先结构化字段，其次尝试解析 JSON，最后退回原文。
    """
    if getattr(result, "is_error", False):
        raise MCPToolError(_first_text(result) or "MCP 工具返回错误")

    structured = getattr(result, "structured_content", None)
    if structured not in (None, {}, []):
        return structured

    text = _first_text(result)
    parsed = _try_parse_json(text)
    return parsed if parsed is not None else text


def _first_text(result: Any) -> str:
    parts: list[str] = []
    for item in getattr(result, "content", None) or []:
        chunk = getattr(item, "text", None)
        if chunk:
            parts.append(chunk)
    return "\n".join(parts).strip()


def _try_parse_json(text: str) -> Any | None:
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    marker = "Original Response"
    idx = text.rfind(marker)
    if idx != -1:
        candidate = text[idx + len(marker) :].lstrip(": \n")
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            pass

    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end > start:
        try:
            return json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            pass
    return None


class HttpMCPClient:
    """基于官方 mcp SDK 的 streamable HTTP 客户端。

    用法::

        async with HttpMCPClient(settings) as client:
            data = await client.call("campaign-calendar", {})
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._stack: AsyncExitStack | None = None
        self._session: Any = None

    async def __aenter__(self) -> "HttpMCPClient":
        from mcp import ClientSession
        from mcp.client.streamable_http import (
            create_mcp_http_client,
            streamable_http_client,
        )

        stack = AsyncExitStack()
        await stack.__aenter__()
        try:
            http_client = await stack.enter_async_context(
                create_mcp_http_client(headers=self._settings.auth_headers())
            )
            read_stream, write_stream = await stack.enter_async_context(
                streamable_http_client(self._settings.mcp_url, http_client=http_client)
            )
            self._session = await stack.enter_async_context(
                ClientSession(
                    read_stream,
                    write_stream,
                    read_timeout_seconds=self._settings.timeout,
                )
            )
            await self._session.initialize()
        except BaseException:
            await stack.aclose()
            raise
        self._stack = stack
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    async def call(self, tool: str, arguments: dict[str, Any] | None = None) -> Any:
        if self._session is None:
            raise RuntimeError("客户端尚未初始化，请使用 `async with` 进入上下文。")
        result = await self._session.call_tool(tool, arguments or None)
        return extract_payload(result)

    async def list_tools(self) -> list[str]:
        if self._session is None:
            raise RuntimeError("客户端尚未初始化，请使用 `async with` 进入上下文。")
        result = await self._session.list_tools()
        return [tool.name for tool in result.tools]

    async def aclose(self) -> None:
        if self._stack is not None:
            await self._stack.aclose()
            self._stack = None
            self._session = None
