"""结果渲染：终端 Markdown 与 JSON 输出。"""

from __future__ import annotations

import json
from datetime import date
from typing import Any

from .models import Activity, Coupon, RadarItem

_STATUS_LABEL = {
    "today": "今日",
    "upcoming": "即将",
    "past": "往期",
    "unknown": "未知",
}

def render_radar_markdown(
    items: list[RadarItem], today: date, demo: bool = False
) -> str:
    lines: list[str] = [f"# 麦麦活动雷达 · {today.isoformat()}"]
    if demo:
        lines.append("")
        lines.append("> 当前为离线演示模式（--demo），数据来自内置样例。")
    lines.append("")

    if not items:
        lines.append("今天没有值得特别关注的活动，去 `calendar` 看看完整日历吧。")
        return "\n".join(lines)

    for rank, item in enumerate(items, start=1):
        activity = item.activity
        status = _STATUS_LABEL.get(activity.status, activity.status)
        lines.append(f"### {rank}. {activity.title}")
        lines.append(
            f"- 时间：{activity.date or '未标注'}（{status}） · "
            f"关注度：{item.score:g}"
        )
        if item.reasons:
            lines.append(f"- 理由：{'；'.join(item.reasons)}")
        if activity.body:
            lines.append(f"- 摘要：{activity.summary()}")
        if activity.image:
            lines.append(f"- 图片：{activity.image}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def render_calendar_markdown(activities: list[Activity]) -> str:
    lines: list[str] = ["# 麦当劳活动日历"]
    if not activities:
        lines.append("")
        lines.append("未获取到活动。")
        return "\n".join(lines)

    by_date: dict[str, list[Activity]] = {}
    for activity in activities:
        by_date.setdefault(activity.date or "未标注", []).append(activity)

    for date_str in sorted(by_date, key=lambda key: (key == "未标注", key)):
        group = by_date[date_str]
        status = _STATUS_LABEL.get(group[0].status, group[0].status)
        lines.append("")
        lines.append(f"## {date_str}（{status}）")
        for activity in group:
            lines.append(f"- **{activity.title}**")
            if activity.body:
                lines.append(f"  {activity.summary(90)}")
    return "\n".join(lines).rstrip() + "\n"


def render_coupons_markdown(coupons: list[Coupon]) -> str:
    lines: list[str] = [f"# 我的优惠券（共 {len(coupons)} 张）"]
    if not coupons:
        lines.append("")
        lines.append("卡包里没有券，可执行 `bind` 一键领取。")
        return "\n".join(lines)

    claimable = [c for c in coupons if "可领取" in c.status]
    owned = [c for c in coupons if "可领取" not in c.status]

    if claimable:
        lines.append("")
        lines.append(f"## 可领取（{len(claimable)} 张）")
        lines.extend(f"- {c.title}" for c in claimable)
    if owned:
        lines.append("")
        lines.append(f"## 已持有（{len(owned)} 张）")
        lines.extend(f"- {c.title}（{c.status}）" for c in owned)
    return "\n".join(lines).rstrip() + "\n"


def to_json(payload: Any) -> str:
    return json.dumps(payload, ensure_ascii=False, indent=2)
